#!/bin/sh
# Estructuracion automatica del entorno visual de usuario
. ./imp.sh
obtenerHome() {
	_uHome="${HOME}"
	if [ -n "${SUDO_USER}" ] && hasCmd getent; then
		_uHome=$(getent passwd "${SUDO_USER}" | cut -d: -f6)
	fi
	printf "%s" "$_uHome"
}
configurarTeclado() {
	impMsg "$CIA" "Localizando mapa de entrada al idioma 'es'..."
	_uHome=$(obtenerHome) ; _xInit="${_uHome}/.xinitrc"
	if [ -f "${_xInit}" ]; then
		if ! grep -q "setxkbmap" "${_xInit}" 2>/dev/null; then
			_tFile=$(mktemp 2>/dev/null || printf "/tmp/xinit_tmp")
			printf "setxkbmap es &\n" > "$_tFile"
			cat "${_xInit}" >> "$_tFile" 2>/dev/null
			cat "$_tFile" > "${_xInit}" 2>/dev/null ; rm -f "$_tFile" 2>/dev/null
		fi
	else
		printf "setxkbmap es &\nexec openbox-session\n" > "${_xInit}" 2>/dev/null
	fi
	[ -n "${SUDO_USER}" ] && execSudo chown "${SUDO_USER}:" "${_xInit}" 2>/dev/null
	
	case "$soTarget" in
		debian) [ -f /etc/default/keyboard ] && execSudo sed -i 's/XKBLAYOUT=.*/XKBLAYOUT="es"/' /etc/default/keyboard 2>/dev/null || true ;;
		void) [ -f /etc/rc.conf ] && { execSudo sed -i 's/^KEYMAP=.*/KEYMAP="es"/' /etc/rc.conf 2>/dev/null || true; grep -q "^KEYMAP=" /etc/rc.conf 2>/dev/null || printf 'KEYMAP="es"\n' | execSudo tee -a /etc/rc.conf >/dev/null; } ;;
		freebsd) execSudo sysrc keymap="spanish.iso.acc" >/dev/null 2>&1 || true ;;
	esac
}
configurarOpenbox() {
	cnf
	impMsg "$VER" "Desplegando esqueleto de configuracion Openbox..."
	_uHome=$(obtenerHome) ; _obDir="${_uHome}/.config/openbox"
	mkdir -p "${_obDir}" 2>/dev/null
	execSudo mkdir -p /usr/share/backgrounds/ 2>/dev/null
	
	[ -f /etc/xdg/openbox/rc.xml ] && cp /etc/xdg/openbox/rc.xml "${_obDir}/" 2>/dev/null
	[ -f /etc/xdg/openbox/menu.xml ] && cp /etc/xdg/openbox/menu.xml "${_obDir}/" 2>/dev/null
	
	if [ ! -f "${_obDir}/autostart" ]; then
		{
			printf "xrandr --output HDMI-1 --mode 1280x720 --rate 50.00 &\nfeh --bg-scale /usr/share/backgrounds/img.png &\n"
			printf "dunst &\ntint2 &\nnm-applet &\nxset s off -dpms &\n"
		} > "${_obDir}/autostart" 2>/dev/null
	fi
	[ -n "${SUDO_USER}" ] && execSudo chown -R "${SUDO_USER}:" "${_uHome}/.config" 2>/dev/null || true
}
confAutostart='
# Teclado español
setxkbmap es &

# Cambiar la resolución si es necesario (opcional, ajustá a tu monitor)
#xrandr --output HDMI-1 --mode 1920x1080 --rate 60.00 &
xrandr --output HDMI-1 --mode 1280x720 --rate 50.00 &
#xrandr --output HDMI-1 --mode 800x600 --rate 50.00 &

# Poner un fondo de pantalla (reemplazá la ruta por tu imagen)
feh --bg-scale /usr/share/backgrounds/img.png & 

# Ejecutar el gestor de notificaciones 
dunst & 

# Lanzar la barra de tareas Tint2 
tint2 & 

# Lanzar el ícono de red en la bandeja del sistema (Wi-Fi)
nm-applet & 

# Gestor de energía (evita que la pantalla se apague sola)
xset s off -dpms &

# Ventanas
#picom & 

# Agente de autenticación (necesario para que pida contraseñas de WiFi)
lxpolkit &

# El panel de escritorio (barra de tareas)
lxpanel --profile Openbox &

# El applet de red (si instalaste nm-tray)
nm-tray &

# O si instalaste network-manager-gnome, usa: nm-applet &
'
cnf(){
	# Crear la carpeta de configuración en tu usuario 
	mkdir -p ~/.config/openbox
	mkdir -p /usr/share/backgrounds/
	# Copiar los archivos plantilla del sistema 
	cp -v /etc/xdg/openbox/rc.xml ~/.config/openbox/	# rc.xml: Configuración de atajos de teclado, comportamiento de ventanas y mouse.
	cp -v /etc/xdg/openbox/menu.xml ~/.config/openbox/ 	# menu.xml: Contenido menu clic derecho en el escritorio.
	cp -v /etc/xdg/openbox/autostart ~/.config/openbox/	# autostart: Programas que se abren solos al iniciar sesión (Wi-Fi, fondo de pantalla, barra, etc.).
	echo "$confAutostart" | tee -a ~/.config/openbox/autostart
}
