#!/bin/sh
set -eu
imp()  { printf "\n${%s}[$(getTSE)] [%s]\t%s${RES}" "$*" >&2; }		# informar
inf()  { #imp "MAG" "INF" "$*"
printf "\n${MAG}[$(getTSE)] [INF]\t%s${RES}" "$*" >&2; }		# informar
prg()  { printf "\n${VER}[$(getTSE)] [PRG]\t%s:${RES}" "$*" >&2; }		# preguntar
adv()  { printf "\n${AMA}[$(getTSE)] [ADV]\t%s${RES}\n" "$*" >&2; }		# advertir
err()  { printf "\n${ROJ}[$(getTSE)] [ERR]\t%s${RES}\n" "$*" >&2; }		# advertir
pantalla(){ clear; }
mostrar_progreso() {	# Barra de progreso global
	porcentaje=$((tareas_procesadas * 100 / tareas_totales))
	completado=$((porcentaje * 50 / 100))
#	barra=$(printf '%*s' "$completado" "" | tr ' ' '█')
	barra=$(printf '%*s' "$completado" "" | tr ' ' '#')
	barra="$barra$(printf '%*s' $((50-completado)) "" | tr ' ' '-')"
#	printf "\r[%s] %3d%% (%d/%d)" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales" 
	printf "\r[%s] %3d%% (%d/%d)\t${ROJO}%s ERR ${NARANJA}%s GEN ${VERDE}%s VER ${RESET}" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales" "$cntERR" "$cntGEN" "$cntVER"
#	printf "[%s] %3d%% (%d/%d)" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales"
}