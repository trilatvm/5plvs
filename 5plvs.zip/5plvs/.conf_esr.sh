Para exprimir al máximo tu TV Box con chip RK322X (arquitectura de 32 bits y 2 GB de RAM) corriendo un kernel actual en 2026, el enfoque principal debe ser reducir el uso de memoria RAM y optimizar el rendimiento del procesador de cuatro núcleos de bajo consumo.
Actualmente tenés la RAM bastante justa (927 MiB en uso y solo 179 MiB libres de forma directa, aunque el sistema puede recuperar de la caché). Además, estás corriendo Firefox ESR 153, que es una versión moderna y pesada para este hardware.
Acá tenés el plan de acción exacto para optimizar ambos componentes:

Parte 1: Optimización Extrema del TV Box (Sistema)


1. Activar ZRAM (Compresión de RAM en tiempo real)

Al no tener memoria de intercambio (Inter: 0B), cuando te quedes sin RAM el sistema va a congelar aplicaciones por falta de memoria (OOM). Como tu micro es de 4 núcleos, configurar ZRAM va a comprimir la RAM inactiva en el procesador, multiplicando virtualmente tu memoria disponible sin usar un disco lento.
1. Instalá las herramientas de ZRAM:bash
sudo apt update && sudo apt install -y zram-tools
Usa el código con precaución.
2. Editá su archivo de configuración:bash
sudo nano /etc/default/zramswap
Usa el código con precaución.
3. Dejá las líneas con estos valores óptimos para tus 2 GB de RAM:ini
ALLOCATION_STRATEGY=adaptive
PERCENT=50
PRIORITY=100
Usa el código con precaución.
4. Guardá (Ctrl+O, Enter) y salí (Ctrl+X). Reiniciá el servicio:bash
sudo service zramswap restart
Usa el código con precaución.
Si ejecutás free -h, ahora vas a ver alrededor de 1.0GiB en la sección "Inter:" (Swap).

2. Cambiar el Gobernador de la CPU a Performance

Por defecto, las TV Box balancean el consumo y el calor bajando la frecuencia del microprocesador. Forzalo a trabajar siempre a su máxima velocidad disponible:
bash
sudo apt install -y cpufrequtils
echo 'GOVERNOR="performance"' | sudo tee /etc/default/cpufrequtils
sudo systemctl restart cpufrequtils
Usa el código con precaución.

3. Ajustar el comportamiento de la memoria (Sysctl)

Para evitar que el TV Box use agresivamente la caché del sistema y se quede sin memoria para tus scripts o el navegador, agregá estas directivas:
bash
sudo tee -a /etc/sysctl.conf <<EOF
vm.vfs_cache_pressure=50
vm.dirty_background_ratio=5
vm.dirty_ratio=10
EOF
sudo sysctl -p
Usa el código con precaución.

Parte 2: Optimización de Firefox ESR 153.5.1

Firefox en arquitecturas armv7l consume muchos recursos de procesamiento debido al motor de JavaScript y el renderizado por software (ya que la GPU del RK322X a veces no tiene drivers de aceleración nativos en Linux moderno).
Abrí Firefox, escribí about:config en la barra de direcciones, aceptá la advertencia y modificá las siguientes opciones de rendimiento:

1. Limitar los procesos de contenido (Vital para ahorrar RAM)

Por defecto, Firefox abre un proceso independiente por cada pestaña. Vamos a forzarlo a usar un entorno mucho más compacto.
• Buscar: dom.ipc.processCount -> Cambiar su valor a 1 o 2 (máximo).
• Buscar: dom.ipc.processCount.extension -> Cambiar a 1.

2. Desactivar animaciones e interfaz pesada

• Buscar: toolkit.cosmeticAnimations.enabled -> Cambiar a false.
• Buscar: browser.tabs.animate -> Cambiar a false.
• Buscar: browser.preferences.animateFade -> Cambiar a false.

3. Reducir el uso de memoria en caché de pestañas

Esto limita cuánta memoria retiene Firefox para el historial de "atrás" y "adelante" en las pestañas activas.
• Buscar: browser.sessionhistory.max_entries -> Cambiar a 10.
• Buscar: browser.cache.memory.enable -> Asegurar que esté en true.
• Buscar: browser.cache.memory.capacity -> Cambiar a 52428 (Limita la caché en RAM a 50 MB estrictos).

4. Forzar/Ajustar la aceleración gráfica por software eficiente

Como las GPU Mali viejas sufren en kernels 6.x, si notas que la pantalla parpadea o va a tirones, forzar WebRender por software (eficiente en CPU multihilo) suele ayudar:
• Buscar: gfx.webrender.software -> Cambiar a true.

5. Instalar la extensión indispensable: uBlock Origin

No uses Firefox en un TV Box sin un bloqueador de publicidad agresivo. El 60% del consumo de RAM y CPU de una página web actual se va en scripts de rastreo y anuncios flotantes. uBlock Origin es el más ligero y le va a quitar una carga masiva encima a tu procesador.
Aplicá la configuración de ZRAM en el sistema y decime si notás una mejora al abrir pestañas en Firefox. Si ejecutás un comando pesado o reproducís videos, ¿notás si el TV Box levanta mucha temperatura al tacto?
