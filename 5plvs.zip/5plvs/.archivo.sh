#!/bin/sh
set -eu
procesar_archivo() {	# Procesar archivo
	archivo=$1 dir=$2
	for a in $algoritmos; do
		dir_hash="$dir/.shall/$a"
		mkdir -p "$dir_hash"
		nombre_hash="$(basename "$archivo" | tr ' ' '_').$a"
		archivo_hash="$dir_hash/$nombre_hash"
		printf "\n${CIAN}[PRO]\t%s${RESET}\n" "$(basename "$archivo")"
		hash_actual=$(calcular_hash "$archivo" "$a" || true)
		if [ -z "$hash_actual" ]; then
			printf "${ROJO}[ERROR]${RESET} %s (%s)\n" "$archivo" "$a"
		elif [ -f "$archivo_hash" ]; then
			hash_guardado=$(cat "$archivo_hash")
			if [ "$hash_actual" = "$hash_guardado" ]; then
				cntVER=$((cntVER + 1))
				printf "${VERDE}[+++]\t${MAGENTA}%s\t${VERDE}%s${RESET}\n" "$a" "$hash_guardado"
#				printf "[CORRECTO]\t%s\n\t\tCAL:%s\n\t\tRGT:%s\n" "$archivo" "$hash_actual" "$hash_guardado" >> "./${tsi}_CRR.log"
			else
				cntERR=$((cntERR + 1))
				printf "${ROJO}[!!!]\t${MAGENTA}%s\t${BLANCO}%s\n\t\t${ROJO}%s${RESET}\n" "$a" "$hash_actual" "$hash_guardado"
				archNbr="${tsi}_ERR"
				archExt="log"
				arch="${archNbr}.${archExt}"
				rta="/home/$(whoami)/"
				mkdir -p $rta
				archRta="${rta}${arch}"
				printf "[INCORRECTO]\t%s\n\t\tCAL:%s\n\t\tRGT:%s\n" "$archivo" "$hash_actual" "$hash_guardado" >> "$archRta"
				informar "Guardado: $rta"
#				sleep 3
			fi
		else
			cntGEN=$((cntGEN + 1))
			printf '%s' "$hash_actual" > "$archivo_hash"
#			printf "${NARANJA}[GEN]\t${MAGENTA}%s\n\t${CIAN}%s\t${ROJO}%sERR ${NARANJA}%sGEN ${VERDE}%sVER ${RESET}\n" "$a" "$archivo" "$cntERR" "$cntGEN" "$cntVER"
			printf "${NARANJA}[GEN]\t${BLANCO}%s\t${CIAN}%s\n\t\t${CIAN}%s${RESET}\n" "$a" "$archivo_hash" "$hash_actual"
#			printf "[GENERAR]\t%s\n\t\tCAL:%s\n" "$archivo" "$hash_actual" >> "./${tsi}_GEN.log"
		fi
		tareas_procesadas=$((tareas_procesadas + 1))
		mostrar_progreso
	done
}
procesar_directorio() {	# Procesar directorio y subdirectorios
	archivos=$(find "$1" -type f ! -path "*/.shall/*")
	[ -z "$archivos" ] && return
	count=$(printf '%s\n' $archivos | wc -l)
	tareas_totales=$((count * $(set -- $algoritmos; echo $#)))
	tareas_procesadas=0
	for f in $archivos; do
		dir=$(dirname "$f")
		procesar_archivo "$f" "$dir"
	done
	printf "\n"
	informar "Procesamiento completado para $1"
}