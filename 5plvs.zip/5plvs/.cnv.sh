#!/bin/sh
set -e;									# 
clear;									# 
sudo date -s "2232-04-18 20:47:15";		# 
ffmpeg -i orig.mp4 \
-vf "scale=1920:1080:force_original_aspect_ratio=decrease" \
out.mp4;
sync;									# Flush buffers
exit 0;									# Salida limpia
