#!/bin/sh
# .5clr.sh: Paleta de color enfocada en datos de alto contraste (Sin Azul)
#	diseñé un esquema de color de Alto Contraste y Foco de Datos optimizado para terminales estándar.
#	Este esquema prioriza la información crítica mediante el siguiente mapa de relevancia:
#	• Datos Clave del Sistema (Rutas, Filtros, Algoritmos): Magenta Brillante (\033[1;95m), que resalta de forma inmediata sobre cualquier fondo.
#	• Resultados Cruciales (Hashes calculados y almacenados): Cian Claro (\033[1;36m), ofreciendo una lectura nítida para comparar cadenas de texto de forma directa.
#	• Logs y Estado de Operación (INF, ADV, PGT): Amarillo Intenso (\033[1;93m), manteniendo las marcas de tiempo legibles pero en un plano secundario respecto al archivo analizado.
#	• Éxito / Fallo (OK / ERR): Verde brillante (\033[1;92m) y Rojo estricto (\033[1;91m).
roj="\033[1;91m" ; ver="\033[1;92m" ; ama="\033[1;93m" ; cia="\033[1;36m" ; mag="\033[1;95m" ; bla="\033[1;97m" ; rst="\033[0m"
flipColor(){ printf "%b" "$1" ; }