#!/bin/sh
# .5par2.sh: Logica par2 limpia e integrada cromáticamente
verificarHerramientasPar2() { if ! command -v par2 >/dev/null 2>&1; then printf "[ERR] Utilidad par2 ausente del sistema operativo.\n" ; exit 1 ; fi ; }
calcularBloqueOptimo() {
	cbUA=$1
	cbTB=$(wc -c < "$cbUA" 2>/dev/null || echo "0")
	cbTB=$(printf "%s" "$cbTB" | tr -cd '0-9')
	[ -z "$cbTB" ] && cbTB=0
	cbTP=4096 ; cbTM=$(( cbTB / 1048176 ))
	if [ "$cbTM" -le 50 ]; then cbBC=16384
	elif [ "$cbTM" -le 500 ]; then cbBC=524288
	elif [ "$cbTM" -le 2000 ]; then cbBC=2097152
	else cbBC=4194304; fi
	cbRes=$(( cbBC % cbTP ))
	if [ "$cbRes" -eq 0 ]; then echo "$cbBC"; else echo "$(( cbBC + (cbTP - cbRes) ))"; fi ; }
calcularPar2() {
	cpRC=$1 ; cpDT=$2 ; cpNB=$(basename "$cpRC") ; cpDP="$cpDT/par2" ; asegurarDirectorio "$cpDP" ; cpAP="$cpDP/$cpNB.par2"
	if [ -f "$cpAP" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "El mapa par2 ya existe. ¿Sobreescribir? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Operacion omitida." ; return 0 ; fi
		rm -f "$cpDP/$cpNB"*.par2 "$cpDP/$cpNB"*.vol* 2>/dev/null || true ; fi
	mInf "Calculando tamaño de bloque optimo..."
	cpBO=$(calcularBloqueOptimo "$cpRC")
	cpRD=$(awk '/MemAvailable/ {print $2}' /proc/meminfo 2>/dev/null || echo "65536")
	cpRD=$(printf "%s" "$cpRD" | tr -cd '0-9') ; [ -z "$cpRD" ] && cpRD=65536
	cpRA=$(( cpRD / 1024 / 2 )) ; [ "$cpRA" -lt 32 ] && cpRA=32
	mInf "Recursos asignados -> RAM: ${cpRA}MB | Bloque: $cpBO"
	if par2 create -r20 -s"$cpBO" -m"$cpRA" -B "$cpDT" -a "$cpDP/$cpNB" "$cpRC" >/dev/null 2>&1; then
		mOk "Volumenes PAR2 creados exitosamente." ; genPar2=$((genPar2 + 1))
	else
		mErr "Fallo al generar el mapa de redundancia par2." ; incPar2=$((incPar2 + 1))
	fi
	verSemaforoPar2 ; }
verificarPar2() {
	vpRC=$1 ; vpDT=$2 ; vpNB=$(basename "$vpRC") ; vpAP="$vpDT/par2/$vpNB.par2"
	if verificarArchivoLectura "$vpAP"; then
		mInf "Validando integridad estructural via PAR2..."
		if par2 verify -B "$vpDT" -a "$vpDT/par2/$vpNB" "$vpRC" >/dev/null 2>&1; then
			mOk "ESTRUCTURA SANA: $vpNB" ; corPar2=$((corPar2 + 1))
		else
			mErr "ESTRUCTURA CORRUPTA O INCOMPLETA: $vpNB" ; incPar2=$((incPar2 + 1))
		fi
	else mInf "Sin mapa PAR2 registrado para: $vpNB" ; fi
	verSemaforoPar2 ; }
repararPar2() {
	rpRC=$1 ; rpDT=$2 ; rpNB=$(basename "$rpRC") ; rpDP="$rpDT/par2" ; rpAP="$rpDP/$rpNB.par2"
	if verificarArchivoLectura "$rpAP"; then
		if par2 verify -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1; then
			mOk "El archivo ya se encuentra sano: $rpNB" ; corPar2=$((corPar2 + 1))
		else
			mInf "Iniciando proceso de reconstruccion de sectores..."
			if par2 repair -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1; then
				mOk "ARCHIVO RECONSTRUIDO Y REPARADO: $rpNB" ; corPar2=$((corPar2 + 1))
			else
				mErr "REPARACION FALLIDA: Sectores de redundancia insuficientes para: $rpNB" ; incPar2=$((incPar2 + 1))
			fi
		fi
	else mErr "Falta el mapa de recuperacion PAR2 para: $rpNB" ; incPar2=$((incPar2 + 1)) ; fi
	verSemaforoPar2 ; }
herramientasPar2Check() { verificarHerramientasPar2 ; }
auditarLoteVerificacionPar2() {
	avFlPar=$1 ; avModPar=$2 ; avDirPar="$directorioActual/par2"
	if [ ! -d "$avDirPar" ]; then mObs "No existen mapas PAR2 creados en este directorio." ; return 0 ; fi
	for avMapa in "$avDirPar"/*.par2; do
		if [ ! -f "$avMapa" ]; then continue ; fi
		avArcOriginalPar=$(basename "$avMapa" ".par2")
		if [ -n "$avFlPar" ]; then case "$avArcOriginalPar" in *."$avFlPar") ;; *) continue ;; esac ; fi
		printf "\n" ; mInf "Auditando registro PAR2: $avArcOriginalPar"
		if [ "$avModPar" = "verificar" ]; then
			verificarPar2 "$directorioActual/$avArcOriginalPar" "$directorioActual"
		elif [ "$avModPar" = "reparar" ]; then
			repararPar2 "$directorioActual/$avArcOriginalPar" "$directorioActual"
		fi
	done ; }
