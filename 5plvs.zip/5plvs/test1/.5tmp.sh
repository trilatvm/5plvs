#!/bin/sh
# .5tmp.sh: Marcas de tiempo extendidas e integradas
obtenerTimestamp() { date '+[%Y-%m-%d %H:%M:%S]' ; }
iniciarCronometro() { cronometroInicio=$(date '+%s') ; }
mostrarTiempoTranscurrido() {
	mtCF=$(date '+%s') ; mtST=$(( mtCF - ${cronometroInicio:-mtCF} ))
	mtH=$((mtST / 3600)) ; mtR=$((mtST % 3600)) ; mtM=$((mtR / 60)) ; mtS=$((mtR % 60))
	mtTF=$(printf "%02d:%02d:%02d" "$mtH" "$mtM" "$mtS")
	printf "%s [INF] Cronometro finalizado. Duracion total: %s\n" "$(obtenerTimestamp)" "$mtTF" ; }
