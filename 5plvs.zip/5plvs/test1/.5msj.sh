#!/bin/sh
# .5msj.sh: Emision de notificaciones limpia sin residuos numericos
mMsg() { printf "${1}%s [%-3s] %s${rst}\n" "$(obtenerTimestamp)" "$2" "$3" ; }
mOk() {  mMsg "$ver" "OK" "$1" ; }
mErr() { mMsg "$roj" "ERR" "$1" ; }
mInf() { mMsg "$ama" "INF" "$1" ; }
mAdb() { mMsg "$roj" "ADV" "$1" ; }
mPgt() { printf "${ama}%s [?  ] %s${rst}" "$(obtenerTimestamp)" "${mag}$1" ; }
mObs() { mMsg "$bla" "OBS" "$1" ; }
mObsErr() { mMsg "$bla" "OBS" "$1" ; }
semaforo(){ printf "${ama}%s [INF] Semáforo -> Fallidos: ${roj}%s${ama} | Creados: ${mag}%s${ama} | Sanos: ${ver}%s${rst}\n" "$(obtenerTimestamp)" "$1" "$2" "$3" ; }
verSemaforoHash(){ semaforo "${incMd5:-0}" "${genMd5:-0}" "${corMd5:-0}" ; }
verSemaforoPar2(){ semaforo "${incPar2:-0}" "${genPar2:-0}" "${corPar2:-0}" ; }
esperarEnter() { printf "\n" && mInf "[ENTER] para continuar..." && read -r _ ; }
