#!/bin/sh
# .5bckpCli.sh: Menus estructurados verticalmente en lista con distribucion de alto contraste
limpiarConsola() { printf "\033[H\033[2J" && sync 2>/dev/null || true ; }
mostrarMenuGeneral() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== MENU PRINCIPAL ==="
	printf "${ama}Directorio activo: ${mag}%s${rst}\n" "$directorioActual"
	printf "${ama}Filtro extension:  ${mag}%s${rst}\n" "${ultimoFiltroExtension:-TODOS LOS ARCHIVOS}"
	printf "%s\n" "1) Gestion de Firmas Hash (M1)"
	printf "%s\n" "2) Gestion de Mapas PAR2 (M2)"
	printf "%s\n" "3) Proceso Completo de Auditoria (M3)"
	printf "%s\n" "4) Configurar Filtro de Extension"
	printf "%s\n" "C) Cambiar Directorio de Trabajo"
	printf "%s\n" "Q) Salir del Sistema" ; }
readOpcionGeneral() { printf "${ama}[SISTEMA] Seleccione opcion [${mag}%s${ama}]: ${rst}" "$uG" ; read -r mO ; [ -z "$mO" ] && mO=$uG ; uG=$mO ; }
mostrarMenuHash() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== GESTION DE FIRMAS HASH ==="
	printf "${ama}Algoritmo activo:  ${mag}%s${rst}\n" "$1"
	printf "${ama}Disponibles:       ${mag}%s${rst}\n" "$2"
	printf "%s\n" "1) Calcular nuevas firmas hash"
	printf "%s\n" "2) Verificar integridad del lote"
	printf "%s\n" "3) Reemplazar firmas existentes"
	printf "%s\n" "4) Cambiar algoritmo de calculo"
	printf "%s\n" "V) Volver al menu principal" ; }
readOpcionHash() { printf "${ama}[SISTEMA] Seleccione opcion [${mag}%s${ama}]: ${rst}" "$uH" ; read -r hO ; [ -z "$hO" ] && hO=$uH ; uH=$hO ; }
mostrarMenuPar2() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== GESTION DE MAPAS PAR2 ==="
	printf "%s\n" "1) Calcular volumenes de redundancia"
	printf "%s\n" "2) Verificar contenedores par2"
	printf "%s\n" "3) Reemplazar mapas existentes"
	printf "%s\n" "4) Reparar archivos dañados"
	printf "%s\n" "V) Volver al menu principal" ; }
readOpcionPar2() { printf "${ama}[SISTEMA] Seleccione opcion [${mag}%s${ama}]: ${rst}" "$uP" ; read -r pO ; [ -z "$pO" ] && pO=$uP ; uP=$pO ; }
mostrarMenuFull() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== AUDITORIA COMPLETA (FULL) ==="
	printf "%s\n" "1) Ejecutar calculo total del lote"
	printf "%s\n" "2) Ejecutar validacion total del lote"
	printf "%s\n" "3) Reemplazar todas las firmas y mapas"
	printf "%s\n" "4) Reparar todo el sistema de archivos"
	printf "%s\n" "V) Volver al menu principal" ; }
readOpcionFull() { printf "${ama}[SISTEMA] Seleccione opcion [${mag}%s${ama}]: ${rst}" "$uF" ; read -r fO ; [ -z "$fO" ] && fO=$uF ; uF=$fO ; }
mostrarMenuFiltro() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== CONFIGURACION DE FILTROS ==="
	printf "${ama}Filtro actual: [ ${mag}%s${ama} ]${rst}\n" "${ultimoFiltroExtension:-NINGUNO (PROCESA TODO)}"
	printf "%s\n" "1) Definir extension especifica"
	printf "%s\n" "2) Limpiar filtro y procesar todo"
	printf "%s\n" "V) Volver al menu principal" ; }
readOpcionFiltro() { printf "${ama}[SISTEMA] Seleccione opcion [${mag}%s${ama}]: ${rst}" "$uE" ; read -r eO ; [ -z "$eO" ] && eO=$uE ; uE=$eO ; }
