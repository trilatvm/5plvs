#!/sh
# _bckp.sh: Logica de negocio principal (Script Maestro Corregido)
directorioScript=$(dirname "$0") ; directorioScript=$(cd "$directorioScript" && pwd)
if [ -f "$directorioScript/.5clr.sh" ]; then . "$directorioScript/.5clr.sh" ; else printf "[ERR] Modulo de color ausente.\n" ; exit 1 ; fi
if [ -f "$directorioScript/.5msj.sh" ] && [ -f "$directorioScript/.5bar.sh" ] && \
   [ -f "$directorioScript/.5bckpCli.sh" ] && [ -f "$directorioScript/.5tmp.sh" ] && \
   [ -f "$directorioScript/.5arch.sh" ] && [ -f "$directorioScript/.5hash.sh" ] && \
   [ -f "$directorioScript/.5par2.sh" ] && [ -f "$directorioScript/.5rgx.sh" ]; then
	. "$directorioScript/.5msj.sh" ; . "$directorioScript/.5bar.sh" ; . "$directorioScript/.5bckpCli.sh"
	. "$directorioScript/.5tmp.sh" ; . "$directorioScript/.5rgx.sh" ; . "$directorioScript/.5arch.sh"
	. "$directorioScript/.5hash.sh" ; . "$directorioScript/.5par2.sh"
else printf "[ERR] Módulos esenciales ausentes.\n" ; exit 1 ; fi
uG="1" ; uH="1" ; uP="1" ; uF="1" ; uE="1" ; ultimoAlgoritmo="md5" ; ultimoFiltroExtension=""
incMd5=0 ; genMd5=0 ; corMd5=0 ; incPar2=0 ; genPar2=0 ; corPar2=0
procesarBucleLote() {
	pblMM=$1 ; pblAM=$2 ; pblEM=$3
	if [ "$pblAM" = "verificar" ] || [ "$pblAM" = "reparar" ]; then
		if [ "$pblMM" = "hash" ]; then
			auditarLoteVerificacionHash "$ultimoAlgoritmo" "$pblEM"
		elif [ "$pblMM" = "par2" ]; then
			auditarLoteVerificacionPar2 "$pblEM" "$pblAM"
		fi
		return 0
	fi
	pblTL=$(contarArchivos "$pblEM" "$directorioActual") ; pblTL=$(echo "$pblTL" | tr -cd '0-9')
	if [ -z "$pblTL" ] || [ "$pblTL" -eq 0 ]; then mObs "Sin archivos para procesar."
	else
		pblCP=0
		for pblAO in "$directorioActual"/*; do
			if [ ! -f "$pblAO" ] || [ -d "$pblAO" ] || ! validarArchivoRegex "$pblAO" || ! validarExclusionEcosistema "$pblAO" || ! verificarArchivoLectura "$pblAO"; then continue ; fi
			if [ -n "$pblEM" ]; then case "$pblAO" in *."$pblEM") ;; *) continue ;; esac ; fi
			pblCP=$((pblCP + 1)) ; printf "\n" ; dibujarProgreso "$pblCP" "$pblTL" "$(basename "$pblAO")"
			if [ "$pblMM" = "hash" ] && [ "$pblAM" = "crear" ]; then calcularHash "$pblAO" "$directorioActual" "$ultimoAlgoritmo"
			elif [ "$pblMM" = "par2" ] && [ "$pblAM" = "crear" ]; then calcularPar2 "$pblAO" "$directorioActual" ; fi ; done ; fi ; }
ejecutarModoFull() {
	emfAF=$1 ; iniciarCronometro
	if [ "$emfAF" = "crear" ] || [ "$emfAF" = "remplazar" ]; then
		[ "$emfAF" = "remplazar" ] && modoFlujoSilencioso="activo" || modoFlujoSilencioso="desactivado"
		for alg in $hD; do mInf "Procesando lote HASH: $alg" ; ultimoAlgoritmo=$alg ; procesarBucleLote "hash" "crear" "$ultimoFiltroExtension" ; done
		mInf "Procesando lote PAR2..." ; procesarBucleLote "par2" "crear" "$ultimoFiltroExtension" ; modoFlujoSilencioso="desactivado"
	elif [ "$emfAF" = "verificar" ] || [ "$emfAF" = "reparar" ]; then
		modoFlujoSilencioso="activo"
		for alg in $hD; do mInf "Validando lote completo HASH: $alg" ; auditarLoteVerificacionHash "$alg" "$ultimoFiltroExtension" ; done
		mInf "Verificando lote completo PAR2..." ; auditarLoteVerificacionPar2 "$ultimoFiltroExtension" "$emfAF" ; fi
	auditarFirmasHuerfanas "$directorioActual" "$hD" ; mOk "FULL completado." ; mostrarTiempoTranscurrido ; }
main() {
	printf "\033[H\033[2J" && sync ; herramientasPar2Check ; hD=$(detectarAlgoritmosHashes) ; inicializarEntornoTrabajo "$directorioScript"
	while true; do
		mostrarMenuGeneral ; readOpcionGeneral
		if [ "$mO" = "q" ] || [ "$mO" = "Q" ]; then mInf "Fin." && break; fi
		if [ "$mO" = "c" ] || [ "$mO" = "C" ]; then ejecutarConmutacionDir && continue; fi
		if [ "$mO" = "1" ]; then
			while true; do
				mostrarMenuHash "$ultimoAlgoritmo" "$hD" ; readOpcionHash
				if [ "$hO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "2" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="verificar"; break;
				elif [ "$hO" = "3" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "4" ]; then ejecutarCambioAlgoritmo "$hD"
				elif [ "$hO" = "v" ] || [ "$hO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "2" ]; then
			while true; do
				mostrarMenuPar2 ; readOpcionPar2
				if [ "$pO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "2" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="verificar"; break;
				elif [ "$pO" = "3" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "4" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="reparar"; break;
				elif [ "$pO" = "v" ] || [ "$pO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "3" ]; then
			while true; do
				mostrarMenuFull ; readOpcionFull
				if [ "$fO" = "1" ]; then ejecutarModoFull "crear" ; break;
				elif [ "$fO" = "2" ]; then ejecutarModoFull "verificar" ; break;
				elif [ "$fO" = "3" ]; then ejecutarModoFull "remplazar" ; break;
				elif [ "$fO" = "4" ]; then ejecutarModoFull "reparar" ; break;
				elif [ "$fO" = "v" ] || [ "$fO" = "V" ]; then break ; fi ; done ; esperarEnter
		elif [ "$mO" = "4" ]; then
			while true; do
				mostrarMenuFiltro ; readOpcionFiltro
				if [ "$eO" = "1" ]; then ejecutarConfiguracionFiltro
				elif [ "$eO" = "2" ]; then ultimoFiltroExtension="" ; mOk "Filtro removido." ; break
				elif [ "$eO" = "v" ] || [ "$eO" = "V" ]; then break ; fi ; done ; esperarEnter
		else mErr "Inválido." ; esperarEnter ; fi ; done ; }
main "$@"
exit 0
