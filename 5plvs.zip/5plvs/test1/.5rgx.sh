#!/bin/sh
# .5rgx.sh: Filtros logicos limpios POSIX con grep
validarArchivoRegex() {
	vrNb=$(basename "$1")
	if printf "%s" "$vrNb" | grep -Eq '^[a-zA-Z0-9_-]+\.[a-zA-Z0-9]+$'; then return 0; else return 1; fi ; }
validarExtensionRegex() { if printf "%s" "$1" | grep -Eq '^[a-zA-Z0-9]+$'; then return 0; else return 1; fi ; }
validarRutaAbsolutaRegex() { if printf "%s" "$1" | grep -Eq '^/[a-zA-Z0-9_.-][a-zA-Z0-9_./-]*$'; then return 0; else return 1; fi ; }
validarAlgoritmoRegex() { if printf "%s" "$1" | grep -Eq '^sha[0-9]+$|^md5$'; then return 0; else return 1; fi ; }
