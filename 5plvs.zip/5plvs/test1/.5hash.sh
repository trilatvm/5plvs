#!/bin/sh
# .5hash.sh: Logica hash corregida para visualizacion cruzada limpia
detectarAlgoritmosHashes() {
	daLH=""
	for daAC in md5 sha1 sha256 sha512; do
		if command -v "${daAC}sum" >/dev/null 2>&1; then daLH="$daLH $daAC" ; fi ; done
	printf "%s" "$daLH" ; }
calcularHash() {
	chRC=$1 ; chDT=$2 ; chTH=$3 ; chNB=$(basename "$chRC") ; chDD="$chDT/hashes/$chTH" ; asegurarDirectorio "$chDD" ; chAH="$chDD/$chNB.$chTH"
	if [ -f "$chAH" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "La firma ya existe. ¿Sobreescribir? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Operacion omitida." ; return 0 ; fi ; fi
	mInf "Calculando firma hash $chTH..."
	chTmpFile="${chAH}.tmp"
	if "${chTH}sum" "$chRC" > "$chTmpFile" 2>/dev/null; then
		chHP=$(awk '{print $1}' "$chTmpFile") ; rm -f "$chTmpFile"
		if [ -n "$chHP" ]; then
			printf "%s  %s\n" "$chHP" "$chNB" > "$chAH"
			mOk "Firma creada con exito." ; genMd5=$((genMd5 + 1))
		else mErr "Error de lectura de salida en archivo: $chNB" ; incMd5=$((incMd5 + 1)) ; fi
	else rm -f "$chTmpFile" ; mErr "Fallo critico del binario al procesar: $chNB" ; incMd5=$((incMd5 + 1)) ; fi
	verSemaforoHash ; }
verificarHash() {
	vhRC=$1 ; vhDT=$2 ; vhTH=$3 ; vhNB=$(basename "$vhRC") ; vhAH="$vhDT/hashes/$vhTH/$vhNB.$vhTH"
	if [ ! -f "$vhRC" ]; then
		mErr "CRITICO: Archivo ausente del disco -> $vhNB"
		incMd5=$((incMd5 + 1)) ; verSemaforoHash ; return 1 ; fi
	mInf "Validando integridad de $vhTH..."
	vhHG=$(awk '{print $1}' "$vhAH" 2>/dev/null || echo "")
	vhTmpFile="${vhAH}.vtmp"
	if "${vhTH}sum" "$vhRC" > "$vhTmpFile" 2>/dev/null; then
		vhHC=$(awk '{print $1}' "$vhTmpFile") ; rm -f "$vhTmpFile"
		printf "${ama}%s [OBS] Almacenado: ${mag}%s${rst}\n" "$(obtenerTimestamp)" "$vhHG"
		printf "${ama}%s [OBS] Calculado:  ${cia}%s${rst}\n" "$(obtenerTimestamp)" "$vhHC"
		if [ -z "$vhHC" ] || [ -z "$vhHG" ]; then vhSt="error"
		elif [ "$vhHG" = "$vhHC" ]; then vhSt="ok" ; else vhSt="fallo" ; fi
		if [ "$vhSt" = "error" ]; then mErr "Error de lectura: $vhNB" ; incMd5=$((incMd5 + 1))
		elif [ "$vhSt" = "ok" ]; then mOk "INTEGRO: $vhNB" ; corMd5=$((corMd5 + 1))
		else mErr "CORRUPTO: $vhNB" ; incMd5=$((incMd5 + 1)) ; fi
	else rm -f "$vhTmpFile" ; mErr "Error de ejecucion en verificador: $vhNB" ; incMd5=$((incMd5 + 1)) ; fi
	verSemaforoHash ; }
auditarLoteVerificacionHash() {
	avAlg=$1 ; avFl=$2 ; avDir="$directorioActual/hashes/$avAlg"
	if [ ! -d "$avDir" ]; then mObs "No existen firmas registradas para el algoritmo $avAlg." ; return 0 ; fi
	for avFirma in "$avDir"/*; do
		if [ ! -f "$avFirma" ]; then continue ; fi
		avArcOriginal=$(basename "$avFirma" ".$avAlg")
		if [ -n "$avFl" ]; then case "$avArcOriginal" in *."$avFl") ;; *) continue ;; esac ; fi
		printf "\n" ; mInf "Auditando registro hash: $avArcOriginal.$avAlg"
		verificarHash "$directorioActual/$avArcOriginal" "$directorioActual" "$avAlg"
	done ; }
