#!/bin/sh
# .5bar.sh: Barra grafica flexible que prioriza el nombre del archivo y su peso en MB
dibujarProgreso() {
	dpAct=$1 ; dpTot=$2 ; dpNom=$3
	[ -z "$dpTot" ] || [ "$dpTot" -le 0 ] && dpTot=1
	[ -z "$dpAct" ] && dpAct=0
	dpMB=0
	if [ -f "$dpNom" ]; then
		dpBytes=$(wc -c < "$dpNom" 2>/dev/null || echo "0")
		dpBytes=$(printf "%s" "$dpBytes" | tr -cd '0-9')
		[ -n "$dpBytes" ] && dpMB=$(( dpBytes / 1048576 )) ; fi
	dpPorc=$(( (dpAct * 100) / dpTot )) ; dpMax=40
	dpLleno=$(( (dpPorc * dpMax) / 100 ))
	[ "$dpLleno" -gt "$dpMax" ] && dpLleno=$dpMax
	[ "$dpLleno" -lt 0 ] && dpLleno=0
	dpVac=$(( dpMax - dpLleno )) ; [ "$dpVac" -lt 0 ] && dpVac=0
	dpBP="########################################"
	dpLP="----------------------------------------"
	dpBar=$(printf "%.${dpLleno}s%.${dpVac}s" "$dpBP" "$dpLP")
	printf "${ama}%s [INF] Progreso: [${mag}%s${ama}] %d%% (%d/%d)${rst}\n" "$(obtenerTimestamp)" "$dpBar" "$dpPorc" "$dpAct" "$dpTot"
	printf "${ama}%s [INF] Objetivo: ${cia}%s${rst} (${mag}%d MB${rst})\n" "$(obtenerTimestamp)" "$(basename "$dpNom")" "$dpMB" ; }
