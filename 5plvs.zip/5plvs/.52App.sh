#!/bin/sh
set -e
buffer=
# Colores ANSI
ROJ='\033[91m'; AMA='\033[93m'; AZU='\033[94m';
NAR='\033[33m'; VER='\033[92m'; MAG='\033[95m';
CIA='\033[96m'; BLA='\033[97m'; RST='\033[0m';
pkgs='
webhttrack webhttrack-common
audacity audacity-data
xorg
drm drm-kmod
openbox obconf menu tint2 feh jgmenu
xfce4 xfce4-dev-tools xfce4-goodies xfce4-mount-plugin
lightdm lightdm-gtk-greeter
xfonts-terminus xfonts-terminus-dos xfonts-terminus-oblique
moreutils coreutils top htop btop
ntpsec ntpsec-doc ntpsec-ntpdate pps-tools gpsd gpsd-clients
linux-headers-current-rockchip
iptables iptables-persistent fail2ban ipmiutil net-tools network-manager network-manager-gnome inotify-tools rsync cron
dctrl-tools ddnet-tools
alien automake build-essential cmake dkms
alsa alsa-tools pipewire pipewire-audio-client-libraries pipewire-pulse wireplumber pavucontrol
cmus cmus-plugin-ffmpeg ffmpeg flac mpv soundconverter spek vlc
postgresql-all
default-jdk default-jre
nodejs npm
git
octave
devscripts
python3-full python3 python3-pip python3-setuptools python3-wheel
aria2 firefox-esr putty uget yt-dlp sshfs
avogadro geogebra stellarium stockfish
cubicsdr cutesdr gnss-sdr gpredict
librecad dia logisim
fonts-terminus fonts-terminus-otb
libreoffice cups qpdfview
nano geany
imagemagick
par2 pypar2
gvfs gvfs-fuse
exfat-fuse exfatprogs exfat-utils fatattr e2fsprogs fatresize dosfstools mtools fuse2fs
ntfs-3g libfsntfs-dev libfsntfs-utils ntfs2btrfs ntfs-config python3-libfsntfs scrounge-ntfs
btrfs-progs
zfs-auto-snapshot zfs-dkms zfs-dracut zfs-initramfs zfsnap zfs-test zfsutils-linux zfs-zed zsnapd zsnapd-rcmd python3-libzfs python3-pyzfs pyzfs-doc simplesnap
sudo unzip xz xarchiver zip gzip
gnome-disk-utility gnome-shell-extension-hard-disk-led
gparted udisks2 udisksie smartmontools testdisk
qemu-system
wine wine-binfmt winetricks fonts-wine
xpaint rgbpaint
'
usr="$(whoami)"
base="/home/${usr}/logOS/"
bkp="/home/${usr}/bkpOS/"
getTSE(){ date "+%s"; }
check_instalado() { dpkg -s "$1" >/dev/null 2>&1; }
check_repositorio() { apt-cache show "$1" >/dev/null 2>&1; }
ejecutar_instalacion() {
	pkg=$1; archivo="${base}${pkg}_$(date "+%s").log"; 
	printf "[$(getT)] ${VER}%s ${CIA}---> Instalando %s...${RST}\n" "$2" "$pkg"
	if sudo apt-get install -y "$pkg" | tee -a "$archivo" 2>&1; then
		printf "[$(getT)] ${VER}%s ${VER}[INF][Instalado] %s${RST}\n" "$2" "$pkg"
	else
		printf "[$(getT)] ${VER}%s ${ROJ}[ERR][  Fallo  ] Falló %s. Ver: %s${RST}\n" "$2" "$pkg" "$archivo"
	fi; }
rstRepo(){
	printf "${ROJ}%s${RST}\n" "$(cat /etc/apt/sources.list)"
	sleep 5
	clear
	cp /etc/apt/sources.list "${bkp}sources.list_$(getTSE)"
	sudo sh -c "cat > /etc/apt/sources.list" << EOF
#
#
# +----> Repositorio de Debian 12 (Bookworm) en debian.csail.mit.edu
# Este espejo pertenece al MIT (Massachusetts Institute of Technology), 
# específicamente al laboratorio CSAIL (Computer Science and Artificial Intelligence Laboratory).
# Es una opción confiable y de alto rendimiento, especialmente para usuarios en América del Norte.
deb https://debian.csail.mit.edu/debian/ bookworm main contrib non-free
deb-src https://debian.csail.mit.edu/debian/ bookworm main contrib non-free
# Repositorio de seguridad de Debian 12 en debian.csail.mit.edu
# Este es el repositorio que contiene las actualizaciones de seguridad para Debian 12 desde MIT.
deb https://debian.csail.mit.edu/debian-security/ bookworm-security main contrib non-free
deb-src https://debian.csail.mit.edu/debian-security/ bookworm-security main contrib non-free
# Repositorio de actualizaciones en debian.csail.mit.edu
# Este espejo también contiene actualizaciones regulares para paquetes de Debian.
deb https://debian.csail.mit.edu/debian/ bookworm-updates main contrib non-free
deb-src https://debian.csail.mit.edu/debian/ bookworm-updates main contrib non-free
#
#
# +----> Repositorio de Debian 12 (Bookworm) en mirrors.ocf.berkeley.edu
# Este espejo pertenece a la organización estudiantil OCF de la Universidad de Berkeley.
# Es un servidor confiable y rápido para descargar paquetes y actualizaciones.
deb https://mirrors.ocf.berkeley.edu/debian/ bookworm main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian/ bookworm main contrib non-free
# Repositorio de seguridad de Debian 12 en mirrors.ocf.berkeley.edu
# Este repositorio contiene las actualizaciones de seguridad para Debian 12.
deb https://mirrors.ocf.berkeley.edu/debian-security/ bookworm-security main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian-security/ bookworm-security main contrib non-free
# Repositorio de actualizaciones en mirrors.ocf.berkeley.edu
# Este espejo también contiene actualizaciones regulares para paquetes de Debian.
deb https://mirrors.ocf.berkeley.edu/debian/ bookworm-updates main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian/ bookworm-updates main contrib non-free
#
#
EOF
clear
printf "${MAG}%s${RST}\n" "$(cat /etc/apt/sources.list)"
sleep 5
clear
printf "[$(getT)] ${CIA}\n"
}
main(){
	clear
	mkdir -p "$base" "$bkp"
	printf "[$(getT)] ${VER}${CIA}Actualizando repositorios...${RST}\n"
#	sudo apt-get update -y >/dev/null 2>&1
#	rstRepo
#	sudo apt-get update | tee -a "${base}upd-$(getT).log"
#	sudo apt-get upgrade -y | tee -a "${base}upg-$(getT).log"
	# Calcular total de paquetes y preparar contadores
	total_pkgs=0
	for p in $pkgs; do total_pkgs=$((total_pkgs + 1)); done
	actual=0
	for pkg in $pkgs; do
		sync
		actual=$((actual + 1))
		porcentaje=$(( (actual * 100) / total_pkgs ))
		
		# Construcción manual de barra de progreso fija de 10 caracteres [=====-----]
		num_barras=$(( porcentaje / 10 ))
		num_guiones=$(( 10 - num_barras ))
		barra=""
		i=0; while [ $i -lt $num_barras ]; do barra="${barra}+"; i=$((i+1)); done
		i=0; while [ $i -lt $num_guiones ]; do barra="${barra}-"; i=$((i+1)); done
		
		# Prefijo de progreso estandarizado: [45% 52/115] [====------]
		progreso_str="[${barra}][${porcentaje}%][${actual}/${total_pkgs}]"
		if check_instalado "$pkg"; then		# 1. Verificar instalado
			printf "${AMA}[$(getT)] ${VER}%s ${NAR}[INF][Instalado] %s${RST}\n" "$progreso_str" "$pkg"
			continue
		fi
		if ! check_repositorio "$pkg"; then	# 2. Verificar existencia en repositorio
			printf "${MAG}[$(getT)] ${VER}%s ${AMA}[ADV][No Existe] %s${RST}\n" "$progreso_str" "$pkg"
			continue
		fi
		ejecutar_instalacion "$pkg" "$progreso_str"		# 3. Instalar
	done; sync; }
getT(){ date '+%Y-%m-%d %H:%M:%S'; }
hacer(){
	cp -rfv ./.img/+img.png /usr/share/backgrounds/
	crpt="/home/usuario/AppON/"
	mkdir -p "$crpt"
	lta='
	cnf.zip
	jd.zip
	twic1647g.zip
	twic1648g.zip
	twic1649g.zip
	twic1650g.zip
	wifi_driver.zip
	'
	for arch in $lta;do
	printf "${AMA}[$(getT)]\n"
	sudo unzip -o "./.zip/${arch}" -d "$crpt"
	done
	crpt="/home/usuario/.config/"
	mkdir -p "$crpt"
	lta='
	xfce4.zip
	yt-dlp.zip
	'
	for arch in $lta;do
	printf "${VER}[$(getT)]\n"
	sudo unzip -o "./.zip/${arch}" -d "$crpt"
	done
	printf "${ROJ}[$(getT)]\n"
	sudo wget https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -O /usr/local/bin/yt-dlp
	sudo chmod a+rx /usr/local/bin/yt-dlp
	sudo yt-dlp -U
	printf "${CIA}[$(getT)]\n"
	cd /home/usuario/AppON/+wifi/
	sudo dkms install ./rtl8188fu	
	sudo sh ./.sh/.iptable.sh
	sudo chmod -R a+rwX /home/usuario/
}
# PPA
echo "--- SCRITP INICIO ---"
main
#hacer
#mkdir -p "$base" "$bkp"
#ejecutar_instalacion
echo "--- SCRITP FIN    ---"
exit 0
