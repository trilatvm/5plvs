#!/bin/sh
# ==============================================================================
# DETECCIÓN DE DEPENDENCIAS CRÍTICAS
# ==============================================================================
if ! command -v ffmpeg >/dev/null 2>&1 || ! command -v ffprobe >/dev/null 2>&1; then
	printf "\033[1;31m[ERROR] Se requieren 'ffmpeg' y 'ffprobe' instalados en el sistema.\033[0m\n"
	exit 1
fi
# ==============================================================================
# VARIABLES GLOBALES Y CONTROL DE CTRL+C
# ==============================================================================
inicioTotal=$(date +%s)
finalizarLimpio() {
	printf "\n\n\033[1;35m+-+-+ \033[1;36m+++ \033[1;32m*** \033[1;33m[!] VIAJE INTERRUMPIDO POR EL USUARIO. ¡HASTA LUEGO! \033[1;31m*** \033[1;34m+++ \033[1;35m+-+-+\033[0m\n"
	exit 0
}
trap finalizarLimpio INT
# ==============================================================================
# PALETA DE COLORES ANSI ESTÁNDAR
# ==============================================================================
colorRojo="1;31"
colorVerde="1;32"
colorAmarillo="1;33"
colorAzul="1;34"
colorRosa="1;35"
colorCian="1;36"
imprimirColor() {
	printf "\033[%sm%s\033[0m\n" "$1" "$2"
}
# ==============================================================================
# SANITIZACIÓN DE NOMBRES DE ARCHIVO
# ==============================================================================
sanitizarNombreArchivo() {
	nombreOriginal=$1
	extensionOriginal=$2
	nombreProcesado=$(printf "%s" "$nombreOriginal" | sed 's/[-_]/./g')
	nombreProcesado=$(printf "%s" "$nombreProcesado" | sed 's/ //g' | sed 's/[^a-zA-Z0-9.]//g')
	printf "%s.%s" "$nombreProcesado" "$extensionOriginal"
}
# ==============================================================================
# BARRA DE PROGRESO RECURSIVA CON ASCII PURO
# ==============================================================================
renderizarBarraProgreso() {
	porcentajeActual=$1
	colorFila=$2
	[ "$porcentajeActual" -gt 100 ] && porcentajeActual=100
	bloquesLlenos=$(expr $porcentajeActual / 5)
	bloquesVacios=$(expr 20 - $bloquesLlenos)
	barraVisual=""
	i=0; while [ $i -lt $bloquesLlenos ]; do barraVisual="${barraVisual}#"; i=$(expr $i + 1); done
	i=0; while [ $i -lt $bloquesVacios ]; do barraVisual="${barraVisual}-"; i=$(expr $i + 1); done
	ahora=$(date +%s)
	tiempoLote=$(expr $ahora - $inicioTotal)
	printf "\033[%smProgress: [%s] %d%% | Total run: %ds\r\033[0m" "$colorFila" "$barraVisual" "$porcentajeActual" "$tiempoLote"
}
# ==============================================================================
# MOTOR DE CONVERSIÓN CON VALIDACIÓN DE SALIDA
# ==============================================================================
ejecutarConversion() {
	archivoOrigen=$1
	formatoDestino=$2
	directorioDestino=$3
	colorFila=$4
	nombreBaseSinExt=$(basename "$archivoOrigen" | sed 's/\.[^.]*$//')
	extensionOrigen=$(printf "%s" "$archivoOrigen" | awk -F. '{print tolower($NF)}')
	nombreSalidaLimpio=$(sanitizarNombreArchivo "$nombreBaseSinExt" "$formatoDestino")
	archivoDestino="$directorioDestino/$nombreSalidaLimpio"
	printf "\n"
	imprimirColor "$colorFila" "********************************************************"
	printf "\033[%sm[ENTRADA]\033[0m %s\n" "$colorCian" "$(basename "$archivoOrigen")"
	printf "\033[%sm[SALIDA]\033[0m  %s\n" "$colorRosa" "$nombreSalidaLimpio"
	duracionTotal=$(ffprobe -v error -show_entries format=duration -of default=noprint_wrappers=1:nocov=1 "$archivoOrigen" | sed 's/\.[^.]*$//' | awk '{print int($1)}')
	[ -z "$duracionTotal" ] || [ "$duracionTotal" -le 0 ] && duracionTotal=1
	if [ "$formatoDestino" = "flac" ]; then
		argumentosAudio="-c:a flac -compression_level 5"
	else
		argumentosAudio="-c:a libmp3lame -q:a 0"
	fi
	ffmpeg -y -i "$archivoOrigen" $argumentosAudio "$archivoDestino" 2>&1 | (
		while read -r lineaLog; do
			case "$lineaLog" in
				*time=*)
					tiempoParcial=$(printf "%s" "$lineaLog" | sed 's/.*time=\([^ ]*\).*/\1/' | awk -F: '{print ($1*3600)+($2*60)+$3}' | sed 's/\.[^.]*$//' | awk '{print int($1)}')
					if [ ! -z "$tiempoParcial" ]; then
						porcentajeCalculado=$(expr $tiempoParcial \* 100 / $duracionTotal)
						renderizarBarraProgreso "$porcentajeCalculado" "$colorFila"
					fi
					;;
			esac
		done
		renderizarBarraProgreso 100 "$colorFila"
	)
	printf "\n"
	if [ -f "$archivoDestino" ] && [ -s "$archivoDestino" ]; then
		imprimirColor "$colorVerde" "+++ PROCESADO CON EXITO EN ONDAS MULTICOLORES +++"
	else
		imprimirColor "$colorRojo" "[!] ERROR CRÍTICO: Ffmpeg no pudo generar el archivo de salida."
	fi
}
# ==============================================================================
# GESTIÓN DE LOTES CONTINUOS Y RESILIENCIA ANTE NEGLIGENCIAS
# ==============================================================================
procesarLotePsicodelico() {
	printf "\n"
	imprimirColor "$colorRosa" "========================================================"
	# 1. Validación estricta del Directorio Origen
	printf "\033[%sm>>> INGRESE DIRECTORIO ORIGEN:\033[0m " "$colorCian"
	read -r directorioOrigen
	if [ -z "$directorioOrigen" ]; then
		imprimirColor "$colorRojo" "[!] ERROR: No ingresaste ninguna ruta de origen."
		return
	fi
	if [ ! -d "$directorioOrigen" ]; then
		imprimirColor "$colorRojo" "[!] ERROR: El origen especificado no existe o no es una carpeta."
		return
	fi
	if [ ! -r "$directorioOrigen" ] || [ ! -x "$directorioOrigen" ]; then
		imprimirColor "$colorRojo" "[!] ERROR DE PERMISOS: No tenés privilegios de lectura/ejecución en el origen."
		return
	fi
	# 2. Validación y creación segura del Directorio Destino
	printf "\033[%sm>>> INGRESE DIRECTORIO DESTINO:\033[0m " "$colorAmarillo"
	read -r directorioDestino
	if [ -z "$directorioDestino" ]; then
		imprimirColor "$colorRojo" "[!] ERROR: No ingresaste ninguna ruta de destino."
		return
	fi
	if [ ! -d "$directorioDestino" ]; then
		# Intentar verificar si el directorio base (padre) permite escritura antes de hacer mkdir
		directorioPadre=$(dirname "$directorioDestino")
		if [ ! -w "$directorioPadre" ]; then
			imprimirColor "$colorRojo" "[!] ERROR DE PERMISOS: No podés crear carpetas en el directorio base: $directorioPadre"
			return
		fi
		
		imprimirColor "$colorAmarillo" "[*] El destino no existe. Creando directorio de forma segura..."
		mkdir -p "$directorioDestino" >/dev/null 2>&1
	fi
	if [ ! -w "$directorioDestino" ]; then
		imprimirColor "$colorRojo" "[!] ERROR DE PERMISOS: La carpeta de destino existe pero NO tenés permisos de escritura."
		return
	fi
	# 3. Selección de formato
	printf "\n\033[%sm*** ELIGE TU DESTINO AUDITIVO ***\033[0m\n" "$colorVerde"
	printf " \033[1;36m1)\033[0m FLAC NATIVO SIN PERDIDAS \n"
	printf " \033[1;35m2)\033[0m MP3 PSICODELICO VBR INTELIGENTE \n"
	printf "Escribe (1 o 2): "
	read -r opcionFormato
	case "$opcionFormato" in
		1) formatoElegido="flac" ;;
		2) formatoElegido="mp3" ;;
		*) imprimirColor "$colorRojo" "[!] OPCION INVALIDA EN EL ESPACIO."; return ;;
	esac
	imprimirColor "$colorAzul" ">>> VALIDACIÓN EXITOSA. INICIANDO PROCESAMIENTO..."
	contadorConvertidos=0
	for archivoFila in "$directorioOrigen"/*; do
		# Si la carpeta está vacía, evita procesar el comodín literal '*'
		[ -f "$archivoFila" ] || continue
		
		# Verificar que el archivo de audio actual sea legible por el usuario
		if [ ! -r "$archivoFila" ]; then
			imprimirColor "$colorRojo" "[!] Saltando archivo (Sin permisos de lectura): $(basename "$archivoFila")"
			continue
		fi
		
		case "$archivoFila" in
			*.wav|*.WAV|*.mp3|*.MP3|*.m4a|*.M4A|*.aac|*.AAC|*.flac|*.FLAC|*.ogg|*.OGG|*.wma|*.WMA)
				restoColor=$(expr $contadorConvertidos % 4)
				case "$restoColor" in
					0) colorActual="$colorRosa" ;;
					1) colorActual="$colorCian" ;;
					2) colorActual="$colorAmarillo" ;;
					3) colorActual="$colorAzul" ;;
				esac
				
				ejecutarConversion "$archivoFila" "$formatoElegido" "$directorioDestino" "$colorActual"
				contadorConvertidos=$(expr $contadorConvertidos + 1)
				;;
		esac
	done
	printf "\n"
	imprimirColor "$colorVerde" "========================================================"
	printf "\033[%smPROCESO COMPLETADO. %d ARCHIVOS SALVADOS EN:\033[0m %s\n" "$colorAmarillo" "$contadorConvertidos" "$directorioDestino"
	imprimirColor "$colorVerde" "========================================================"
}
# ==============================================================================
# INICIO DE ENTORNO
# ==============================================================================
clear
imprimirColor "1;35" " ******************************************************** "
imprimirColor "1;36" " *   AUDIO TRANSLATOR SYSTEM - BULLETPROOF RETRO SH	 * "
imprimirColor "1;32" " ******************************************************** "
while :; do
	procesarLotePsicodelico
done
exit 0
