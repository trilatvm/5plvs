#!/bin/sh

# ==============================================================================
# CONFIGURACIÓN PERSONALIZABLE (MODIFICA AQUÍ EN SEGUNDOS)
# ==============================================================================
scriptBuscado=".des.sh"       # Nombre del script a ejecutar en cada carpeta
tiempoEjecucion=180           # Tiempo límite de ejecución en SEGUNDOS (ej: 600 = 10 min)
tiempoDelay=3                 # Tiempo de espera entre carpetas en SEGUNDOS

# ==============================================================================
# CONFIGURACIÓN Y VARIABLES GLOBALES DEL SISTEMA
# ==============================================================================
inicioTotal=$(date +%s)
vueltasCompletadas=0
totalCarpetas=$(find . -mindepth 1 -maxdepth 1 -type d | wc -l)

# ==============================================================================
# MANEJO DE INTERRUPCIONES (CONTROL CTRL+C)
# ==============================================================================
finalizarProcesoLimpio() {
    calcularTiempoTranscurrido
    printf "\n\n\033[1;31m[!] Proceso interrumpido por el usuario.\033[0m\n"
    printf "\033[1;32m[ESTADÍSTICAS FINALES]\033[0m\n"
    printf "-> Tiempo total de ejecución: %02dh:%02dm:%02ds\n" "$horas" "$minutos" "$segundos"
    printf "-> Ciclos/Vueltas completadas: %d\n" "$vueltasCompletadas"
    exit 0
}

# Captura Ctrl+C (SIGINT)
trap finalizarProcesoLimpio INT

# ==============================================================================
# FUNCIONES AUXILIARES Y DE CÁLCULO
# ==============================================================================
calcularTiempoTranscurrido() {
    ahora=$(date +%s)
    diferenciaTiempo=$(expr $ahora - $inicioTotal)
    
    horas=$(expr $diferenciaTiempo / 3600)
    restoSegundos=$(expr $diferenciaTiempo % 3600)
    minutos=$(expr $restoSegundos / 60)
    segundos=$(expr $restoSegundos % 60)
}

# ==============================================================================
# RENDERIZADO E IMPRESIÓN (HERENCIA FUNCIONAL Y RECURSIVIDAD)
# ==============================================================================
imprimirEnColor() {
    codigoColor=$1
    mensajeTexto=$2
    printf "\033[%sm%s\033[0m\n" "$codigoColor" "$mensajeTexto"
}

imprimirMensajeInformativo() {
    imprimirEnColor "1;33" "$1"
}

imprimirMensajeExito() {
    imprimirEnColor "1;32" "$1"
}

# Función RECURSIVA para la barra de estado dinámica según el delay en segundos
dibujarBarraProgreso() {
    segundosRestantes=$1
    
    # Condición de parada de la recursividad
    [ "$segundosRestantes" -lt 0 ] && return
    
    # Cálculo porcentual de bloques llenos y vacíos (máximo de 20 caracteres en barra)
    if [ "$tiempoDelay" -gt 0 ]; then
        bloquesLlenos=$(expr \( $tiempoDelay - $segundosRestantes \) \* 20 / $tiempoDelay)
    else
        bloquesLlenos=20
    fi
    
    bloquesVacios=$(expr 20 - $bloquesLlenos)
    
    # Construcción iterativa de la línea de la barra
    barraVisual=""
    i=0
    while [ $i -lt $bloquesLlenos ]; do
        barraVisual="${barraVisual}█"
        i=$(expr $i + 1)
    done
    i=0
    while [ $i -lt $bloquesVacios ]; do
        barraVisual="${barraVisual}░"
        i=$(expr $i + 1)
    done
    
    # Imprime usando retorno de carro '\r'
    printf "\033[1;33mSiguiente carpeta en: [%s] %ds\r\033[0m" "$barraVisual" "$segundosRestantes"
    
    if [ "$segundosRestantes" -gt 0 ]; then
        sleep 1
        # Llamada recursiva decremental
        dibujarBarraProgreso $(expr $segundosRestantes - 1)
    else
        printf "\n\n"
    fi
}

mostrarCabezal() {
    carpetaActual=$1
    nombreDirectorio=$2
    
    imprimirMensajeInformativo "========================================================================"
    imprimirMensajeInformativo "[Carpeta $carpetaActual/$totalCarpetas de la Vuelta #$vueltasCompletadas] -> Entrando a: $nombreDirectorio"
    imprimirMensajeInformativo "========================================================================"
}

mostrarProgresoYEspera() {
    calcularTiempoTranscurrido
    printf "\n"
    imprimirMensajeInformativo "[REPORTE] Tiempo total acumulado: $(printf "%02dh:%02dm:%02ds" $horas $minutos $segundos) | Vueltas completadas: $vueltasCompletadas"
    
    dibujarBarraProgreso "$tiempoDelay"
}

# ==============================================================================
# LÓGICA DE CONTROL DEL CICLO
# ==============================================================================
procesarCicloCarpetas() {
    contadorCarpetas=0
    
    for miDirectorio in */; do
        [ -d "$miDirectorio" ] || continue
        
        contadorCarpetas=$(expr $contadorCarpetas + 1)
        mostrarCabezal "$contadorCarpetas" "$miDirectorio"
        
        cd "$miDirectorio"
        if [ -f "$scriptBuscado" ]; then
            chmod +x "$scriptBuscado"
            
            # Envia 3 ENTERs (\n\n\n) por pipe directamente a la entrada del proceso
            printf "\n\n\n" | timeout -k 10s "${tiempoEjecucion}s" "./$scriptBuscado"
            
        else
            imprimirMensajeInformativo "Aviso: No se encontró $scriptBuscado en este directorio"
        fi
        cd ..
        
        mostrarProgresoYEspera
    done
}

# ==============================================================================
# FLUJO PRINCIPAL
# ==============================================================================
while :; do
    procesarCicloCarpetas
    
    vueltasCompletadas=$(expr $vueltasCompletadas + 1)
    imprimirMensajeExito "¡Vuelta #$vueltasCompletadas completada con éxito! Reiniciando ciclo alfabético..."
    sleep 2
done
