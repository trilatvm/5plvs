#!/bin/sh
set -e
ROOT_ANARCHY="./prba"; ROOT_SYM="./prbaSim";
pow2() {
	n=$1
	r=1
	i=0
	while [ $i -lt $n ]; do
		r=$((r * 2))
		i=$((i + 1))
	done
	echo "$r"
}
gen_file_sym() {	# ARCHIVO SIMÉTRICO (potencias de 2 KB)
	file=$1
	# Exponentes posibles: 5..10 → 2^5 KB = 32 KB, 2^6 KB = 64 KB ... 2^10 KB = 1024 KB
#	exp=$(rand_range 5 10)
# ------------
#	exp=$(rand_range 16 32)
#	size=$(( 2 ** exp * 1024 ))  # tamaño en bytes
# ------------
	exp=$(rand_range 1 8)
	size=$(( $(pow2 "$exp") * 1024 ))
#	dd if=/dev/urandom of="$file" bs=1 count="$size" status=none
	dd if=/dev/urandom of="$file" bs=1 count="$size" status=progress conv=fdatasync
	imp "$size bytes $file"; }
imp() { clear; printf "[INF] %s\n" "$*"; } # imprimir en consola
rand_byte() { od -An -N1 -tu1 /dev/urandom | tr -d ' ';} # RANDOM BYTE (0-255)
rand_range() {	# RANDOM RANGE
	min=$1
	max=$2
	n=$(od -An -N4 -tu4 /dev/urandom | tr -d ' ')
	echo $(( n % (max - min + 1) + min )); }
rand_name() {	# NOMBRE RANDOM SEGURO
	len=$(rand_range 5 12)
	tr -dc 'A-Za-z0-9._-' < /dev/urandom | head -c "$len"; }
gen_file_anarchy() {	# ARCHIVO ANÁRQUICO (0 - 1MB)
	file=$1
	size=$(rand_range 1024 1048576) # bytes
	head -c "$size" /dev/urandom > "$file"
	imp "ANARCHY $file ($size bytes)"; }
crearDir() {	# LIMPIAR
	rm -rf "$ROOT_ANARCHY" "$ROOT_SYM"
	mkdir -p "$ROOT_ANARCHY" "$ROOT_SYM"; }
crearAleatorio() {	# ESTRUCTURA ANÁRQUICA (TOTALMENTE RANDOM)
	i=0
	while [ $i -lt 3 ]; do
		d1="$ROOT_ANARCHY/$(rand_name)"
		mkdir -p "$d1"
		j=0
		while [ $j -lt $(rand_range 3 7) ]; do
			d2="$d1/$(rand_name)"
			mkdir -p "$d2"
			k=0
			while [ $k -lt $(rand_range 2 6) ]; do
				gen_file_anarchy "$d2/$(rand_name).bin"
				k=$((k + 1))
			done
			j=$((j + 1))
		done
		i=$((i + 1))
	done; }
crearSimetrico() {	# ESTRUCTURA SIMÉTRICA (FIJA)
	i=0
	while [ $i -lt 3 ]; do
		d1="$ROOT_SYM/$(($i + 100)) datos"
		mkdir -p "$d1"
		j=0
		while [ $j -lt 5 ]; do
			d2="$d1/$(($j + 100)) datos"
			mkdir -p "$d2"
			k=0
			while [ $k -lt 7 ]; do
#				gen_file_sym "$d2/file_${k}.bin"
				gen_file_sym "$d2/$(($k + 100)) datos.bin"
				k=$((k + 1))
			done
			j=$((j + 1))
		done
		i=$((i + 1))
	done; }
main() {
	imp "--- INICIO ---"
	crearDir
	crearAleatorio
	crearSimetrico
	imp "--- FIN	---"; }
main	# PPA
exit 0