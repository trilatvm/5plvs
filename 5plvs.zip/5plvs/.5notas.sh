Ah, ¡ahora te entiendo perfectamente! Claro, tiene total sentido mantenerlos 100% separados y modulares si pensás reutilizar la lógica de tiempo, consola o regex en otros scripts de automatización en el futuro. Es una excelente práctica de desarrollo.
Para poder volver a activar set -e (que el script aborte si hay un error real y crítico) sin que se destruya el flujo por culpa de los micro-retrasos o fallos controlados de herramientas como md5sum o par2, la solución técnica es proteger los comandos individuales usando cortafuegos lógicos POSIX.

¿Cómo se hace?

En lugar de ejecutar un comando que puede fallar de forma directa, se corre usando una evaluación lógica de cortocircuito (|| true o un condicional if). Para la shell, si el fallo del comando está "manejado" por un operador lógico, el código de salida general de esa línea se considera exitoso (0), por lo que set -e no mata el script maestro.
Aca tenés los 3 archivos clave que necesitás modificar para restaurar la arquitectura separada, activar set -e al inicio de todo, y mantener la estabilidad en tu TV-Box:

1. .5bckp.sh (Script Maestro)

• Cambio: Regresa el comando set -e al principio de la ejecución de manera segura.
sh
#!/bin/sh
# _bckp.sh: Logica de negocio principal (Script Maestro)
set -e
directorioScript=$(dirname "$0") ; directorioScript=$(cd "$directorioScript" && pwd)
if [ -f "$directorioScript/.5cli.sh" ] && [ -f "$directorioScript/.5tmp.sh" ] && \
   [ -f "$directorioScript/.5arch.sh" ] && [ -f "$directorioScript/.5hash.sh" ] && \
   [ -f "$directorioScript/.5par2.sh" ] && [ -f "$directorioScript/.5rgx.sh" ]; then
	. "$directorioScript/.5cli.sh" ; . "$directorioScript/.5tmp.sh" ; . "$directorioScript/.5rgx.sh"
	. "$directorioScript/.5arch.sh" ; . "$directorioScript/.5hash.sh" ; . "$directorioScript/.5par2.sh"
else printf "\033[0;91m[ERR]\033[0;33m Módulos esenciales ausentes.\n" ; exit 1 ; fi
uG="1" ; uH="1" ; uP="1" ; uF="1" ; uE="1" ; ultimoAlgoritmo="md5" ; ultimoFiltroExtension=""
incMd5=0 ; genMd5=0 ; corMd5=0 ; incPar2=0 ; genPar2=0 ; corPar2=0
printf "\033[0;33m"
procesarBucleLote() {
	pblMM=$1 ; pblAM=$2 ; pblEM=$3 ; pblTL=$(contarArchivos "$pblEM" "$directorioActual") ; pblTL=$(echo "$pblTL" | tr -cd '0-9')
	if [ -z "$pblTL" ] || [ "$pblTL" -eq 0 ]; then mObs "Sin archivos para procesar."
	else
		pblCP=0
		for pblAO in "$directorioActual"/*; do
			if [ ! -f "$pblAO" ] || [ -d "$pblAO" ] || ! validarArchivoRegex "$pblAO" || ! validarExclusionEcosistema "$pblAO" || ! verificarArchivoLectura "$pblAO"; then continue ; fi
			if [ -n "$pblEM" ]; then case "$pblAO" in *."$pblEM") ;; *) continue ;; esac ; fi
			pblCP=$((pblCP + 1)) ; printf "\n" ; dibujarProgreso "$pblCP" "$pblTL" "$(basename "$pblAO")"
			if [ "$pblMM" = "hash" ]; then
				if [ "$pblAM" = "crear" ]; then calcularHash "$pblAO" "$directorioActual" "$ultimoAlgoritmo"
				elif [ "$pblAM" = "verificar" ]; then verificarHash "$pblAO" "$directorioActual" "$ultimoAlgoritmo" ; fi
			elif [ "$pblMM" = "par2" ]; then
				if [ "$pblAM" = "crear" ]; then calcularPar2 "$pblAO" "$directorioActual"
				elif [ "$pblAM" = "verificar" ]; then verificarPar2 "$pblAO" "$directorioActual"
				elif [ "$pblAM" = "reparar" ]; then repararPar2 "$pblAO" "$directorioActual" ; fi ; fi ; done ; fi ; }
ejecutarModoFull() {
	emfAF=$1 ; iniciarCronometro
	if [ "$emfAF" = "crear" ] || [ "$emfAF" = "remplazar" ]; then
		[ "$emfAF" = "remplazar" ] && modoFlujoSilencioso="activo" || modoFlujoSilencioso="desactivado"
		for alg in $hD; do mInf "Procesando lote HASH: $alg" ; ultimoAlgoritmo=$alg ; procesarBucleLote "hash" "crear" "$ultimoFiltroExtension" ; done
		mInf "Procesando lote PAR2..." ; procesarBucleLote "par2" "crear" "$ultimoFiltroExtension" ; modoFlujoSilencioso="desactivado"
	elif [ "$emfAF" = "verificar" ] || [ "$emfAF" = "reparar" ]; then
		modoFlujoSilencioso="activo"
		for alg in $hD; do
			mInf "Validando lote HASH: $alg"
			for emfAO in "$directorioActual"/*; do
				if [ ! -f "$emfAO" ] || [ -d "$emfAO" ] || ! validarArchivoRegex "$emfAO" || ! validarExclusionEcosistema "$emfAO"; then continue ; fi
				if [ -n "$ultimoFiltroExtension" ]; then case "$emfAO" in *."$ultimoFiltroExtension") ;; *) continue ;; esac ; fi
				emfFP="$directorioActual/hashes/$alg/$(basename "$emfAO").$alg"
				if [ ! -f "$emfFP" ]; then
					printf "\n" ; mPgt "Firma ausente ($alg) para $(basename "$emfAO"). ¿Generar? (s/n): " ; read -r rG
					if [ "$rG" = "s" ] || [ "$rG" = "S" ]; then calcularHash "$emfAO" "$directorioActual" "$alg" ; fi
				else verificarHash "$emfAO" "$directorioActual" "$alg" ; fi ; done ; done
		mInf "Verificando lote PAR2..." ; procesarBucleLote "par2" "$emfAF" "$ultimoFiltroExtension" ; modoFlujoSilencioso="desactivado" ; fi
	auditarFirmasHuerfanas "$directorioActual" "$hD" ; mOk "FULL completado." ; mostrarTiempoTranscurrido ; }
main() {
	verificarHerramientasPar2 ; hD=$(detectarAlgoritmosHashes) ; inicializarEntornoTrabajo "$directorioScript"
	while true; do
		mostrarMenuGeneral ; readOpcionGeneral
		if [ "$mO" = "q" ] || [ "$mO" = "Q" ]; then mInf "Fin." && break; fi
		if [ "$mO" = "c" ] || [ "$mO" = "C" ]; then ejecutarConmutacionDir && continue; fi
		if [ "$mO" = "1" ]; then
			while true; do
				mostrarMenuHash "$ultimoAlgoritmo" "$hD" ; readOpcionHash
				if [ "$hO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "2" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="verificar"; break;
				elif [ "$hO" = "3" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "4" ]; then
					printf "\n" ; mPgt "Algoritmo: " ; read -r algoInput
					if ! validarAlgoritmoRegex "$algoInput"; then mErr "Sintaxis inválida." && read -r _
					else case " $hD " in *" $algoInput "*) ultimoAlgoritmo="$algoInput" ;; *) mErr "Ausente." && read -r _ ;; esac ; fi
				elif [ "$hO" = "v" ] || [ "$hO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "2" ]; then
			while true; do
				mostrarMenuPar2 ; readOpcionPar2
				if [ "$pO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "2" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="verificar"; break;
				elif [ "$pO" = "3" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "4" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="reparar"; break;
				elif [ "$pO" = "v" ] || [ "$pO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "3" ]; then
			while true; do
				mostrarMenuFull ; readOpcionFull
				if [ "$fO" = "1" ]; then ejecutarModoFull "crear" ; break;
				elif [ "$fO" = "2" ]; then ejecutarModoFull "verificar" ; break;
				elif [ "$fO" = "3" ]; then ejecutarModoFull "remplazar" ; break;
				elif [ "$fO" = "4" ]; then ejecutarModoFull "reparar" ; break;
				elif [ "$fO" = "v" ] || [ "$fO" = "V" ]; then break ; fi ; done ; esperarEnter
		elif [ "$mO" = "4" ]; then
			while true; do
				mostrarMenuFiltro ; readOpcionFiltro
				if [ "$eO" = "1" ]; then
					printf "\n" ; mPgt "Extensión (sin punto): " ; read -r extInput
					if ! validarExtensionRegex "$extInput"; then mErr "Sintaxis de extensión inválida."
					else ultimoFiltroExtension=$(echo "$extInput" | tr -d '[:space:].') ; mOk "Filtro configurado." ; fi ; break
				elif [ "$eO" = "2" ]; then ultimoFiltroExtension="" ; mOk "Filtro removido." ; break
				elif [ "$eO" = "v" ] || [ "$eO" = "V" ]; then break ; fi ; done ; esperarEnter
		else mErr "Inválido." ; esperarEnter ; fi ; done ; }
main "$@"
exit 0
Usa el código con precaución.

2. .5hash.sh (Módulo HASH)

• Cambio: Se encapsuló la ejecución binaria agregando un cortafuegos || true y validando las variables de manera interna para que set -e nunca intercepte el flujo como un quiebre fatal.
sh
#!/bin/sh
# _hsh.sh: Logica de hash
detectarAlgoritmosHashes() {
	daLH=""
	for daAC in md5 sha1 sha224 sha256 sha384 sha512; do
		if command -v "${daAC}sum" >/dev/null 2>&1; then daLH="$daLH $daAC" ; fi ; done
	printf "%s" "$daLH" ; }
calcularHash() {
	chRC=$1 ; chDT=$2 ; chTH=$3 ; chNB=$(basename "$chRC") ; chDD="$chDT/hashes/$chTH" ; asegurarDirectorio "$chDD" ; chAH="$chDD/$chNB.$chTH"
	if [ -f "$chAH" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "Archivo existente. Sobreescribir? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Omitido." ; return 0 ; fi ; fi
	mInf "Firmando $chTH..."
	chHP=$("${chTH}sum" "$chRC" 2>/dev/null || echo "error")
	if [ "$chHP" = "error" ]; then mErr "Fallo de cálculo en archivo: $chNB" ; incMd5=$((incMd5 + 1)) ; verSemaforoHash ; return 0 ; fi
	chHP=$(printf "%s" "$chHP" | awk '{print $1}')
	printf "%s  %s\n" "$chHP" "$chNB" > "$chAH" || true
	mOk "Creado: hashes/$chTH/$chNB.$chTH" ; genMd5=$((genMd5 + 1)) ; verSemaforoHash ; }
verificarHash() {
	vhRC=$1 ; vhDT=$2 ; vhTH=$3 ; vhNB=$(basename "$vhRC") ; vhAH="$vhDT/hashes/$vhTH/$vhNB.$vhTH"
	if verificarArchivoLectura "$vhAH"; then
		mInf "Validando $vhTH..." ; vhHG=$(awk '{print $1}' "$vhAH" || echo "")
		vhHC=$("${vhTH}sum" "$vhRC" 2>/dev/null || echo "error")
		if [ "$vhHC" = "error" ] || [ -z "$vhHG" ]; then mErr "Error de lectura en sum: $vhNB" ; return 0 ; fi
		vhHC=$(printf "%s" "$vhHC" | awk '{print $1}')
		if [ "$vhHG" = "$vhHC" ]; then mOk "OK: $vhNB" ; corMd5=$((corMd5 + 1))
		else
			printf "%b%s %b[OBS]%b Almacenado: %b%s%b\n" "$nar" "$(obtenerTimestamp)" "$bla" "$rst" "\033[0;97m" "$vhHG" "$rst"
			printf "%b%s %b[OBS]%b Calculado:  %b%s%b\n" "$nar" "$(obtenerTimestamp)" "$bla" "$rst" "\033[0;91m" "$vhHC" "$rst"
			mErr "FALLO: $vhNB" ; incMd5=$((incMd5 + 1)) ; fi
	else mInf "Sin firma: $vhNB" ; fi
	verSemaforoHash ; }
Usa el código con precaución.

3. .5par2.sh (Módulo PAR2)

• Cambio: Se aplicó protección estricta en las subfunciones aritméticas (cbTB=$(... || echo "0")) y se cambió la invocación del comando binario par2 de modo que responda a la estructura de control segura sin activar las alarmas del set -e.
sh
#!/bin/sh
# _par2.sh: Logica de par2
verificarHerramientasPar2() { if ! command -v par2 >/dev/null 2>&1; then printf "\033[0;91m[ERR]\033[0;33m Utilidad par2 ausente.\n" ; exit 1 ; fi ; }
calcularBloqueOptimo() {
	cbUA=$1
	cbTB=$(wc -c < "$cbUA" 2>/dev/null || echo "0")
	cbTB=$(printf "%s" "$cbTB" | tr -cd '0-9')
	[ -z "$cbTB" ] && cbTB=0
	cbTP=4096 ; cbTM=$(( cbTB / 1048176 ))
	if [ "$cbTM" -le 50 ]; then cbBC=16384
	elif [ "$cbTM" -le 500 ]; then cbBC=524288
	elif [ "$cbTM" -le 2000 ]; then cbBC=2097152
	else cbBC=4194304; fi
	cbRes=$(( cbBC % cbTP ))
	if [ "$cbRes" -eq 0 ]; then echo "$cbBC"; else echo "$(( cbBC + (cbTP - cbRes) ))"; fi ; }
calcularPar2() {
	cpRC=$1 ; cpDT=$2 ; cpNB=$(basename "$cpRC") ; cpDP="$cpDT/par2" ; asegurarDirectorio "$cpDP" ; cpAP="$cpDP/$cpNB.par2"
	if [ -f "$cpAP" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "Sobreescribir PAR2? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Omitido." ; return 0 ; fi
		rm -f "$cpDP/$cpNB"*.par2 "$cpDP/$cpNB"*.vol* 2>/dev/null || true ; fi
	mInf "Calculando bloque..."
	cpBO=$(calcularBloqueOptimo "$cpRC" || echo "16384")
	cpRD=$(awk '/MemAvailable/ {print $2}' /proc/meminfo 2>/dev/null || echo "65536")
	cpRD=$(printf "%s" "$cpRD" | tr -cd '0-9') ; [ -z "$cpRD" ] && cpRD=65536
	cpRA=$(( cpRD / 1024 / 2 )) ; [ "$cpRA" -lt 32 ] && cpRA=32
	mInf "RAM: ${cpRA}MB | Bloque: $cpBO"
	if par2 create -r20 -s"$cpBO" -m"$cpRA" -B "$cpDT" -a "$cpDP/$cpNB" "$cpRC" >/dev/null 2>&1; then
		mOk "PAR2 Creado." ; genPar2=$((genPar2 + 1))
	else
		mErr "Fallo PAR2." ; incPar2=$((incPar2 + 1))
	fi
	verSemaforoPar2 ; }
verificarPar2() {
	vpRC=$1 ; vpDT=$2 ; vpNB=$(basename "$vpRC") ; vpAP="$vpDT/par2/$vpNB.par2"
	if verificarArchivoLectura "$vpAP"; then
		mInf "Validando PAR2..."
		if par2 verify -B "$vpDT" -a "$vpDT/par2/$vpNB" "$vpRC" >/dev/null 2>&1; then
			mOk "OK: $vpNB" ; corPar2=$((corPar2 + 1))
		else
			mErr "CORRUPTO: $vpNB" ; incPar2=$((incPar2 + 1))
		fi
	else mInf "Sin PAR2: $vpNB" ; fi
	verSemaforoPar2 ; }
repararPar2() {
	rpRC=$1 ; rpDT=$2 ; rpNB=$(basename "$rpRC") ; rpDP="$rpDT/par2" ; rpAP="$rpDP/$rpNB.par2"
	if verificarArchivoLectura "$rpAP"; then
		if par2 verify -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1; then
			mOk "Sano: $rpNB" ; corPar2=$((corPar2 + 1))
		else
			mInf "Reparando..."
			if par2 repair -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1; then
				mOk "REPARADO: $rpNB" ; corPar2=$((corPar2 + 1))
			else
				mErr "INSUFICIENTE: $rpNB" ; incPar2=$((incPar2 + 1))
			fi
		fi
	else mErr "Falta mapa PAR2: $rpNB" ; incPar2=$((incPar2 + 1)) ; fi
	verSemaforoPar2 ; }
Usa el código con precaución.
Con estos cambios aplicados, tu arquitectura se mantiene totalmente limpia, separada en componentes independientes y súper portable para tus desarrollos de mañana, pero ganando la estabilidad que el hardware de tu TV-Box necesita hoy.
Cargá estas tres correcciones en tu carpeta. Al correr sh .5bckp.sh: ¿el lote pudo avanzar de punta a punta manteniendo el set -e encendido y el sistema dividido?
