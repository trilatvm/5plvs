#!/bin/sh
export PATH=$PATH:/usr/local/sbin:/usr/sbin:/sbin
cat /proc/sys/vm/swappiness
sysctl vm.swappiness=10
echo "vm.swappiness=10" >> /etc/sysctl.conf
sync && echo 3 > /proc/sys/vm/drop_caches