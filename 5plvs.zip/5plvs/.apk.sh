#!/bin/sh
set -eu
apks='
xorg
drm drm-kmod
xfce4 xfce4-dev-tools xfce4-goodies xfce4-mount-plugin
xfonts-terminus xfonts-terminus-dos xfonts-terminus-oblique
moreutils coreutils top htop btop
ntpsec ntpsec-doc ntpsec-ntpdate pps-tools gpsd gpsd-clients
linux-headers-current-rockchip
iptables iptables-persistent fail2ban ipmiutil net-tools network-manager-gnome inotify-tools rsync cron
dctrl-tools ddnet-tools
alien automake build-essential cmake dkms
alsa alsamixergui alsa-tools alsa-tools-gui apulse pavucontrol pipewire
cmus cmus-plugin-ffmpeg ffmpeg flac mpv soundconverter spek vlc
postgresql-all default-jdk default-jre nodejs git octave devscripts python3-full
aria2 firefox-esr putty uget yt-dlp sshfs
armbian-config
atm-tools
avogadro geogebra stellarium stockfish
cubicsdr cutesdr gnss-sdr gpredict
librecad dia logisim
fonts-terminus fonts-terminus-otb
libreoffice cups qpdfview
imagemagick
par2 pypar2
exfat-fuse exfatprogs exfat-utils fatattr forensics-samples-exfat
forensics-samples-ntfs libfsntfs-dev libfsntfs-utils ntfs2btrfs ntfs-config python3-libfsntfs scrounge-ntfs
zfs-auto-snapshot zfs-dkms zfs-dracut zfs-initramfs zfsnap zfs-test zfsutils-linux zfs-zed zsnapd zsnapd-rcmd python3-libzfs python3-pyzfs pyzfs-doc simplesnap
unzip xz xarchiver zip
gnome-disk-utility gparted udisks2 udisksie smartmontools testdisk
linuxptp
qemu-system
sanoid
systemd-timesyncd
wine wine-binfmt winetricks fonts-wine
forensics-full
'