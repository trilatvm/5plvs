#!/bin/sh
set -e
# Asegura que el script termine limpiamente si el usuario presiona Ctrl+C
trap 'echo "\nMonitor detenido."; exit 0' INT TERM
# Códigos de color ANSI estáticos
ROJ="\033[0;31m"; NAR="\033[0;33m"; VER="\033[0;32m"; RST="\033[0m";
# Extensión inicial por defecto
EXT_ACTUAL="mkv"
# --- BUCLE PRINCIPAL DE MONITOREO ---
while true; do
	# --- SOLICITUD Y VALIDACIÓN DE LA EXTENSIÓN ---
	while true; do
	clear
	printf "Ingresar extensión [%s]: " "$EXT_ACTUAL"
		read -r EXT_INPUT
		# Si presiona Enter vacío, mantiene la última activa (o mkv la primera vez)
		if [ -z "$EXT_INPUT" ]; then
			break
		fi
		# Limpiar posibles espacios o puntos extras
		EXT_INPUT=$(echo "$EXT_INPUT" | tr -d ' .' 2>/dev/null)
		# Validar con Regex POSIX 'expr' (letras/números, 1-5 caracteres)
		if expr "$EXT_INPUT" : '^[a-zA-Z0-9]\{1,5\}$' >/dev/null 2>&1; then
			EXT_ACTUAL="$EXT_INPUT"
			break
		else
			printf "${ROJ}Error: Usa solo letras o números (1 a 5 caracteres) sin puntos.${RST}\n\n"
		fi
	done
	# Sub-bucle de monitoreo para la extensión seleccionada
	while true; do
		# Limpia la pantalla de forma segura y retrocompatible
		clear 2>/dev/null || printf "\033[2J\033[H"
	sync
		# Cabecera de la tabla
		printf "${ROJ}%-16s      %s${RST}\n" "FECHA" "NOMBRE DEL ARCHIVO"
		# Conteo global rápido
		TOTAL=$(find . -type f -name "*.$EXT_ACTUAL" 2>/dev/null | wc -l | tr -d ' ')
		[ -z "$TOTAL" ] && TOTAL=0
		i=0
		# Procesamiento robusto compatible con espacios en nombres
		find . -type f -name "*.$EXT_ACTUAL" 2>/dev/null | xargs ls -td 2>/dev/null | while read -r ruta; do
			[ "$i" -ge 7 ] && break
			[ -z "$ruta" ] && continue
			# Obtiene la fecha controlando variaciones Linux (date -r) y macOS/BSD (stat)
			fecha=$(date -r "$ruta" "+%Y-%m-%d %H:%M:%S" 2>/dev/null)
			[ -z "$fecha" ] && fecha=$(stat -f "%Sm" -t "%Y-%m-%d %H:%M" "$ruta" 2>/dev/null)
			[ -z "$fecha" ] && fecha="0000-00-00 00:00"
			nombre="${ruta##*/}"
			[ -z "$nombre" ] && continue
			nombre_corto=$(echo "$nombre" | cut -c1-39 2>/dev/null)
			if [ $((i % 2)) -eq 0 ]; then COLOR="$NAR"; else COLOR="$VER"; fi
			printf "${COLOR}%-16s   %s${RST}\n" "$fecha" "$nombre_corto"
			i=$((i + 1))
		done
		# Pie de interfaz
		printf "${ROJ}$(date "+%Y-%m-%d %H:%M:%S")   .%s = %s" "$EXT_ACTUAL" "$TOTAL"

		sleep 30
	done
done
exit 0
