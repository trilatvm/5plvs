#!/bin/sh
# .5colores.sh: Prueva de paleta de color consola
# probar_colores.sh: Muestra la paleta de colores ANSI en la terminal
printf "\n=== PALETA DE COLORES ANSI ESTÁNDAR ===\n"
printf "\033[0;31mrojo (0;31m)\033[0m      \033[1;31mrojo brillante (1;31m)\033[0m\n"
printf "\033[0;32mverde (0;32m)\033[0m     \033[1;32mverde brillante (1;32m)\033[0m\n"
printf "\033[0;33mnaranja (0;33m)\033[0m   \033[1;33mnaranja brillante (1;33m)\033[0m\n"
printf "\033[0;34mazul (0;34m)\033[0m      \033[1;34mazul brillante (1;34m)\033[0m\n"
printf "\033[0;35mmagenta (0;35m)\033[0m   \033[1;35mmagenta brillante (1;35m)\033[0m\n"
printf "\033[0;36mcian (0;36m)\033[0m      \033[1;36mcian brillante (1;36m)\033[0m\n"
printf "\033[0;37mblanco (0;37m)\033[0m    \033[1;37mblanco brillante (1;37m)\033[0m\n"
printf "\n=== PALETA DE ALTA INTENSIDAD (AI) ===\n"
printf "\033[0;91mrojo AI (0;91m)\033[0m   \033[1;91mrojo AI brillante (1;91m)\033[0m\n"
printf "\033[0;92mverde AI (0;92m)\033[0m  \033[1;92mverde AI brillante (1;92m)\033[0m\n"
printf "\033[0;93mamarillo (0;93m)\033[0m  \033[1;93mamarillo brillante (1;93m)\033[0m\n"
printf "\033[0;94mazul AI (0;94m)\033[0m   \033[1;94mazul AI brillante (1;94m)\033[0m\n"
printf "\033[0;95mmagenta AI (0;95m)\033[0m\033[1;95mmagenta AI brillante (1;95m)\033[0m\n"
printf "\033[0;96mcian AI (0;96m)\033[0m   \033[1;96mcian AI brillante (1;96m)\033[0m\n"
printf "\033[0;97mblanco AI (0;97m)\033[0m  \033[1;97mblanco AI brillante (1;97m)\033[0m\n"
printf "\n=== EJEMPLOS DE FONDOS ===\n"
printf "\033[41;37m Fondo Rojo \033[0m \033[42;30m Fondo Verde \033[0m \033[43;30m Fondo Naranja/Amarillo \033[0m \033[46;30m Fondo Cian \033[0m\n\n"

# test_naranja.sh: Muestra tonos de naranja real en paleta de 256 colores
printf "\n=== TONOS DE NARANJA REAL (256 colores) ===\n"
printf "\033[38;5;202m\033[1mNaranja Oscuro/Fuego (202m)\033[0m\n"
printf "\033[38;5;208m\033[1mNaranja Puro/Estándar (208m)\033[0m\n"
printf "\033[38;5;214m\033[1mNaranja Claro/Brillante (214m)\033[0m\n"
printf "\033[38;5;166m\033[1mNaranja Rojizo/Ladrillo (166m)\033[0m\n"
printf "\nComparativa contra el amarillo de tu terminal:\n"
printf "\033[1;33mAmarillo de sistema (1;33m)\033[0m\n\n"
exit 0
