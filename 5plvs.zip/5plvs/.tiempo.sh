#!/bin/sh
set -eu
setTiempo() {	# ajustar tiempo
	if date -s "2232-04-18 20:47:15" >/dev/null 2>&1; then
		tiempoI=$(get_tiempo)
		informar "Tiempo ajustado   :${tiempoI}"		# Éxito		
	else
		tiempoI=$(get_tiempo)
		informar "Tiempo NO ajustado:${tiempoI}"		# Fallo
	fi; }
getFecha() { date +"$(getHora) %A, %d de %m del %Y"; }
getHora() { date +"%Hh %Mm %Ss"; }
getTiempo() { date +"%Y-%m-%d %H:%M:%S"; }
getTS() { date +"%Y%m%d%H%M%S"; }
getTSE() { date +"%s"; }