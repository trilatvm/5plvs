#!/bin/sh
set -eu
# Variable global para recordar directorio
directorio_actual="./"
# Colores ANSI
ROJO='\033[91m'
VERDE='\033[92m'
NARANJA='\033[33m'
AMARILLO='\033[93m'
AZUL='\033[94m'
MAGENTA='\033[95m'
CIAN='\033[96m'
BLANCO='\033[97m'
RESET='\033[0m'
informar()  { printf '[INFO]  %s\n' "$*"; }
advertir()  { printf '[AVISO] %s\n' "$*" >&2; }
detectar_algoritmos() {	# Detectar todos los algoritmos disponibles
	algoritmos=""
	for a in md5 md5sum sha1 sha1sum sha256 sha256sum sha512 sha512sum b2sum cksum; do
		if command -v "$a" >/dev/null 2>&1; then
			case "$a" in
				md5|md5sum) algoritmos="$algoritmos md5" ;;
				sha1|sha1sum) algoritmos="$algoritmos sha1" ;;
				sha256|sha256sum) algoritmos="$algoritmos sha256" ;;
				sha512|sha512sum) algoritmos="$algoritmos sha512" ;;
				b2sum) algoritmos="$algoritmos b2sum" ;;
				cksum) algoritmos="$algoritmos cksum" ;;
			esac
		fi
	done
	[ -n "$algoritmos" ] || { advertir "No se encontró ningún algoritmo disponible."; exit 1; }
	informar "Algoritmos detectados:$algoritmos"; }
calcular_hash() {	# Calcular hash
	archivo=$1 algoritmo=$2
	case "$algoritmo" in
		md5) md5 -q "$archivo" 2>/dev/null || md5sum "$archivo" | cut -d' ' -f1 ;;
		sha1) sha1 -q "$archivo" 2>/dev/null || sha1sum "$archivo" | cut -d' ' -f1 ;;
		sha256) sha256 -q "$archivo" 2>/dev/null || sha256sum "$archivo" | cut -d' ' -f1 ;;
		sha512) sha512 -q "$archivo" 2>/dev/null || sha512sum "$archivo" | cut -d' ' -f1 ;;
		b2sum) b2sum "$archivo" | cut -d' ' -f1 ;;
		cksum) cksum "$archivo" | cut -d' ' -f1 ;;
	esac; }
mostrar_progreso() {	# Barra de progreso global
	porcentaje=$((tareas_procesadas * 100 / tareas_totales))
	completado=$((porcentaje * 50 / 100))
#	barra=$(printf '%*s' "$completado" "" | tr ' ' '█')
	barra=$(printf '%*s' "$completado" "" | tr ' ' '#')
	barra="$barra$(printf '%*s' $((50-completado)) "" | tr ' ' '-')"
	printf "\r[%s] %3d%% (%d/%d)" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales"
}
procesar_archivo() {	# Procesar archivo
	archivo=$1 dir=$2
	for a in $algoritmos; do
		dir_hash="$dir/.shall/$a"
		mkdir -p "$dir_hash"
		nombre_hash="$(basename "$archivo" | tr ' ' '_').$a"
		archivo_hash="$dir_hash/$nombre_hash"
		hash_actual=$(calcular_hash "$archivo" "$a" || true)
		if [ -z "$hash_actual" ]; then
			printf "${ROJO}[ERROR]${RESET} %s (%s)\n" "$archivo" "$a"
		elif [ -f "$archivo_hash" ]; then
			hash_guardado=$(cat "$archivo_hash")
			if [ "$hash_actual" = "$hash_guardado" ]; then
				printf "${VERDE} [CORRECTO]   ${MAGENTA}%s\n\t${CIAN}%s${RESET}\n" "$a" "$archivo" | tee -a "/tmp/.CRR.log"
			else
				printf "${ROJO} [INCORRECTO] ${MAGENTA}%s\n\t${AMARILLO}%s${RESET}\n" "$a" "$archivo" | tee -a "/tmp/.ERR.log"
				sleep 3   # Delay de 3 segundos en caso de fallo
			fi
		else
			printf '%s' "$hash_actual" > "$archivo_hash"
			printf "${NARANJA} [GENERAR]   ${MAGENTA}%s\n\t${CIAN}%s${RESET}\n" "$a" "$archivo" | tee -a "/tmp/.GEN.log"
		fi
		tareas_procesadas=$((tareas_procesadas + 1))
		mostrar_progreso
	done
}
procesar_directorio() {	# Procesar directorio y subdirectorios
	archivos=$(find "$1" -type f ! -path "*/.shall/*")
	[ -z "$archivos" ] && return
	count=$(printf '%s\n' $archivos | wc -l)
	tareas_totales=$((count * $(set -- $algoritmos; echo $#)))
	tareas_procesadas=0
	for f in $archivos; do
		dir=$(dirname "$f")
		procesar_archivo "$f" "$dir"
	done
	printf "\n"
	informar "Procesamiento completado para $1"
}
iniciar() {	# Inicio
	informar "=== Sistema de hashes .shall ==="
	detectar_algoritmos
	while :; do
		sync
		clear
		if [ -n "$directorio_actual" ]; then
			printf "Ingresar directorio [%s]: " "$directorio_actual"
		else
			printf "Ingresar directorio: "
		fi
		read -r entrada
		[ -n "$entrada" ] && directorio_actual=$entrada
		[ -d "$directorio_actual" ] || { advertir "Directorio inválido"; sleep 3; continue; }
		procesar_directorio "$directorio_actual"
		printf "\n¿Desea procesar otro directorio? [ENTER=Sí / s=Salir]: "
		read -r r
		case "$r" in s|S) break ;; esac
	done
}
informar "--- INICIO ---"
iniciar
informar "--- FIN    ---"
exit 0