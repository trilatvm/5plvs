#!/bin/sh
set -eu
# Colores ANSI
ROJ='\033[91m'
VER='\033[92m'
NAR='\033[33m'
AMA='\033[93m'
AZU='\033[94m'
MAG='\033[95m'
CIA='\033[96m'
BLA='\033[97m'
RES='\033[0m'