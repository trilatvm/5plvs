#!/bin/sh
# Módulo de gestión de tiempo compatible con POSIX sh
get_timestamp() { date +%Y%m%d%H%M%S; }
get_fecha_legible() { date '+%Y-%m-%d %H:%M:%S'; }
cronometro_iniciar() { TIEMPO_INICIO=$(date +%s); }	# Segundos epoch
cronometro_finalizar() {
	TIEMPO_FIN=$(date +%s)
	DURACION=$(( TIEMPO_FIN - TIEMPO_INICIO ))	# Cálculo aritmético básico POSIX sh
	printf "%s" "$DURACION"; }

