# Registro de instalacion para ntp
paquete='ntp'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:08:07'
estado='EXITO'
