# Registro de instalacion para cmake
paquete='cmake'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:51:12'
estado='EXITO'
