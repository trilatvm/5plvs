# Registro de instalacion para python3-openssl
paquete='python3-openssl'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:00:03'
estado='EXITO'
