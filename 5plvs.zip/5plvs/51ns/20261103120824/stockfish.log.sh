# Registro de instalacion para stockfish
paquete='stockfish'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:05:36'
estado='EXITO'
