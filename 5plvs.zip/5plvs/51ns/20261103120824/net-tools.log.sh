# Registro de instalacion para net-tools
paquete='net-tools'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:21:23'
estado='EXITO'
