# Registro de instalacion para tree
paquete='tree'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:26:09'
estado='EXITO'
