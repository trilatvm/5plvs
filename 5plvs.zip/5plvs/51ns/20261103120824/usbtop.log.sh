# Registro de instalacion para usbtop
paquete='usbtop'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:29:09'
estado='EXITO'
