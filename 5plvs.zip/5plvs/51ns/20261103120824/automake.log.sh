# Registro de instalacion para automake
paquete='automake'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:49:31'
estado='EXITO'
