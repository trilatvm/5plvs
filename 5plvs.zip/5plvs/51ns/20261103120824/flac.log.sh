# Registro de instalacion para flac
paquete='flac'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:42:07'
estado='EXITO'
