# Registro de instalacion para exfatprogs
paquete='exfatprogs'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:18:19'
estado='EXITO'
