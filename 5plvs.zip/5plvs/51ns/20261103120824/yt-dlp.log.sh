# Registro de instalacion para yt-dlp
paquete='yt-dlp'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:48:12'
estado='EXITO'
