# Registro de instalacion para dkms
paquete='dkms'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:17:36'
estado='EXITO'
