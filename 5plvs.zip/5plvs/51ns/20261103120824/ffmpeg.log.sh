# Registro de instalacion para ffmpeg
paquete='ffmpeg'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:41:22'
estado='EXITO'
