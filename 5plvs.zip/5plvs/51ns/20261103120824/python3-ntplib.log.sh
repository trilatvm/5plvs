# Registro de instalacion para python3-ntplib
paquete='python3-ntplib'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:55:28'
estado='EXITO'
