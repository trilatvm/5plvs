# Registro de instalacion para bzip2
paquete='bzip2'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:14:44'
estado='EXITO'
