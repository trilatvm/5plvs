# Registro de instalacion para ntpsec-ntpdate
paquete='ntpsec-ntpdate'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:08:55'
estado='EXITO'
