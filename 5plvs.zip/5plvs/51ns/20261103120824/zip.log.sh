# Registro de instalacion para zip
paquete='zip'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:29:56'
estado='EXITO'
