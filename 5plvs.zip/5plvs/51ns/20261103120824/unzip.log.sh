# Registro de instalacion para unzip
paquete='unzip'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:28:24'
estado='EXITO'
