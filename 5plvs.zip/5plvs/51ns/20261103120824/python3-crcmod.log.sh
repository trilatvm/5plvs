# Registro de instalacion para python3-crcmod
paquete='python3-crcmod'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:53:48'
estado='EXITO'
