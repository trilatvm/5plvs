# Registro de instalacion para mc
paquete='mc'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:02:35'
estado='EXITO'
