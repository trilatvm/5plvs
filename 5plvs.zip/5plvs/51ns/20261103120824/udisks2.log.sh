# Registro de instalacion para udisks2
paquete='udisks2'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:27:42'
estado='EXITO'
