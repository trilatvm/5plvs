# Registro de instalacion para aria2
paquete='aria2'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:01:07'
estado='EXITO'
