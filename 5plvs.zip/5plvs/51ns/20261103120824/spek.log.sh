# Registro de instalacion para spek
paquete='spek'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:45:33'
estado='EXITO'
