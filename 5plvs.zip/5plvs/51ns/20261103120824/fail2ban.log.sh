# Registro de instalacion para fail2ban
paquete='fail2ban'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:10:07'
estado='EXITO'
