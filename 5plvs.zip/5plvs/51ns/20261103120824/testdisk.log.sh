# Registro de instalacion para testdisk
paquete='testdisk'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:25:24'
estado='EXITO'
