# Registro de instalacion para fatresize
paquete='fatresize'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:19:03'
estado='EXITO'
