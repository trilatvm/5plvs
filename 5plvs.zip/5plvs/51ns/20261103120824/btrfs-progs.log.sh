# Registro de instalacion para btrfs-progs
paquete='btrfs-progs'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:14:03'
estado='EXITO'
