# Registro de instalacion para cronutils
paquete='cronutils'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:15:31'
estado='EXITO'
