# Registro de instalacion para smartmontools
paquete='smartmontools'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:22:34'
estado='EXITO'
