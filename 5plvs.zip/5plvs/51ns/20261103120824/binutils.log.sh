# Registro de instalacion para binutils
paquete='binutils'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:10:28'
estado='EXITO'
