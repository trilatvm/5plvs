# Registro de instalacion para cmus
paquete='cmus'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:31:15'
estado='EXITO'
