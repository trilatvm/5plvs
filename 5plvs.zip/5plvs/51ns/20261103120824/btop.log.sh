# Registro de instalacion para btop
paquete='btop'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:11:12'
estado='EXITO'
