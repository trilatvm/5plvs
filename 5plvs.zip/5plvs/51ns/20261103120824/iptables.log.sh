# Registro de instalacion para iptables
paquete='iptables'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:06:34'
estado='EXITO'
