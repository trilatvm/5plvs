# Registro de instalacion para par2
paquete='par2'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 13:03:27'
estado='EXITO'
