# Registro de instalacion para moreutils
paquete='moreutils'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:19:54'
estado='EXITO'
