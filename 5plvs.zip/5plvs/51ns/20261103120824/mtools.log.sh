# Registro de instalacion para mtools
paquete='mtools'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:20:38'
estado='EXITO'
