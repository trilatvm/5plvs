# Registro de instalacion para git
paquete='git'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 12:53:06'
estado='EXITO'
