#!/bin/sh
# Módulo de entorno Openbox compatible con POSIX sh
confAutostart='
# Cambiar la resolución si es necesario (opcional, ajustá a tu monitor)
#xrandr --output HDMI-1 --mode 1920x1080 --rate 60.00 &
xrandr --output HDMI-1 --mode 1280x720 --rate 50.00 &
# Poner un fondo de pantalla (reemplazá la ruta por tu imagen)
feh --bg-scale /usr/share/backgrounds/img.png & 
# Ejecutar el gestor de notificaciones 
dunst & 
# Lanzar la barra de tareas Tint2 
tint2 & 
# Lanzar el ícono de red en la bandeja del sistema (Wi-Fi)
nm-applet & 
# Gestor de energía (evita que la pantalla se apague sola)
xset s off -dpms & 
'
cnf(){
	# Crear la carpeta de configuración en tu usuario 
	mkdir -p ~/.config/openbox
	mkdir -p /usr/share/backgrounds/
	# Copiar los archivos plantilla del sistema 
	cp -v /etc/xdg/openbox/rc.xml ~/.config/openbox/	# rc.xml: Configuración de atajos de teclado, comportamiento de ventanas y mouse.
	cp -v /etc/xdg/openbox/menu.xml ~/.config/openbox/ 	# menu.xml: Contenido menu clic derecho en el escritorio.
	cp -v /etc/xdg/openbox/autostart ~/.config/openbox/	# autostart: Programas que se abren solos al iniciar sesión (Wi-Fi, fondo de pantalla, barra, etc.).
}
configurar_openbox() {
	printf "-> Configurando entorno Openbox...\n"
	cnf
	USER_HOME="${HOME}"
	[ -n "${SUDO_USER}" ] && USER_HOME=$(getent passwd "${SUDO_USER}" | cut -d: -f6)
	OB_DIR="${USER_HOME}/.config/openbox"
	mkdir -p "${OB_DIR}"
	if [ ! -f "${OB_DIR}/autostart" ]; then
#		printf "tint2 &\nnm-applet &\nfeh --bg-scale /usr/share/backgrounds/default.png &\n" > "${OB_DIR}/autostart"
		#cat "$confAutostart" >> "${OB_DIR}/autostart"
		echo "$confAutostart" >> "${OB_DIR}/autostart"
	fi
	XINIT="${USER_HOME}/.xinitrc"
	if [ ! -f "${XINIT}" ]; then
		printf "exec openbox-session\n" > "${XINIT}"
	fi
	[ -n "${SUDO_USER}" ] && chown -R "${SUDO_USER}:" "${USER_HOME}/.config" "${XINIT}" 2>/dev/null
	return 0
}
