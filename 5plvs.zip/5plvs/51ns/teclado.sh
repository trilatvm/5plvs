#!/bin/sh
configurar_teclado() {
	imp msg "-> Configurando idioma del teclado en Español (España)..."
	
	# 1. Configuración para el Entorno Gráfico (X11 / Openbox)
	USER_HOME="${HOME}"
	[ -n "${SUDO_USER}" ] && USER_HOME=$(getent passwd "${SUDO_USER}" | cut -d: -f6)
	XINIT="${USER_HOME}/.xinitrc"
	
	# Inyectar setxkbmap antes de iniciar Openbox si no está ya configurado
	if [ -f "${XINIT}" ]; then
		if ! grep -q "setxkbmap" "${XINIT}"; then
			# Insertar al principio del archivo .xinitrc
			temporal=$(mktemp)
			printf "setxkbmap es &\n" > "$temporal"
			cat "${XINIT}" >> "$temporal"
			cat "$temporal" > "${XINIT}"
			rm -f "$temporal"
		fi
	else
		printf "setxkbmap es &\nexec openbox-session\n" > "${XINIT}"
	fi
	[ -n "${SUDO_USER}" ] && chown "${SUDO_USER}:" "${XINIT}" 2>/dev/null

	# 2. Configuración para la Consola del Sistema (TTY) según el SO
	case "$SO" in
		debian)
			# Cambia la distribución a 'es' en el archivo nativo de consola
			if [ -f /etc/default/keyboard ]; then
				sudo sed -i 's/XKBLAYOUT=.*/XKBLAYOUT="es"/' /etc/default/keyboard
			fi
			;;
		void)
			# Void Linux gestiona la consola en rc.conf
			if [ -f /etc/rc.conf ]; then
				sudo sed -i 's/^KEYMAP=.*/KEYMAP="es"/' /etc/rc.conf
				if ! grep -q "^KEYMAP=" /etc/rc.conf; then
					printf 'KEYMAP="es"\n' | sudo tee -a /etc/rc.conf >/dev/null
				fi
			fi
			;;
		freebsd)
			# FreeBSD mapea el teclado de consola de forma nativa en rc.conf
			sudo sysrc keymap="spanish.iso.acc" >/dev/null 2>&1
			;;
	esac
}

exit 0
