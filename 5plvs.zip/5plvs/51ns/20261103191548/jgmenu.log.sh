# Registro de instalacion para jgmenu
paquete='jgmenu'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:22:31'
estado='EXITO'
