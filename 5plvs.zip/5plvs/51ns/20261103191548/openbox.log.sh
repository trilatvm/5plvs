# Registro de instalacion para openbox
paquete='openbox'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:19:44'
estado='EXITO'
