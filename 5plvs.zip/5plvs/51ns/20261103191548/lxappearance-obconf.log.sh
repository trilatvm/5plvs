# Registro de instalacion para lxappearance-obconf
paquete='lxappearance-obconf'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:23:57'
estado='EXITO'
