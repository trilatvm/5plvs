# Registro de instalacion para tint2
paquete='tint2'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:29:11'
estado='EXITO'
