# Registro de instalacion para obconf-qt
paquete='obconf-qt'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:27:39'
estado='EXITO'
