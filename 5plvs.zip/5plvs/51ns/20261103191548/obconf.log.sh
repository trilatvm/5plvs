# Registro de instalacion para obconf
paquete='obconf'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:25:35'
estado='EXITO'
