# Registro de instalacion para xinit
paquete='xinit'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:29:58'
estado='EXITO'
