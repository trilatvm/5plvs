# Registro de instalacion para xorg
paquete='xorg'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:32:50'
estado='EXITO'
