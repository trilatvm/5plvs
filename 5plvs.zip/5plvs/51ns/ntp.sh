#!/bin/sh
# Módulo de configuración NTP compatible con POSIX sh
# debian: /etc/ntpsec/ntp.conf
# server ntp.metas.ch
# server ntp11.metas.ch
# server ntp12.metas.ch
# server ntp13.metas.ch
# server ntp.ign.gob.ar
# server ntp.inti.gob.ar
configurar_ntp() {
	[ -z "$SO" ] && return 1
	printf "-> Configurando cliente NTP con ntp.inti.gob.ar...\n"
	NTP_SERVER="ntp.inti.gob.ar"
	NTP_CONF="/etc/ntp.conf"
	case "$SO" in
		debian|void)
			if [ -f "$NTP_CONF" ]; then
				sudo sed -i '/^pool /d; /^server /d' "$NTP_CONF"
				printf "server %s iburst\n" "$NTP_SERVER" | sudo tee -a "$NTP_CONF" >/dev/null
			fi
			;;
		freebsd)
			sudo sed -i '' '/^pool /d; /^server /d' "$NTP_CONF"
			printf "server %s iburst\n" "$NTP_SERVER" | sudo tee -a "$NTP_CONF" >/dev/null
			sudo sysrc ntpd_enable="YES" >/dev/null 2>&1
			;;
	esac
}
