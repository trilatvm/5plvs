# Registro de instalacion para python3-numpy-stl
paquete='python3-numpy-stl'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 17:01:44'
estado='EXITO'
