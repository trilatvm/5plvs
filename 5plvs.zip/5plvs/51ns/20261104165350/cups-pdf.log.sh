# Registro de instalacion para cups-pdf
paquete='cups-pdf'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 17:02:54'
estado='EXITO'
