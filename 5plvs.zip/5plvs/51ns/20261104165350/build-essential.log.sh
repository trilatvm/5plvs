# Registro de instalacion para build-essential
paquete='build-essential'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 17:01:13'
estado='EXITO'
