# Registro de instalacion para python3-pip
paquete='python3-pip'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 16:58:21'
estado='EXITO'
