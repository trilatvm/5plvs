#!/bin/sh
# Módulo de impresión por consola compatible con POSIX sh
imp() {
	case "$1" in
		err)  printf "Error: %s\n" "$2" >&2; exit 1 ;;
		msg)  printf "%s\n" "$2" ;;
		info) printf "Actualizando repositorios para %s... " "$2" ;;
		prog)
			porc=$(( ($2 * 100) / $3 ))
			h=$(( porc / 5 )); d=$(( 20 - h ))
			hashes=$(printf "%0${h}s" | tr ' ' '#')
			dashes=$(printf "%0${d}s" | tr ' ' '-')
			printf "\r[%s%s] %3d%% (%d/%d) [%-11s] [%s]" "$hashes" "$dashes" "$porc" "$2" "$3" "$4" "$5"
			;;
	esac
}
