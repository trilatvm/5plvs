# Registro de instalacion para gpsd
paquete='gpsd'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 19:02:59'
estado='EXITO'
