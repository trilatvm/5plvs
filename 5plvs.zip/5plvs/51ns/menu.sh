#!/bin/sh
# Módulo de menú de selección compatible con POSIX sh
menu_seleccion() {
	clear
	imp msg "GESTOR DE INSTALACIÓN MODULAR COMPATIBLE POSIX"
	imp msg "Tipo de instalación general:"
	imp msg "1) Solo Consola Completo (CLI + Redes/NTP)"
	imp msg "2) Entorno Gráfico Completo (CLI + Openbox Suite + GUIs)"
	imp msg "3) Selección personalizada por categorías"
	printf "Seleccione una opción (1-3): "; read -r tipo
	pkgs=""
	instalar_ob=0
	instalar_net=0
	case "$tipo" in
		1)
			pkgs="$cli_sistema $cli_multimedia $cli_desarrollo $cli_herramientas $cli_redes"
			instalar_net=1
			;;
		2)
			pkgs="$cli_sistema $cli_multimedia $cli_desarrollo $cli_herramientas $cli_redes $gui_openbox $gui_entorno $gui_multimedia $gui_desarrollo $gui_oficina $gui_herramientas"
			instalar_ob=1
			instalar_net=1
			;;
		3)
			ask() { printf "%s (s/n): " "$1"; read -r ans; case "$ans" in [sS]*) return 0 ;; *) return 1 ;; esac; }
			imp msg "\nCATEGORÍAS CLI (CONSOLA)"
			if ask "¿Sistema Base? $pkgs $cli_sistema"; then pkgs="$pkgs $cli_sistema"; fi
			if ask "¿Multimedia? $pkgs $cli_multimedia"; then pkgs="$pkgs $cli_multimedia"; fi
			if ask "¿Desarrollo? $pkgs $cli_desarrollo"; then pkgs="$pkgs $cli_desarrollo"; fi
			if ask "¿Herramientas? $pkgs $cli_herramientas"; then pkgs="$pkgs $cli_herramientas"; fi
			if ask "¿Configuración Redes/NTP/Firewall (Iptables)? $pkgs $cli_redes"; then
				pkgs="$pkgs $cli_redes"
				instalar_net=1
			fi
			imp msg "\nCATEGORÍAS GUI (GRÁFICO)"
			if ask "¿Instalar Xorg y Gestor de Ventanas Openbox? $pkgs $gui_openbox"; then
				pkgs="$pkgs $gui_openbox $gui_entorno"
				instalar_ob=1
			fi
			if ask "¿Multimedia Gráfico? $pkgs $gui_multimedia"; then pkgs="$pkgs $gui_multimedia"; fi
			if ask "¿Desarrollo Gráfico? $pkgs $gui_desarrollo"; then pkgs="$pkgs $gui_desarrollo"; fi
			if ask "¿Oficina y Web? $pkgs $gui_oficina"; then pkgs="$pkgs $gui_oficina"; fi
			if ask "¿Herramientas Gráficas Avanzadas? $pkgs $gui_herramientas"; then pkgs="$pkgs $gui_herramientas"; fi
			;;
		*) imp err "Opción inválida." ;;
	esac
	[ -z "$pkgs" ] && imp err "No se seleccionaron paquetes."
}
