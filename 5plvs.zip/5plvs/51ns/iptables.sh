#!/bin/sh
# Módulo de configuración de Firewall compatible con POSIX sh
aplicarReglas(){
	cmd_firewall="$1"
	imp msg "-> Aplicando reglas para $cmd_firewall..."
	imp msg "Reglas $cmd_firewall: Limpiar reglas existentes"
	sudo "$cmd_firewall" -F
	sudo "$cmd_firewall" -X
	sudo "$cmd_firewall" -t nat -F 2>/dev/null || true
	sudo "$cmd_firewall" -t nat -X 2>/dev/null || true
	sudo "$cmd_firewall" -t mangle -F 2>/dev/null || true
	sudo "$cmd_firewall" -t mangle -X 2>/dev/null || true
	imp msg "Reglas $cmd_firewall: Politicas por defecto"
	sudo "$cmd_firewall" -P INPUT DROP
	sudo "$cmd_firewall" -P FORWARD DROP
	sudo "$cmd_firewall" -P OUTPUT ACCEPT
	imp msg "Reglas $cmd_firewall: Permitir loopback"
	sudo "$cmd_firewall" -A INPUT -i lo -j ACCEPT
	sudo "$cmd_firewall" -A OUTPUT -o lo -j ACCEPT
	imp msg "Reglas $cmd_firewall: Permitir conexiones ya establecidas y relacionadas"
	sudo "$cmd_firewall" -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
	imp msg "Reglas $cmd_firewall: Puertos permitidos (SSH, HTTP, HTTPS)"
	sudo "$cmd_firewall" -A INPUT -p tcp --dport 22 -j ACCEPT
	sudo "$cmd_firewall" -A INPUT -p tcp --dport 80 -j ACCEPT
	sudo "$cmd_firewall" -A INPUT -p tcp --dport 443 -j ACCEPT
	# Condicional POSIX estricto para trazar ICMP v4/v6
	if [ "$cmd_firewall" = "iptables" ]; then
		sudo "$cmd_firewall" -A INPUT -p icmp --icmp-type echo-request -j ACCEPT
	else
		sudo "$cmd_firewall" -A INPUT -p ipv6-icmp --icmpv6-type echo-request -j ACCEPT
	fi
	imp msg "Reglas $cmd_firewall: Rechazar todo lo demas explicitamente"
	sudo "$cmd_firewall" -A INPUT -j REJECT
	sudo "$cmd_firewall" -A FORWARD -j REJECT
	# Persistencia de datos según el sistema operativo
	if [ "$SO" = "debian" ]; then
		imp msg "Reglas $cmd_firewall: Guardando reglas para Debian"
		if [ -d /etc/iptables ]; then
			if [ "$cmd_firewall" = "iptables" ]; then
				sudo sh -c "$cmd_firewall-save > /etc/iptables/rules.v4"
				imp msg "Reglas IPv4 guardadas en /etc/iptables/rules.v4"
			else
				sudo sh -c "$cmd_firewall-save > /etc/iptables/rules.v6"
				imp msg "Reglas IPv6 guardadas en /etc/iptables/rules.v6"
			fi
		fi
	elif [ "$SO" = "void" ]; then
		imp msg "Reglas $cmd_firewall: Guardando reglas para Void Linux"
		sudo mkdir -p "/etc/$cmd_firewall"
		if [ "$cmd_firewall" = "iptables" ]; then
			sudo sh -c "$cmd_firewall-save > /etc/$cmd_firewall/rules.v4"
		else
			sudo sh -c "$cmd_firewall-save > /etc/$cmd_firewall/rules.v6"
		fi
	fi
	imp msg "Reglas de $cmd_firewall aplicadas con exito."
	sudo "$cmd_firewall" -L -n -v -x --line-numbers
}
aplicar(){
	if command -v "$1" >/dev/null 2>&1; then
		aplicarReglas "$1"
	else
		imp msg "[Aviso] $1 no se encuentra disponible en este sistema."
	fi
}
configurar_iptables() {
	[ -z "$SO" ] && return 1
	case "$SO" in
		debian|void)
			if [ "$SO" = "debian" ]; then
				imp msg "-> Asegurando entorno iptables-persistent en Debian..."
				# Aprovecha el sistema nativo de gestión de paquetes del orquestador principal
				gestionar_paquete ins "iptables-persistent"
			fi
			# Ejecuta la lógica para ambas capas de red de forma secuencial
			aplicar "iptables"
			aplicar "ip6tables"
			;;
		freebsd)
			imp msg "[Aviso] FreeBSD utiliza PF/IPFW de forma nativa. No se procesa iptables."
			;;
	esac
}
