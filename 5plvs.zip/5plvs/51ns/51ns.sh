#!/bin/sh
# Script principal optimizado bajo el estándar estricto POSIX sh
# Función de chequeo de integridad estructural estricto
chequear_integridad() {
#	modulos="impresion.sh paquetes.sh menu.sh tiempo.sh registro.sh ntp.sh iptables.sh openbox.sh"
	modulos='	impresion.sh
			iptables.sh
			menu.sh
			ntp.sh
			openbox.sh
			paquetes.sh
			registro.sh
			tiempo.sh
		'
	faltantes=""
	for mod in $modulos; do
		if [ ! -f "./$mod" ]; then
			faltantes="$faltantes $mod"
		fi
	done

	if [ -n "$faltantes" ]; then
		printf "Error Crítico de Integridad: Faltan los siguientes módulos indispensables:%s\n" "$faltantes" >&2
		exit 1
	fi
}
# Ejecutar control antes de la carga
chequear_integridad
# Inclusión nativa de módulos independientes
. ./impresion.sh
. ./iptables.sh
. ./menu.sh
. ./ntp.sh
. ./openbox.sh
. ./paquetes.sh
. ./registro.sh
. ./tiempo.sh
detectar_so() {
	SO=""
	if [ -f /etc/os-release ]; then
		. /etc/os-release
		[ "$ID" = "void" ] && SO="void"
		{ [ "$ID" = "debian" ] || [ "$ID_LIKE" = "debian" ]; } && SO="debian"
	fi
	[ -z "$SO" ] && [ "$(uname)" = "FreeBSD" ] && SO="freebsd"
	[ -z "$SO" ] && imp err "Sistema operativo no soportado."
}
actualizar_repo() {
	imp info "$SO"
	case "$SO" in
		void)    xbps-install -S >/dev/null 2>&1 ;;
		debian)  sudo apt-get update -y >/dev/null 2>&1 ;;
		freebsd) sudo pkg update -q >/dev/null 2>&1 ;;
	esac
	[ $? -eq 0 ] && imp msg "OK" || imp msg "ERR"
}
gestionar_paquete() {
	case "$1" in
		chk_inst)
			case "$SO" in
				void)    xbps-query -l | grep -q " ${2}-" ;;
				debian)  dpkg-query -W -f='${Status}' "$2" 2>/dev/null | grep -q "ok installed" ;;
				freebsd) pkg info -e "$2" ;;
			esac
			;;
		chk_repo)
			case "$SO" in
				void)    xbps-query -Rs "^${2}-[0-9]" >/dev/null 2>&1 ;;
				debian)  apt-cache show "$2" >/dev/null 2>&1 ;;
				freebsd) pkg search -qx "^${2}$" >/dev/null 2>&1 ;;
			esac
			;;
		ins)
			case "$SO" in
				void)    sudo xbps-install -y "$2" >/dev/null 2>&1 ;;
				debian)  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "$2" >/dev/null 2>&1 ;;
				freebsd) sudo pkg install -y "$2" >/dev/null 2>&1 ;;
			esac
			;;
	esac
}
main() {
	detectar_so
	menu_seleccion
	cronometro_iniciar
	inicializar_logs
	tot=0; for p in $pkgs; do tot=$((tot + 1)); done
	actualizar_repo
	act=0
	for p in $pkgs; do
		act=$((act + 1))
		if gestionar_paquete chk_inst "$p"; then
			est="EXISTE"
		elif ! gestionar_paquete chk_repo "$p"; then
			est="NO REPO"
			registrar_no_repo "$p"
		else
			est="INSTALANDO"
			imp prog "$act" "$tot" "$est" "$p"
			if gestionar_paquete ins "$p"; then
				est="OK"
				registrar_instalado "$p" "$SO"
			else
				est="ERROR"
			fi
			sync 2>/dev/null || true
		fi
		imp prog "$act" "$tot" "$est" "$p"
		printf "\n"
	done
	[ "$instalar_net" -eq 1 ] && configurar_ntp && configurar_iptables
	[ "$instalar_ob" -eq 1 ] && configurar_openbox
	segundos_totales=$(cronometro_finalizar)
	imp msg "\n¡Proceso finalizado con éxito en ${segundos_totales} segundos!"
}
memoria(){
	# Liberar caché residual
	sync
	echo 3 > /proc/sys/vm/drop_caches
}
memoria
main
memoria
exit 0
