# Registro de instalacion para lxterminal
paquete='lxterminal'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:59:44'
estado='EXITO'
