# Registro de instalacion para gparted
paquete='gparted'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:58:19'
estado='EXITO'
