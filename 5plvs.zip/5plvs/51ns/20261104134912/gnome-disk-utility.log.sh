# Registro de instalacion para gnome-disk-utility
paquete='gnome-disk-utility'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:56:42'
estado='EXITO'
