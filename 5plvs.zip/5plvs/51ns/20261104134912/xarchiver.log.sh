# Registro de instalacion para xarchiver
paquete='xarchiver'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 14:01:11'
estado='EXITO'
