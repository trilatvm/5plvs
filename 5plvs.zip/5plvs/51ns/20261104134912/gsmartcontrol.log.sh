# Registro de instalacion para gsmartcontrol
paquete='gsmartcontrol'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:52:58'
estado='EXITO'
