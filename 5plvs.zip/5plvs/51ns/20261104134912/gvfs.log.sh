# Registro de instalacion para gvfs
paquete='gvfs'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:51:25'
estado='EXITO'
