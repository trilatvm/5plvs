# Registro de instalacion para cups-pdf
paquete='cups-pdf'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 14:06:22'
estado='EXITO'
