# Registro de instalacion para cups
paquete='cups'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 14:04:53'
estado='EXITO'
