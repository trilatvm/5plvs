# Registro de instalacion para ntfs2btrfs
paquete='ntfs2btrfs'
sistema_operativo='debian'
fecha_instalacion='2026-11-04 13:53:59'
estado='EXITO'
