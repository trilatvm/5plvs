#!/bin/sh
# Script de instalación optimizado y modular bajo el estándar estricto POSIX sh
# Compatible con Debian, Void y Freebsd

cli_sistema='binutils btop btrfs-progs bzip2 coreutils cronutils dkms dosfstools e2fsprogs exfatprogs fail2ban fatresize htop moreutils mtools net-tools parted rsync smartmontools socklog-void testdisk tree udisks2 unzip usbtop wget xz zip'
cli_multimedia='cmus cmus-flac cmus-pulseaudio ffmpeg flac spek yt-dlp'
cli_desarrollo='automake cmake diffutils git openjdk8 openjdk17 postgresql-full python3 python3-crcmod python3-cryptography python3-cryptography_vectors python3-ntplib python3-numexpr python3-numpy python3-numpy-stl python3-openssl'
cli_herramientas='aria2 bitcoin mc nano par2cmdline pps-tools stockfish'

# Configuración y Redes (Separados para aprovisionamiento)
cli_redes='iptables ntp'

# Suite Openbox (Separada explícitamente de la GUI genérica)
gui_openbox='openbox feh jgmenu lxappearance-obconf obconf obconf-qt obmenu-generator tint2 xinit xorg xtools'

gui_entorno='dbus font-terminus font-termsyn grub-terminus network-manager-applet'
gui_multimedia='CubicSDR ImageMagick alsa-plugins-ffmpeg alsa-plugins-pulseaudio apulse gpredict gpsd gpsd-qt mpv mypaint pavucontrol pavucontrol-qt pulseaudio pulseaudio-equalizer-ladspa pulseaudio-qt pulseaudio-utils pulsemixer soundconverter vlc x264 x265'
gui_desarrollo='geany geany-editorconfig-plugin geany-plugins geany-plugins-extra python3-matplotlib python3-matplotlib-inline'
gui_oficina='LibreCAD dia firefox-esr libreoffice pcmanfm qpdfview tuxpaint tuxpaint-stamps viewnior'
gui_herramientas='bitcoin-qt protontricks qalculate qalculate-qt qrencode wine-mono winetricks zfs-lts zfsbootmenu'

# Método centralizado de impresión
imp() {
	case "$1" in
		err)  printf "Error: %s\n" "$2" >&2; exit 1 ;;
		msg)  printf "%s\n" "$2" ;;
		info) printf "Actualizando repositorios para %s... " "$2" ;;
		prog)
			porc=$(( ($2 * 100) / $3 ))
			h=$(( porc / 5 )); d=$(( 20 - h ))
			hashes=$(printf "%0${h}s" | tr ' ' '#')
			dashes=$(printf "%0${d}s" | tr ' ' '-')
			printf "\r[%s%s] %3d%% (%d/%d) [%-11s] [%s]" "$hashes" "$dashes" "$porc" "$2" "$3" "$4" "$5"
			;;
	esac
}

detectar_so() {
	SO=""
	if [ -f /etc/os-release ]; then
		. /etc/os-release
		[ "$ID" = "void" ] && SO="void"
		{ [ "$ID" = "debian" ] || [ "$ID_LIKE" = "debian" ]; } && SO="debian"
	fi
	[ -z "$SO" ] && [ "$(uname)" = "FreeBSD" ] && SO="freebsd"
	[ -z "$SO" ] && imp err "Sistema operativo no soportado."
}

actualizar_repo() {
	imp info "$SO"
	case "$SO" in
		void)    xbps-install -S >/dev/null 2>&1 ;;
		debian)  sudo apt-get update -y >/dev/null 2>&1 ;;
		freebsd) sudo pkg update -q >/dev/null 2>&1 ;;
	esac
	[ $? -eq 0 ] && imp msg "OK" || imp msg "ERR"
}

gestionar_paquete() {
	case "$1" in
		chk_inst)
			case "$SO" in
				void)    xbps-query -l | grep -q " ${2}-" ;;
				debian)  dpkg-query -W -f='${Status}' "$2" 2>/dev/null | grep -q "ok installed" ;;
				freebsd) pkg info -e "$2" ;;
			esac
			;;
		chk_repo)
			case "$SO" in
				void)    xbps-query -Rs "^${2}-[0-9]" >/dev/null 2>&1 ;;
				debian)  apt-cache show "$2" >/dev/null 2>&1 ;;
				freebsd) pkg search -qx "^${2}$" >/dev/null 2>&1 ;;
			esac
			;;
		ins)
			case "$SO" in
				void)    sudo xbps-install -y "$2" >/dev/null 2>&1 ;;
				debian)  sudo DEBIAN_FRONTEND=noninteractive apt-get install -y "$2" >/dev/null 2>&1 ;;
				freebsd) sudo pkg install -y "$2" >/dev/null 2>&1 ;;
			esac
			;;
	esac
}

# --- MÓDULOS DE CONFIGURACIÓN COMPATIBLES POSIX ---

configurar_openbox() {
	imp msg "-> Configurando entorno Openbox..."
	
	# Determinar el HOME real si se ejecuta con sudo
	USER_HOME="${HOME}"
	[ -n "${SUDO_USER}" ] && USER_HOME=$(getent passwd "${SUDO_USER}" | cut -d: -f6)
	
	OB_DIR="${USER_HOME}/.config/openbox"
	mkdir -p "${OB_DIR}"
	
	# Estructura base de inicio automático limpia
	if [ ! -f "${OB_DIR}/autostart" ]; then
		printf "tint2 &\nnm-applet &\nfeh --bg-scale /usr/share/backgrounds/default.png &\n" > "${OB_DIR}/autostart"
	fi
	
	# Asegurar xinitrc para arrancar con startx sin intermediarios
	XINIT="${USER_HOME}/.xinitrc"
	if [ ! -f "${XINIT}" ]; then
		printf "exec openbox-session\n" > "${XINIT}"
	fi
	
	[ -n "${SUDO_USER}" ] && chown -R "${SUDO_USER}:" "${USER_HOME}/.config" "${XINIT}" 2>/dev/null
}

configurar_ntp() {
	imp msg "-> Configurando cliente NTP con ntp.inti.gob.ar..."
	
	# Servidor solicitado
	NTP_SERVER="ntp.inti.gob.ar"
	
	case "$SO" in
		debian|void)
			NTP_CONF="/etc/ntp.conf"
			if [ -f "$NTP_CONF" ]; then
				sudo sed -i '/^pool /d; /^server /d' "$NTP_CONF"
				printf "server %s iburst\n" "$NTP_SERVER" | sudo tee -a "$NTP_CONF" >/dev/null
			fi
			;;
		freebsd)
			NTP_CONF="/etc/ntp.conf"
			# Configuración nativa ntp de FreeBSD
			sudo sed -i '' '/^pool /d; /^server /d' "$NTP_CONF"
			printf "server %s iburst\n" "$NTP_SERVER" | sudo tee -a "$NTP_CONF" >/dev/null
			# Habilitar el demonio en rc.conf
			sudo sysrc ntpd_enable="YES" >/dev/null 2>&1
			;;
	esac
}

configurar_iptables() {
	imp msg "-> Configurando políticas básicas de Firewall..."
	case "$SO" in
		debian|void)
			if command -v iptables >/dev/null 2>&1; then
				sudo iptables -F
				sudo iptables -P INPUT DROP
				sudo iptables -P FORWARD DROP
				sudo iptables -P OUTPUT ACCEPT
				sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
				sudo iptables -A INPUT -i lo -j ACCEPT
				
				# Persistencia según distribución
				if [ "$SO" = "debian" ]; then
					echo "iptables-persistent" | gestionar_paquete ins
					sudo iptables-save | sudo tee /etc/iptables/rules.v4 >/dev/null
				fi
			fi
			;;
		freebsd)
			# En FreeBSD, iptables no existe nativamente; se advierte o redirige conceptualmente a PF
			imp msg "[Aviso] FreeBSD utiliza PF/IPFW. No se aplica iptables directamente aquí."
			;;
	esac
}

menu_seleccion() {
	clear
	imp msg "GESTOR DE INSTALACIÓN MODULAR COMPATIBLE POSIX"
	imp msg "Tipo de instalación general:"
	imp msg "1) Solo Consola Completo (CLI + Redes/NTP)"
	imp msg "2) Entorno Gráfico Completo (CLI + Openbox Suite + GUIs)"
	imp msg "3) Selección personalizada por categorías"
	printf "Seleccione una opción (1-3): "; read -r tipo

	pkgs=""
	instalar_ob=0
	instalar_net=0

	case "$tipo" in
		1) 
			pkgs="$cli_sistema $cli_multimedia $cli_desarrollo $cli_herramientas $cli_redes" 
			instalar_net=1
			;;
		2) 
			pkgs="$cli_sistema $cli_multimedia $cli_desarrollo $cli_herramientas $cli_redes $gui_openbox $gui_entorno $gui_multimedia $gui_desarrollo $gui_oficina $gui_herramientas" 
			instalar_ob=1
			instalar_net=1
			;;
		3)
			ask() { printf "%s (s/n): " "$1"; read -r ans; case "$ans" in [sS]*) return 0 ;; *) return 1 ;; esac; }
			
			imp msg "\nCATEGORÍAS CLI (CONSOLA)"
			if ask "¿Sistema Base?"; then pkgs="$pkgs $cli_sistema"; fi
			if ask "¿Multimedia?"; then pkgs="$pkgs $cli_multimedia"; fi
			if ask "¿Desarrollo?"; then pkgs="$pkgs $cli_desarrollo"; fi
			if ask "¿Herramientas?"; then pkgs="$pkgs $cli_herramientas"; fi
			if ask "¿Configuración Redes/NTP/Firewall (Iptables)?"; then 
				pkgs="$pkgs $cli_redes"
				instalar_net=1
			fi

			imp msg "\nCATEGORÍAS GUI (GRÁFICO)"
			if ask "¿Instalar Gestor de Ventanas Openbox y dependencias directas?"; then 
				pkgs="$pkgs $gui_openbox"
				instalar_ob=1
			fi
			if ask "¿Entorno Base Adicional?"; then pkgs="$pkgs $gui_entorno"; fi
			if ask "¿Multimedia Gráfico?"; then pkgs="$pkgs $gui_multimedia"; fi
			if ask "¿Desarrollo Gráfico?"; then pkgs="$pkgs $gui_desarrollo"; fi
			if ask "¿Oficina y Web?"; then pkgs="$pkgs $gui_oficina"; fi
			if ask "¿Herramientas Gráficas Avanzadas?"; then pkgs="$pkgs $gui_herramientas"; fi
			;;
		*) imp err "Opción inválida." ;;
	esac
	[ -z "$pkgs" ] && imp err "No se seleccionaron paquetes."
}

main() {
	detectar_so
	menu_seleccion

	tot=0; for p in $pkgs; do tot=$((tot + 1)); done
	actualizar_repo
	
	act=0
	for p in $pkgs; do
		act=$((act + 1))
		
		if gestionar_paquete chk_inst "$p"; then
			est="EXISTE"
		elif ! gestionar_paquete chk_repo "$p"; then
			est="NO REPO"
		else
			est="INSTALANDO"
			imp prog "$act" "$tot" "$est" "$p"
			gestionar_paquete ins "$p" && est="OK" || est="ERROR"
			sync 2>/dev/null || true
		fi
		imp prog "$act" "$tot" "$est" "$p"
		printf "\n"
	done

	# Despliegue de aprovisionamientos condicionales basados en la selección
	[ "$instalar_net" -eq 1 ] && configurar_ntp && configurar_iptables
	[ "$instalar_ob" -eq 1 ] && configurar_openbox

	imp msg "\n¡Proceso finalizado con éxito!"
}

main
exit 0
