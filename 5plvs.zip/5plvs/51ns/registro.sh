#!/bin/sh
# Módulo de auditoría y registros compatible con POSIX sh

inicializar_logs() {
	# Usamos la nueva función del módulo tiempo
	LOG_DIR=$(get_timestamp)
	mkdir -p "$LOG_DIR"
	LOG_BUSCADOS="buscados.log.sh"
	printf "# Archivo de paquetes no encontrados en el repositorio - %s\n" "$LOG_DIR" > "$LOG_BUSCADOS"
}
registrar_no_repo() { 
#	printf "paquete_ausente='%s'\n" "$1" >> "$LOG_BUSCADOS"
#	for pkg in $1; do
		case "$SO" in
			void)    xbps-query -Rs $pkg >> "$LOG_BUSCADOS" 2>&1 ;;
			debian)  apt search $pkg >> "$LOG_BUSCADOS" 2>&1 ;;
			freebsd) pkg search $pkg >> "$LOG_BUSCADOS" 2>&1 ;;
		esac	
#	done	
}
registrar_instalado() {
	p_nombre="$1"
	p_so="$2"
	p_fecha=$(get_fecha_legible)
	printf "# Registro de instalacion para %s\n" "$p_nombre" > "$LOG_DIR/${p_nombre}.log.sh"
	printf "paquete='%s'\n" "$p_nombre" >> "$LOG_DIR/${p_nombre}.log.sh"
	printf "sistema_operativo='%s'\n" "$p_so" >> "$LOG_DIR/${p_nombre}.log.sh"
	printf "fecha_instalacion='%s'\n" "$p_fecha" >> "$LOG_DIR/${p_nombre}.log.sh"
	printf "estado='EXITO'\n" >> "$LOG_DIR/${p_nombre}.log.sh"; }
