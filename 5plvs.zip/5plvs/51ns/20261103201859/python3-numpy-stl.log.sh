# Registro de instalacion para python3-numpy-stl
paquete='python3-numpy-stl'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:19:35'
estado='EXITO'
