#!/bin/sh
# Módulo de definición de paquetes compatible con POSIX sh
cli_sistema='binutils btop btrfs-progs bzip2 coreutils cronutils gvfs dkms gsmartcontrol ntfs-3g ntfs2btrfs socklog-void dosfstools e2fsprogs exfatprogs fatresize pavucontrol pulseaudio zfs-lts zfsbootmenu moreutils mtools net-tools parted rsync smartmontools socklog-void testdisk tree udisks2 unzip usbtop wget xz zip'
cli_multimedia='cmus cmus-flac cmus-pulseaudio ffmpeg flac yt-dlp font-terminus font-termsyn grub-terminus'
cli_desarrollo='make python3 python3-pip python3-setuptools python3-wheel build-essential gcc automake cmake diffutils git openjdk8 openjdk17 postgresql-full python3 python3-crcmod python3-cryptography python3-cryptography_vectors python3-ntplib python3-numexpr python3-numpy python3-numpy-stl python3-openssl'
cli_herramientas='aria2 bitcoin mc nano par2 par2cmdline pps-tools gpsd qrencode stockfish qalculate htop btop'
cli_redes='iptables ntp ntpsec ntpsec-ntpdate fail2ban'
gui_openbox='openbox feh jgmenu lxappearance-obconf obconf obconf-qt obmenu-generator tint2 xinit xorg xtools'
gui_entorno='xorg dbus network-manager-applet pcmanfm qpdfview viewnior x264 x265 gnome-disk-utility gparted mpv xterm lxterminal xarchiver'
gui_multimedia='CubicSDR ImageMagick spek alsa-plugins-ffmpeg alsa-plugins-pulseaudio apulse gpredict gpsd-qt mypaint pavucontrol-qt pulseaudio-equalizer-ladspa pulseaudio-qt pulseaudio-utils pulsemixer soundconverter vlc'
gui_desarrollo='dia geany geany-editorconfig-plugin geany-plugins geany-plugins-extra python3-matplotlib python3-matplotlib-inline'
gui_oficina='LibreCAD librecad firefox-esr libreoffice cups cups-pdf tuxpaint tuxpaint-stamps'
gui_herramientas='bitcoin-qt protontricks qalculate-qt wine-mono winetricks'
