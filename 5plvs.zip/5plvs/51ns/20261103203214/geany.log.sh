# Registro de instalacion para geany
paquete='geany'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:52:00'
estado='EXITO'
