# Registro de instalacion para dia
paquete='dia'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:12:29'
estado='EXITO'
