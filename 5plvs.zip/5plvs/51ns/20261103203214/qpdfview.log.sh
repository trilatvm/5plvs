# Registro de instalacion para qpdfview
paquete='qpdfview'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:27:01'
estado='EXITO'
