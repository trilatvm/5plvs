# Registro de instalacion para firefox-esr
paquete='firefox-esr'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:15:02'
estado='EXITO'
