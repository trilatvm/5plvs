# Registro de instalacion para pulsemixer
paquete='pulsemixer'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:44:28'
estado='EXITO'
