# Registro de instalacion para librecad
paquete='librecad'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:10:27'
estado='EXITO'
