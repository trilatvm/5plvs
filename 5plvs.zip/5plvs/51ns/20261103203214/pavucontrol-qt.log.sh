# Registro de instalacion para pavucontrol-qt
paquete='pavucontrol-qt'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:43:42'
estado='EXITO'
