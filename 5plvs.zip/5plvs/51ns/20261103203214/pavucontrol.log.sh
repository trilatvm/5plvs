# Registro de instalacion para pavucontrol
paquete='pavucontrol'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:41:19'
estado='EXITO'
