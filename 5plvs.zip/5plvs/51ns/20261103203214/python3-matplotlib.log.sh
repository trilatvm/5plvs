# Registro de instalacion para python3-matplotlib
paquete='python3-matplotlib'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:06:31'
estado='EXITO'
