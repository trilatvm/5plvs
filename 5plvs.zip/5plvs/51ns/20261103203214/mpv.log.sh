# Registro de instalacion para mpv
paquete='mpv'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:36:33'
estado='EXITO'
