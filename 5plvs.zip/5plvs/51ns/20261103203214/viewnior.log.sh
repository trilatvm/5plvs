# Registro de instalacion para viewnior
paquete='viewnior'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:28:14'
estado='EXITO'
