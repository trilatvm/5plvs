# Registro de instalacion para geany-plugins
paquete='geany-plugins'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:57:17'
estado='EXITO'
