# Registro de instalacion para python3-matplotlib-inline
paquete='python3-matplotlib-inline'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:07:21'
estado='EXITO'
