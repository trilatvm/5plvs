# Registro de instalacion para x264
paquete='x264'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:49:47'
estado='EXITO'
