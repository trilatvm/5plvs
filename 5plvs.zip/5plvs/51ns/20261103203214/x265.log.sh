# Registro de instalacion para x265
paquete='x265'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:50:30'
estado='EXITO'
