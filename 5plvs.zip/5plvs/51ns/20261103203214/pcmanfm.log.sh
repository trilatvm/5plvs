# Registro de instalacion para pcmanfm
paquete='pcmanfm'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:30:34'
estado='EXITO'
