# Registro de instalacion para libreoffice
paquete='libreoffice'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 21:25:35'
estado='EXITO'
