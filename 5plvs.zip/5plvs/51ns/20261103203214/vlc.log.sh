# Registro de instalacion para vlc
paquete='vlc'
sistema_operativo='debian'
fecha_instalacion='2026-11-03 20:48:55'
estado='EXITO'
