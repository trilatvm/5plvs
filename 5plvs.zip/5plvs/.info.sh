#!/bin/sh
set -eu
#apt search zfs | greep zfs | tee zfs
