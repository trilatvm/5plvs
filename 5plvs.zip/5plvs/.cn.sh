#!/bin/sh
###############################################################################
# convertir_videos_selectivo_posix.sh
# Compatible: Linux y FreeBSD (solo sh)
# Convierte videos a múltiples formatos, resoluciones y FPS
# Solo genera versiones con resolución y FPS menores o iguales al original
###############################################################################
set -u
OUTPUT_DIR="convertidos"
FORMATOS="mp4 mkv webm"
FPS_LIST="60 55 50 45 40 35 30 25 24"
#RESOLUCIONES="3840x2160 2560x1440 1920x1080 1280x720 854x480 640x360"
RESOLUCIONES="1920x1080 1280x720 854x480 640x360"
# -------------------------------
# FUNCIONES
# -------------------------------
error() { printf 'ERROR: %s\n' "$*" >&2; }
info()  { printf '[INFO] %s\n' "$*"; }
verificar_dependencias() {
	command -v ffmpeg >/dev/null 2>&1 || { error "ffmpeg no está instalado."; exit 1; }
	command -v ffprobe >/dev/null 2>&1 || { error "ffprobe no está instalado."; exit 1; }
}
crear_directorio_salida() {
	[ ! -d "$OUTPUT_DIR" ] && mkdir -p "$OUTPUT_DIR"
}
obtener_fps_video() {
	archivo="$1"
	fps_raw=$(ffprobe -v error -select_streams v:0 -show_entries stream=r_frame_rate \
		-of default=noprint_wrappers=1:nokey=1 "$archivo")
	# Calcular FPS si es fracción
	echo "$fps_raw" | awk -F/ '{ if(NF==2) printf "%.0f\n",$1/$2; else print $1 }'
}
obtener_resolucion_video() {
	archivo="$1"
	ffprobe -v error -select_streams v:0 -show_entries stream=width,height \
		-of csv=s=x:p=0 "$archivo"
}
obtener_nombre_base() {
	archivo="$1"
	nombre=$(basename "$archivo")
	echo "${nombre%.*}"
}
obtener_codec() {
	formato="$1"
	case "$formato" in
		mp4|mkv) echo "h264" ;;
		webm) echo "vp9" ;;
		*) echo "video" ;;
	esac
}
generar_nombre_salida() {
	base="$1"
	resolucion="$2"
	fps="$3"
	codec="$4"
	ext="$5"
	echo "$OUTPUT_DIR/${resolucion}_${fps}fps_${codec}-(${base}).${ext}"
}
convertir_video() {
	entrada="$1"
	salida="$2"
	resolucion="$3"
	fps="$4"
	formato="$5"
	case "$formato" in
		mp4)
			ffmpeg -i "$entrada" -vf "scale=$resolucion" -r "$fps" \
				-c:v libx264 -preset medium -crf 23 -c:a aac -movflags +faststart -y "$salida"
			;;
		mkv)
			ffmpeg -i "$entrada" -vf "scale=$resolucion" -r "$fps" \
				-c:v libx264 -preset medium -crf 23 -c:a copy -y "$salida"
			;;
		webm)
			ffmpeg -i "$entrada" -vf "scale=$resolucion" -r "$fps" \
				-c:v libvpx-vp9 -crf 32 -b:v 0 -c:a libopus -y "$salida"
			;;
		*)
			error "Formato no soportado: $formato"
			;;
	esac
}
procesar_video() {
	archivo="$1"
	[ ! -f "$archivo" ] && { error "Archivo no existe: $archivo"; return; }
	info "Procesando: $archivo"
	fps_original=$(obtener_fps_video "$archivo")
	resolucion_original=$(obtener_resolucion_video "$archivo")
	ancho_original=$(echo "$resolucion_original" | cut -dx -f1)
	alto_original=$(echo "$resolucion_original" | cut -dx -f2)
	base=$(obtener_nombre_base "$archivo")
	for formato in $FORMATOS; do
		codec=$(obtener_codec "$formato")
		for resolucion in $RESOLUCIONES; do
			ancho=$(echo "$resolucion" | cut -dx -f1)
			alto=$(echo "$resolucion" | cut -dx -f2)
			[ "$ancho" -le "$ancho_original" ] || [ "$alto" -le "$alto_original" ] || continue
			for fps in $FPS_LIST; do
				[ "$fps" -le "$fps_original" ] || continue
				# Evitar generar idéntico al original
				ext="${archivo##*.}"
				if [ "$fps" -eq "$fps_original" ] && [ "$ancho" -eq "$ancho_original" ] && [ "$alto" -eq "$alto_original" ] && [ "$formato" = "$ext" ]; then
					continue
				fi
				salida=$(generar_nombre_salida "$base" "$resolucion" "$fps" "$codec" "$formato")
				info "Generando: $(basename "$salida")"
				convertir_video "$archivo" "$salida" "$resolucion" "$fps" "$formato"
			done
		done
	done
}
mostrar_uso() {
	cat << EOF
Uso:
	$0 video1.mp4 video2.mkv ...
Los archivos convertidos se guardarán en: $OUTPUT_DIR
EOF
}
procesar_todos() {
	if [ "$#" -eq 0 ]; then
		mostrar_uso
		exit 1
	fi
	for archivo in "$@"; do
		procesar_video "$archivo"
	done
}
# -------------------------------
# PUNTO DE ENTRADA
# -------------------------------
main() {
	verificar_dependencias
	crear_directorio_salida
	read -r
	procesar_todos "./7680_4320_120fps.mp4"
	info "¡Proceso finalizado!"
}
main
exit 0