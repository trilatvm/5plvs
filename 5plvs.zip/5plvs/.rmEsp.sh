#!/bin/sh
set -e
#
# renombrar_espacios.sh
#
# Reemplaza espacios por "_" en nombres de archivos y directorios.
# Compatible con POSIX sh, GNU/Linux y FreeBSD.
#
# VARIABLES GLOBALES
directorio_actual=""
ultimo_directorio="./"
# FUNCIONES DE MENSAJERÍA
informar() {
	printf '[INFO] %s\n' "$*"
}
advertir() {
	printf '[AVISO] %s\n' "$*" >&2
}
error() {
	printf '[ERROR] %s\n' "$*" >&2
}
# FUNCIONES DE VALIDACIÓN
validar_directorio() {
	[ -d "$directorio_actual" ]
}
# FUNCIONES DE RENOMBRADO
generar_nombre_nuevo() {
	printf '%s' "$1" | tr ' ' '_'
}
renombrar_elemento() {
	ruta=$1
	nombre=$(basename "$ruta")
	padre=$(dirname "$ruta")
	nombre_nuevo=$(generar_nombre_nuevo "$nombre")
	#
	# No requiere cambios.
	#
	[ "$nombre" = "$nombre_nuevo" ] && return 0
	ruta_nueva=$padre/$nombre_nuevo
	#
	# Evitar sobrescrituras.
	#
	if [ -e "$ruta_nueva" ]; then
		advertir "Omitido (destino existente):"
		printf '  %s\n' "$ruta"
		return 0
	fi
	#
	# GNU mv y FreeBSD mv.
	#
	if mv -- "$ruta" "$ruta_nueva" 2>/dev/null ||
	   mv "$ruta" "$ruta_nueva" 2>/dev/null
	then
		printf '%s\n' '--------------------------------------------------'
		printf 'RENOMBRADO\n'
		printf '  ANTES   : %s\n' "$ruta"
		printf '  DESPUÉS : %s\n' "$ruta_nueva"
	else
		error "No fue posible renombrar:"
		printf '  %s\n' "$ruta" >&2
	fi
}
procesar_directorio() {
	find "$directorio_actual" -depth |
	while IFS= read -r elemento
	do
		renombrar_elemento "$elemento"
	done
}
# FUNCIONES INTERACTIVAS
solicitar_directorio() {
	while :; do
		if [ -n "$ultimo_directorio" ]; then
			printf 'Ingresar directorio para remover espacios [%s]: ' "$ultimo_directorio"
		else
			printf 'Ingresar directorio para remover espacios: '
		fi
		read -r entrada
		#
		# Enter = reutilizar último directorio.
		#
		if [ -z "$entrada" ] && [ -n "$ultimo_directorio" ]; then
			entrada=$ultimo_directorio
		fi
		directorio_actual=$entrada
		if validar_directorio; then
			ultimo_directorio=$directorio_actual
			return 0
		fi
		advertir "Directorio inválido."
	done
}
preguntar_continuar() {
	respuesta='s'
	printf '\n¿Procesar otro directorio? [s/N]: '
	read -r respuesta
	case $respuesta in
		s|S|si|SI|Si|sI)
			return 0
			;;
		*)
			return 1
			;;
	esac
}
# FUNCIÓN PRINCIPAL
iniciar() {
	informar "--- INICIO ---"
	while :; do
		clear
		sync
		solicitar_directorio
		informar "Analizando: $directorio_actual"
		procesar_directorio
		informar "Proceso finalizado."
		preguntar_continuar || break
	done
	informar "--- FIN    ---"
}
# INICIO
iniciar
exit 0
