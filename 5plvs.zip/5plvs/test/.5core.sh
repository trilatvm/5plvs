#!/bin/sh
# .5core.sh: Nucleo del sistema y gestion de herencia de propiedades
set +e
roj="\033[1;91m" ; ama="\033[1;93m" ; ver="\033[1;92m" ; cia="\033[1;36m" ; mag="\033[1;95m" ; bla="\033[1;97m" ; rst="\033[0m"
obtenerTimestamp() { date '+[%Y-%m-%d %H:%M:%S]' ; }
limpiarConsola() { printf "\033[H\033[2J" && sync 2>/dev/null || true ; }
logMensaje() { printf "%s [%-3s] %s${rst}\n" "$(obtenerTimestamp)" "$1" "$2" ; }
logOk() {  logMensaje "$ver" "OK " "$1" ; }
logErr() { logMensaje "$roj" "ERR" "$1" ; }
logInf() { logMensaje "$ama" "INF" "$1" ; }
logDat() { logMensaje "$cia" "DAT" "$1" ; }
heredarAtributosPadre() {
	dirOrigen="${1:-.}"
	dirDestino="${2:-./backup_salida}"
	maxNivelRecursion=${3:-5}
	ignorarOcultos=${4:-true}
	logInf "Propiedades base heredadas al modulo hijo de forma exitosa." ; }
