#!/bin/sh
# .5worker.sh: Compartimentacion de procesos de compresion e indexado
ejecutarEmpaquetadoRobusto() {
	_wkItem=$1
	_wkPeso=$2
	_wkBaseName=$(basename "$_wkItem")
	_wkDestinoReal="$dirDestino/Arc_${_wkBaseName}.tar.gz"
	logInf "Procesando elemento: $_wkBaseName ($_wkPeso MB)"
	if [ -f "$_wkDestinoReal" ]; then
		logInf "El respaldo ya existe para $_wkBaseName. Saltando escritura."
		return 0
	fi
	_wkRet=1
	tar -czf "$_wkDestinoReal" -C "$(dirname "$_wkItem")" "$_wkBaseName" >/dev/null 2>&1 && _wkRet=0
	if [ "$_wkRet" -eq 0 ]; then
		logOk "Contenedor de respaldo consolidado con exito: $_wkDestinoReal"
		conteoExitos=$((conteoExitos + 1))
	else
		logErr "Fallo critico al intentar empaquetar de forma aislada: $_wkBaseName"
		conteoFallos=$((conteoFallos + 1))
	fi ; }
