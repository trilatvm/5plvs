#!/bin/sh
# .5bckp.sh: Orquestador Maestro de la Suite Modular
directorioScript=$(dirname "$0") ; directorioScript=$(cd "$directorioScript" && pwd)
if [ -f "$directorioScript/.5core.sh" ]; then . "$directorioScript/.5core.sh" ; else printf "[ERR] Clase base de nucleo ausente.\n" ; exit 1 ; fi
if [ -f "$directorioScript/.5scanner.sh" ] && [ -f "$directorioScript/.5worker.sh" ] && [ -f "$directorioScript/.5bckpCli.sh" ]; then
	. "$directorioScript/.5scanner.sh" ; . "$directorioScript/.5worker.sh" ; . "$directorioScript/.5bckpCli.sh"
else logErr "Submódulos especificos de la suite ausentes." ; exit 1 ; fi
opcionPorDefecto="1" ; filtroExtension="" ; listaTemporalEscaneo="$directorioScript/scan_db.tmp"
heredarAtributosPadre "$directorioScript" "$directorioScript/backup_salida" 5 true
asegurarDirectorio "$dirDestino"
while true; do
	mostrarMenuPrincipal ; capturarEntradaUsuario
	if [ "$seleccionInput" = "q" ] || [ "$seleccionInput" = "Q" ]; then logInf "Cierre de sesión del motor de respaldos." && break ; fi
	if [ "$seleccionInput" = "1" ]; then
		logInf "Iniciando escaneo recursivo e indexación..."
		rm -f "$listaTemporalEscaneo" && touch "$listaTemporalEscaneo"
		conteoExitos=0 ; conteoFallos=0 ; iniciarCronometro
		escanearEstructuraRecursiva "$dirOrigen" 1
		if [ -f "$listaTemporalEscaneo" ] && [ -s "$listaTemporalEscaneo" ]; then
			logOk "Indexacion completa. Iniciando empaquetado compartimentado de elementos..."
			while IFS="|" read -r filaRuta filaPeso; do
				[ -z "$filaRuta" ] && continue
				ejecutarEmpaquetadoRobusto "$filaRuta" "$filaPeso"
			done < "$listaTemporalEscaneo"
			rm -f "$listaTemporalEscaneo"
			logOk "Lote de ejecucion procesado masivamente."
			printf "Respaldos correctos: %s | Bloqueos detectados: %s\n" "$conteoExitos" "$conteoFallos"
		else
			rm -f "$listaTemporalEscaneo"
			logInf "La busqueda recursiva no arrojo ningun elemento bajo el criterio configurado."
		fi
		mostrarTiempoTranscurrido ; esperarEnter
	elif [ "$seleccionInput" = "2" ]; then
		printf "\n" ; logInf "Filtro activo (ej: zip, sh, txt o vacio para todo): " ; read -r extInput
		filtroExtension=$(echo "$extInput" | tr -d '[:space:].') ; logOk "Filtro modificado." ; esperarEnter
	elif [ "$seleccionInput" = "3" ]; then
		printf "\n" ; logInf "Profundidad maxima de recursion permitida (numero entero del 1 al 9): " ; read -r nivelInput
		nivelInput=$(echo "$nivelInput" | tr -cd '0-9')
		if [ -n "$nivelInput" ] && [ "$nivelInput" -gt 0 ]; then maxNivelRecursion=$nivelInput ; logOk "Limite recursivo fijado." ; else logErr "Valor invalido asignado." ; fi
		esperarEnter
	else logErr "Criterio de opcion invalida." ; esperarEnter ; fi
done
exit 0
