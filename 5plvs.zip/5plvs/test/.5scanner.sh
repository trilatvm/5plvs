#!/bin/sh
# .5scanner.sh: Escaner recursivo puro sin dependencias externas
escanearEstructuraRecursiva() {
	_esDirActual=$1
	_esNivelAct=$2
	if [ "$_esNivelAct" -gt "$maxNivelRecursion" ]; then
		logInf "Limite de recursion alcanzado en nivel $_esNivelAct. Saltando subárbol."
		return 0
	fi
	for _esItem in "$_esDirActual"/*; do
		if [ ! -e "$_esItem" ]; then continue ; fi
		_esNombre=$(basename "$_esItem")
		if [ "$ignorarOcultos" = "true" ]; then
			case "$_esNombre" in .*) continue ;; esac
		fi
		if [ -d "$_esItem" ] && [ ! -L "$_esItem" ]; then
			logDat "Directorio hallado de nivel $_esNivelAct: $_esItem"
			escanearEstructuraRecursiva "$_esItem" "$((_esNivelAct + 1))"
		elif [ -f "$_esItem" ]; then
			_esExt=$(printf "%s" "$_esNombre" | awk -F. '{if (NF>1) print $NF}')
			if [ -n "$filtroExtension" ] && [ "$_esExt" != "$filtroExtension" ]; then continue ; fi
			_esBytes=$(wc -c < "$_esItem" 2>/dev/null | tr -cd '0-9')
			_esMB=$(( ${_esBytes:-0} / 1048576 ))
			printf "%s|%s\n" "$_esItem" "$_esMB" >> "$listaTemporalEscaneo"
		fi
	done ; }
