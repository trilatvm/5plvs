#!/bin/sh
# .5bckpCli.sh: Capa de entrada e interfaz interactiva vertical
mostrarMenuPrincipal() {
	limpiarConsola
	printf "${mag}%s${rst}\n" "=== SISTEMA DE RESPALDO RECURSIVO MODULAR ==="
	printf "Directorio Origen  : %s\n" "$dirOrigen"
	printf "Directorio Destino : %s\n" "$dirDestino"
	printf "Filtro Extension   : %s\n" "${filtroExtension:-NINGUNO (PROCESA TODO)}"
	printf "Nivel Recursion Max: %s\n" "$maxNivelRecursion"
	printf "--------------------------------------------------\n"
	printf "%s\n" "1) Ejecutar busqueda recursiva y empaquetado masivo"
	printf "%s\n" "2) Cambiar extension del filtro de trabajo"
	printf "%s\n" "3) Configurar limite maximo de profundidad recursiva"
	printf "%s\n" "Q) Salir del motor operacional"
	printf "--------------------------------------------------\n" ; }
capturarEntradaUsuario() { printf "${ama}[SISTEMA] Seleccione opcion [%s]: ${rst}" "$opcionPorDefecto" ; read -r seleccionInput ; [ -z "$seleccionInput" ] && seleccionInput=$opcionPorDefecto ; opcionPorDefecto=$seleccionInput ; }
