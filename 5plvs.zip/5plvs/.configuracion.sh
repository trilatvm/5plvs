#!/bin/sh
set -eu