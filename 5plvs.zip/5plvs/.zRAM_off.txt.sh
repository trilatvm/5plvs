Para eliminar zram por completo de tu box con Armbian (o similar para Rockchip), debés desactivar los bloques activos y deshabilitar el servicio que los genera automáticamente al arrancar.
Seguí estos pasos en tu terminal:
## 1. Desactivar el espacio de intercambio (Swap) actual
Primero, apagá la memoria swap que está corriendo en zram0:
sudo swapoff /dev/zram0
## 2. Desmontar los directorios en ZRAM
Tenés zram1 montado en /var/log. Para evitar pérdida de datos o errores, vualca los logs actuales al disco (si el script de Armbian lo soporta) y desmontalo:
sudo systemctl stop armbian-zram-config.service 2>/dev/null
sudo umount /var/log
(Nota: Si /var/log está ocupado, es posible que debas reiniciar después del paso 3 para que se libere por completo).
## 3. Deshabilitar el servicio del sistema
En las distribuciones para placas Rockchip, ZRAM suele ser gestionado por un servicio llamado armbian-zram-config o zram-config. Copiá y ejecutá estos comandos para detenerlos y enmascararlos (evita que se vuelvan a activar):
sudo systemctl disable armbian-zram-config.service
sudo systemctl mask armbian-zram-config.service
sudo systemctl disable zram-config.service
sudo systemctl mask zram-config.service
## 4. Modificar la configuración de Armbian (Si aplica)
Si tu sistema usa el archivo de configuración global de Armbian, debés editarlo para indicarle que no use ZRAM:
   1. Abrí el archivo: sudo nano /etc/default/armbian-zram-config o sudo nano /etc/default/armbian-hardware (dependiendo de la versión).
   2. Buscá las líneas ENABLED=true o ZRAM_ENABLED=true y cambialas a false.
   3. Guardá los cambios presionando Ctrl + O, Enter, y salí con Ctrl + X.
## 5. Reiniciar y verificar
Reiniciá el dispositivo para aplicar los cambios de forma definitiva:
sudo reboot
Cuando vuelva a encender, ejecutá free -h y lsblk. La sección de Inter: (Swap) debería figurar en 0 y los dispositivos zram0, zram1 y zram2 ya no tendrían que aparecer en la lista.
Si querés avanzar, decime:
* ¿Querés crear un archivo Swap tradicional en la memoria interna para no quedarte sin memoria de intercambio?
* ¿Te tiró algún error de lectura/escritura al desmontar /var/log?
