#!/bin/sh

# Detener el script si ocurre un error
set -e

aux=""

getTiempo(){
	date "+%s"
}

respaldar_repo() {
	TS=$(getTiempo)
	BACKUP_DIR="/home/respaldo/etc/apt"
	mkdir -p "$BACKUP_DIR"
	BACKUP_FILE="$BACKUP_DIR/sources.list_$TS"
	echo "Creando respaldo de /etc/apt/sources.list en $BACKUP_FILE..."
	sudo cp /etc/apt/sources.list "$BACKUP_FILE"
}

agregar_repo() {
	# Sobrescribir sources.list con repositorios de Debian Bookworm
	echo "Escribiendo nuevos repositorios en /etc/apt/sources.list..."
	sudo sh -c "cat > /etc/apt/sources.list" << EOF
# +----> Repositorio de Debian 12 (Bookworm) en mirrors.ocf.berkeley.edu
# Este espejo pertenece a la organización estudiantil OCF de la Universidad de Berkeley.
# Es un servidor confiable y rápido para descargar paquetes y actualizaciones.
deb https://mirrors.ocf.berkeley.edu/debian/ bookworm main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian/ bookworm main contrib non-free
# Repositorio de seguridad de Debian 12 en mirrors.ocf.berkeley.edu
# Este repositorio contiene las actualizaciones de seguridad para Debian 12.
deb https://mirrors.ocf.berkeley.edu/debian-security/ bookworm-security main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian-security/ bookworm-security main contrib non-free
# Repositorio de actualizaciones en mirrors.ocf.berkeley.edu
# Este espejo también contiene actualizaciones regulares para paquetes de Debian.
deb https://mirrors.ocf.berkeley.edu/debian/ bookworm-updates main contrib non-free
deb-src https://mirrors.ocf.berkeley.edu/debian/ bookworm-updates main contrib non-free
# +----> Repositorio de Debian 12 (Bookworm) en debian.csail.mit.edu
# Este espejo pertenece al MIT (Massachusetts Institute of Technology), específicamente al laboratorio CSAIL (Computer Science and Artificial Intelligence Laboratory).
# Es una opción confiable y de alto rendimiento, especialmente para usuarios en América del Norte.
deb https://debian.csail.mit.edu/debian/ bookworm main contrib non-free
deb-src https://debian.csail.mit.edu/debian/ bookworm main contrib non-free
# Repositorio de seguridad de Debian 12 en debian.csail.mit.edu
# Este es el repositorio que contiene las actualizaciones de seguridad para Debian 12 desde MIT.
deb https://debian.csail.mit.edu/debian-security/ bookworm-security main contrib non-free
deb-src https://debian.csail.mit.edu/debian-security/ bookworm-security main contrib non-free
# Repositorio de actualizaciones en debian.csail.mit.edu
# Este espejo también contiene actualizaciones regulares para paquetes de Debian.
deb https://debian.csail.mit.edu/debian/ bookworm-updates main contrib non-free
deb-src https://debian.csail.mit.edu/debian/ bookworm-updates main contrib non-free
EOF
}

actualizar() {
	archivo="$(getTiempo)""_update.log"
	sudo apt update | tee -a "$archivo"
	archivo="$(getTiempo)""_upgrade.log"
	sudo apt upgrade -y | tee -a "$archivo"
}

# Inicio
echo "Inicio script $(getTiempo)"
echo "Respaldando fuentes lista de paquetes..."
echo "Enter para continuar"
read aux
respaldar_repo
echo "Agregando fuentes a lista de paquetes..."
echo "Enter para continuar"
read aux
agregar_repo
#echo "Actualizando la lista de paquetes..."
#echo "Enter para continuar"
#read aux
#actualizar
echo "Fin script $(getTiempo)"
exit 0
