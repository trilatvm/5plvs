#!/bin/sh
# .5hsh.sh: Logica de hash
detectarAlgoritmosHashes() {
	daLH=""
#	for daAC in md5 sha1 sha224 sha256 sha384 sha512; do
	for daAC in md5 sha1 sha256 sha512; do
		if command -v "${daAC}sum" >/dev/null 2>&1; then daLH="$daLH $daAC" ; fi ; done
	printf "%s" "$daLH" ; }
calcularHash() {
	chRC=$1 ; chDT=$2 ; chTH=$3 ; chNB=$(basename "$chRC") ; chDD="$chDT/hashes/$chTH" ; asegurarDirectorio "$chDD" ; chAH="$chDD/$chNB.$chTH"
	if [ -f "$chAH" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "Archivo existente. Sobreescribir? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Omitido." ; return 0 ; fi ; fi
	mInf "Firmando $chTH..."
	chHP=$( "${chTH}sum" "$chRC" 2>/dev/null || echo "" )
	chHP=$(printf "%s" "$chHP" | awk '{print $1}')
	if [ -z "$chHP" ]; then mErr "Fallo de cálculo en archivo: $chNB" ; incMd5=$((incMd5 + 1)) ; verSemaforoHash ; return 0 ; fi
	printf "%s  %s\n" "$chHP" "$chNB" > "$chAH" ; mOk "Creado: hashes/$chTH/$chNB.$chTH" ; genMd5=$((genMd5 + 1)) ; verSemaforoHash ; }
verificarHash() {
	vhRC=$1 ; vhDT=$2 ; vhTH=$3 ; vhNB=$(basename "$vhRC") ; vhAH="$vhDT/hashes/$vhTH/$vhNB.$vhTH"
	if verificarArchivoLectura "$vhAH"; then
		mInf "Validando $vhTH..." ; vhHG=$(awk '{print $1}' "$vhAH")
		vhHC=$( "${vhTH}sum" "$vhRC" 2>/dev/null || echo "" )
		vhHC=$(printf "%s" "$vhHC" | awk '{print $1}')
		if [ -z "$vhHC" ]; then mErr "Error de lectura en sum: $vhNB" ; return 0 ; fi
		if [ "$vhHG" = "$vhHC" ]; then mOk "OK: $vhNB" ; corMd5=$((corMd5 + 1))
		else
			printf "%b%s %b[OBS]%b Almacenado: %b%s%b\n" "$nar" "$(obtenerTimestamp)" "$bla" "$rst" "\033[0;97m" "$vhHG" "$rst"
			printf "%b%s %b[OBS]%b Calculado:  %b%s%b\n" "$nar" "$(obtenerTimestamp)" "$bla" "$rst" "\033[0;91m" "$vhHC" "$rst"
			mErr "FALLO: $vhNB" ; incMd5=$((incMd5 + 1)) ; fi
	else mInf "Sin firma: $vhNB" ; fi
	verSemaforoHash ; }
