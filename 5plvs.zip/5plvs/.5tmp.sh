#!/bin/sh
# .5tmp.sh: Logica de tiempo y fecha
obtenerTimestamp() { printf "[%s]" "$(date '+%H:%M:%S')" ; }
iniciarCronometro() { cronometroInicio=$(date '+%s') ; }
mostrarTiempoTranscurrido() {
	mtCF=$(date '+%s') ; mtST=$(( mtCF - ${cronometroInicio:-mtCF} ))
	mtH=$((mtST / 3600)) ; mtR=$((mtST % 3600)) ; mtM=$((mtR / 60)) ; mtS=$((mtR % 60))
	mtTF=$(printf "%02d:%02d:%02d" "$mtH" "$mtM" "$mtS")
	printf "%b%s %b[INF]%b Tiempo: %b%s%b\n" "\033[0;33m" "$(obtenerTimestamp)" "\033[0;33m" "\033[0;33m" "\033[0;95m" "$mtTF" "\033[0;33m" ; }
