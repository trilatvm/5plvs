#!/bin/sh
set -eu
# ----------------------------------------------------------------- VAR
# Variable global para recordar directorio
directorio_actual="./"
# Colores ANSI
ROJO='\033[91m'; VERDE='\033[92m'; NARANJA='\033[33m'; #AMARILLO='\033[93m'; 
AMARILLO='\033[0m'; AZUL='\033[94m'; MAGENTA='\033[95m'; CIAN='\033[96m'; BLANCO='\033[97m'; #RESET='\033[0m';
RESET='\033[93m'
tsf= ; tsi= ; tsd= ;
tiempoI= ;
fechaf= ; fechai= ;
cntERR= ; cntGEN= ; cntVER= ;
# ----------------------------------------------------------------- FNC
adjT() {	# ajustar tiempo
	if date -s "2232-04-18 20:47:15" >/dev/null 2>&1; then
		tiempoI=$(get_tiempo)
		informar "Tiempo ajustado   :${tiempoI}"		# Éxito	else
		tiempoI=$(get_tiempo)
		informar "Tiempo NO ajustado:${tiempoI}"		# Fallo
	fi; sleep 3; }
get_fecha() { date +"%Y-%m-%d"; }
get_tiempo() { date +"%Y-%m-%d %H:%M:%S"; }
get_ts() { date +"%Y%m%d%H%M%S"; }
informar()  { printf "\n${MAGENTA}[INF]  %s${RESET}\n" "$*"; }
preguntar()  { printf "\n${VERDE}[PRG]  %s:${RESET}" "$*"; }
advertir()  { printf "\n${AMARILLO}[AVS] %s${RESET}\n" "$*" >&2; }
#solicitar()  { printf "\n${CIAN}%s'['%s']':${RESET}" "$*"; }
detectar_algoritmos() {	# Detectar todos los algoritmos disponibles
	algoritmos=""
	for a in md5 md5sum sha1 sha1sum sha256 sha256sum sha512 sha512sum b2sum cksum; do
		if command -v "$a" >/dev/null 2>&1; then
			case "$a" in
				md5|md5sum) algoritmos="$algoritmos md5" ;;
				sha1|sha1sum) algoritmos="$algoritmos sha1" ;;
				sha256|sha256sum) algoritmos="$algoritmos sha256" ;;
				sha512|sha512sum) algoritmos="$algoritmos sha512" ;;
				b2sum) algoritmos="$algoritmos b2sum" ;;
				cksum) algoritmos="$algoritmos cksum" ;;
			esac
		fi
	done
	[ -n "$algoritmos" ] || { advertir "No se encontró ningún algoritmo disponible."; exit 1; }
	informar "Algoritmos detectados:$algoritmos"; }
calcular_hash_A() {	# Calcular hash
	archivo=$1 algoritmo=$2
	case "$algoritmo" in
		md5) md5 -q "$archivo" 2>/dev/null || md5sum "$archivo" | cut -d' ' -f1 ;;
		sha1) sha1 -q "$archivo" 2>/dev/null || sha1sum "$archivo" | cut -d' ' -f1 ;;
		sha256) sha256 -q "$archivo" 2>/dev/null || sha256sum "$archivo" | cut -d' ' -f1 ;;
		sha512) sha512 -q "$archivo" 2>/dev/null || sha512sum "$archivo" | cut -d' ' -f1 ;;
		b2sum) b2sum "$archivo" | cut -d' ' -f1 ;;
		cksum) cksum "$archivo" | cut -d' ' -f1 ;;
	esac; }
calcular_hash() {	# Calcular hash formato estándar
	archivo=$1 algoritmo=$2
	case "$algoritmo" in
		md5) md5 -q "$archivo" 2>/dev/null || md5sum "$archivo" ;;
		sha1) sha1 -q "$archivo" 2>/dev/null || sha1sum "$archivo" ;;
		sha256) sha256 -q "$archivo" 2>/dev/null || sha256sum "$archivo" ;;
		sha512) sha512 -q "$archivo" 2>/dev/null || sha512sum "$archivo" ;;
		b2sum) b2sum "$archivo" ;;
		cksum) cksum "$archivo" ;;
	esac; }
mostrar_progreso() {	# Barra de progreso global
	porcentaje=$((tareas_procesadas * 100 / tareas_totales))
	completado=$((porcentaje * 50 / 100))
#	barra=$(printf '%*s' "$completado" "" | tr ' ' '█')
	barra=$(printf '%*s' "$completado" "" | tr ' ' '#')
	barra="$barra$(printf '%*s' $((50-completado)) "" | tr ' ' '-')"
#	printf "\r[%s] %3d%% (%d/%d)" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales" 
	printf "\r[%s] %3d%% (%d/%d)\t${ROJO}%s ERR ${NARANJA}%s GEN ${VERDE}%s VER ${RESET}" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales" "$cntERR" "$cntGEN" "$cntVER"
#	printf "[%s] %3d%% (%d/%d)" "$barra" "$porcentaje" "$tareas_procesadas" "$tareas_totales"
}
procesar_archivo_A() {	# Procesar archivo
	archivo=$1 dir=$2
	for a in $algoritmos; do
		dir_hash="$dir/.shall/$a"
		mkdir -p "$dir_hash"
		nombre_hash="$(basename "$archivo" | tr ' ' '_').$a"
		archivo_hash="$dir_hash/$nombre_hash"
		printf "\n${CIAN}[PRO]\t%s${RESET}\n" "$(basename "$archivo")"
		hash_actual=$(calcular_hash "$archivo" "$a" || true)
		if [ -z "$hash_actual" ]; then
			printf "${ROJO}[ERROR]${RESET} %s (%s)\n" "$archivo" "$a"
		elif [ -f "$archivo_hash" ]; then
			hash_guardado=$(cat "$archivo_hash")
			if [ "$hash_actual" = "$hash_guardado" ]; then
				cntVER=$((cntVER + 1))
				printf "${VERDE}[+++]\t${MAGENTA}%s\t${VERDE}%s${RESET}\n" "$a" "$hash_guardado"
#				printf "[CORRECTO]\t%s\n\t\tCAL:%s\n\t\tRGT:%s\n" "$archivo" "$hash_actual" "$hash_guardado" >> "./${tsi}_CRR.log"
			else
				cntERR=$((cntERR + 1))
				printf "${ROJO}[!!!]\t${MAGENTA}%s\t${BLANCO}%s\n\t\t${ROJO}%s${RESET}\n" "$a" "$hash_actual" "$hash_guardado"
				archNbr="${tsi}_ERR"
				archExt="log"
				arch="${archNbr}.${archExt}"
				rta="/home/$(whoami)/"
				mkdir -p $rta
				archRta="${rta}${arch}"
				printf "[INCORRECTO]\t%s\n\t\tCAL:%s\n\t\tRGT:%s\n" "$archivo" "$hash_actual" "$hash_guardado" >> "$archRta"
				informar "Guardado: $rta"
#				sleep 3
			fi
		else
			cntGEN=$((cntGEN + 1))
			printf '%s' "$hash_actual" > "$archivo_hash"
#			printf "${NARANJA}[GEN]\t${MAGENTA}%s\n\t${CIAN}%s\t${ROJO}%sERR ${NARANJA}%sGEN ${VERDE}%sVER ${RESET}\n" "$a" "$archivo" "$cntERR" "$cntGEN" "$cntVER"
			printf "${NARANJA}[GEN]\t${BLANCO}%s\t${CIAN}%s\n\t\t${CIAN}%s${RESET}\n" "$a" "$archivo_hash" "$hash_actual"
#			printf "[GENERAR]\t%s\n\t\tCAL:%s\n" "$archivo" "$hash_actual" >> "./${tsi}_GEN.log"
		fi
		tareas_procesadas=$((tareas_procesadas + 1))
		mostrar_progreso
	done; }
procesar_archivo() {	# Procesar archivo
	archivo=$1 dir=$2
	# Guardar directorio de ejecución original
	dir_origen=$(pwd) 
	for a in $algoritmos; do
		dir_hash="$dir/.shall/$a"
		mkdir -p "$dir_hash"
		# Conservar nombre real de archivo para hash
		nombre_base=$(basename "$archivo")
		nombre_hash="$nombre_base.$a"
		archivo_hash="$dir_hash/$nombre_hash"
		printf "\n${CIAN}[PRO]\t%s${RESET}\n" "$nombre_base"
		# Cambiar temporalmente directorio de archivo para que hash guarde ruta relativa './archivo'
		cd "$dir"
		hash_linea=$(calcular_hash "$nombre_base" "$a" || true)
		cd "$dir_origen"
		if [ -z "$hash_linea" ]; then
			printf "${ROJO}[ERROR]${RESET} %s (%s)\n" "$archivo" "$a"
			continue
		fi
		# Extraer únicamente valor hash hexadecimal para condicionales internas
		hash_actual=${hash_linea%% *}
		if [ -f "$archivo_hash" ]; then
			# Leer línea guardada y extraer valor hash numérico
			hash_linea_guardada=$(cat "$archivo_hash")
			hash_guardado=${hash_linea_guardada%% *}
				if [ "$hash_actual" = "$hash_guardado" ]; then
				cntVER=$((cntVER + 1))
				printf "${VERDE}[+++]\t${MAGENTA}%s\t${VERDE}%s${RESET}\n" "$a" "$hash_guardado"
			else
				cntERR=$((cntERR + 1))
				printf "${ROJO}[!!!]\t${MAGENTA}%s\t${BLANCO}%s\n\t\t${ROJO}%s${RESET}\n" "$a" "$hash_actual" "$hash_guardado"
				archNbr="${tsi}_ERR"
				archExt="log"
				arch="${archNbr}.${archExt}"
				rta="/home/$(whoami)/"
				mkdir -p "$rta"
				archRta="${rta}${arch}"
				printf "[INCORRECTO]\t%s\n\t\tCAL:%s\n\t\tRGT:%s\n" "$archivo" "$hash_actual" "$hash_guardado" >> "$archRta"
				informar "Guardado: $rta"
			fi
		else
			cntGEN=$((cntGEN + 1))
			# Guardar la línea con el formato estándar completo (Hash + Nombre)
			printf '%s\n' "$hash_linea" > "$archivo_hash"
			printf "${NARANJA}[GEN]\t${BLANCO}%s\t${CIAN}%s\n\t\t${CIAN}%s${RESET}\n" "$a" "$archivo_hash" "$hash_actual"
		fi
		tareas_procesadas=$((tareas_procesadas + 1))
		mostrar_progreso
	done; }
truncar_texto() {
	texto=$1
	margen=$2
	# Obtener columnas actual de terminal (por defecto 80)
	columnas=$(tput cols 2>/dev/null || echo 80)
	# Calcular espacio máximo disponible restando margen fijo de interfaz
	max_ancho=$((columnas - margen))
	if [ ${#texto} -gt $max_ancho ] && [ $max_ancho -gt 5 ]; then
		# Cortar cadena y concatenar puntos suspensivos
		printf '%s...' "$(echo "$texto" | cut -c 1-$((max_ancho - 3)))"
	else
		printf '%s' "$texto"
	fi; }
procesar_directorio() {	# Procesar directorio y subdirectorios
	archivos=$(find "$1" -type f ! -path "*/.shall/*")
	[ -z "$archivos" ] && return
	count=$(printf '%s\n' $archivos | wc -l)
	tareas_totales=$((count * $(set -- $algoritmos; echo $#)))
	tareas_procesadas=0
	for f in $archivos; do
		dir=$(dirname "$f")
		procesar_archivo "$f" "$dir"
	done
	printf "\n"
	informar "Procesamiento completado para $1"
}
iniciar() {	# Inicio
	tsi=$(get_ts)
	informar "=== Sistema de hashes .shall ==="
	detectar_algoritmos
	while :; do
		clear
		cntERR=$((0))
		cntGEN=$cntERR
		cntVER=$cntGEN
		if [ -n "$directorio_actual" ]; then
			printf "Ingresar directorio [$directorio_actual]:"
		else
			printf "Ingresar directorio:"
		fi
		read -r entrada
		[ -n "$entrada" ] && directorio_actual=$entrada
		[ -d "$directorio_actual" ] || { advertir "Directorio inválido"; sleep 3; continue; }
		procesar_directorio "$directorio_actual"
		preguntar '¿Procesar otro directorio? ["ENTER" Sí / "n" No]'
		read -r r
		case "$r" in n|N) break ;; esac
		sync
	done
	tsf=$(get_ts)
}
# ----------------------------------------------------------------- PPA
adjT
informar "--- INICIO ---"
iniciar
# ----------------------------------------------------------------- FIN
informar "--- FIN	---"
exit 0
