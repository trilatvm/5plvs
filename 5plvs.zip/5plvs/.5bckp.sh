#!/bin/sh
#set -e
# .5bckp.sh: Logica de negocio principal (Script Maestro)
directorioScript=$(dirname "$0") ; directorioScript=$(cd "$directorioScript" && pwd)
if [ -f "$directorioScript/.5cli.sh" ] && [ -f "$directorioScript/.5tmp.sh" ] && \
   [ -f "$directorioScript/.5arch.sh" ] && [ -f "$directorioScript/.5hash.sh" ] && \
   [ -f "$directorioScript/.5par2.sh" ] && [ -f "$directorioScript/.5rgx.sh" ]; then
	. "$directorioScript/.5cli.sh" ; . "$directorioScript/.5tmp.sh" ; . "$directorioScript/.5rgx.sh"
	. "$directorioScript/.5arch.sh" ; . "$directorioScript/.5hash.sh" ; . "$directorioScript/.5par2.sh"
else printf "\033[0;91m[ERR]\033[0;33m Módulos esenciales ausentes.\n" ; exit 1 ; fi
uG="1" ; uH="1" ; uP="1" ; uF="1" ; uE="1" ; ultimoAlgoritmo="md5" ; ultimoFiltroExtension=""
incMd5=0 ; genMd5=0 ; corMd5=0 ; incPar2=0 ; genPar2=0 ; corPar2=0
printf "\033[0;33m"
procesarBucleLote() {
	pblMM=$1 ; pblAM=$2 ; pblEM=$3 ; pblTL=$(contarArchivos "$pblEM" "$directorioActual") ; pblTL=$(echo "$pblTL" | tr -cd '0-9')
	if [ -z "$pblTL" ] || [ "$pblTL" -eq 0 ]; then mObs "Sin archivos para procesar."
	else
		pblCP=0
		for pblAO in "$directorioActual"/*; do
			if [ ! -f "$pblAO" ] || [ -d "$pblAO" ] || ! validarArchivoRegex "$pblAO" || ! validarExclusionEcosistema "$pblAO" || ! verificarArchivoLectura "$pblAO"; then continue ; fi
			if [ -n "$pblEM" ]; then case "$pblAO" in *."$pblEM") ;; *) continue ;; esac ; fi
			pblCP=$((pblCP + 1)) ; printf "\n" ; dibujarProgreso "$pblCP" "$pblTL" "$(basename "$pblAO")"
			if [ "$pblMM" = "hash" ]; then
				if [ "$pblAM" = "crear" ]; then calcularHash "$pblAO" "$directorioActual" "$ultimoAlgoritmo"
				elif [ "$pblAM" = "verificar" ]; then verificarHash "$pblAO" "$directorioActual" "$ultimoAlgoritmo" ; fi
			elif [ "$pblMM" = "par2" ]; then
				if [ "$pblAM" = "crear" ]; then calcularPar2 "$pblAO" "$directorioActual"
				elif [ "$pblAM" = "verificar" ]; then verificarPar2 "$pblAO" "$directorioActual"
				elif [ "$pblAM" = "reparar" ]; then repararPar2 "$pblAO" "$directorioActual" ; fi ; fi ; done ; fi ; }
ejecutarModoFull() {
	emfAF=$1 ; iniciarCronometro
	if [ "$emfAF" = "crear" ] || [ "$emfAF" = "remplazar" ]; then
		[ "$emfAF" = "remplazar" ] && modoFlujoSilencioso="activo" || modoFlujoSilencioso="desactivado"
		for alg in $hD; do mInf "Procesando lote HASH: $alg" ; ultimoAlgoritmo=$alg ; procesarBucleLote "hash" "crear" "$ultimoFiltroExtension" ; done
		mInf "Procesando lote PAR2..." ; procesarBucleLote "par2" "crear" "$ultimoFiltroExtension" ; modoFlujoSilencioso="desactivado"
	elif [ "$emfAF" = "verificar" ] || [ "$emfAF" = "reparar" ]; then
		modoFlujoSilencioso="activo"
		for alg in $hD; do
			mInf "Validando lote HASH: $alg"
			for emfAO in "$directorioActual"/*; do
				if [ ! -f "$emfAO" ] || [ -d "$emfAO" ] || ! validarArchivoRegex "$emfAO" || ! validarExclusionEcosistema "$emfAO"; then continue ; fi
				if [ -n "$ultimoFiltroExtension" ]; then case "$emfAO" in *."$ultimoFiltroExtension") ;; *) continue ;; esac ; fi
				emfFP="$directorioActual/hashes/$alg/$(basename "$emfAO").$alg"
				if [ ! -f "$emfFP" ]; then
					printf "\n" ; mPgt "Firma ausente ($alg) para $(basename "$emfAO"). ¿Generar? (s/n): " ; read -r rG
					if [ "$rG" = "s" ] || [ "$rG" = "S" ]; then calcularHash "$emfAO" "$directorioActual" "$alg" ; fi
				else verificarHash "$emfAO" "$directorioActual" "$alg" ; fi ; done ; done
		mInf "Verificando lote PAR2..." ; procesarBucleLote "par2" "$emfAF" "$ultimoFiltroExtension" ; modoFlujoSilencioso="desactivado" ; fi
	auditarFirmasHuerfanas "$directorioActual" "$hD" ; mOk "FULL completado." ; mostrarTiempoTranscurrido ; }
main() {
	verificarHerramientasPar2 ; hD=$(detectarAlgoritmosHashes) ; inicializarEntornoTrabajo "$directorioScript"
	while true; do
		mostrarMenuGeneral ; readOpcionGeneral
		if [ "$mO" = "q" ] || [ "$mO" = "Q" ]; then mInf "Fin." && break; fi
		if [ "$mO" = "c" ] || [ "$mO" = "C" ]; then ejecutarConmutacionDir && continue; fi
		if [ "$mO" = "1" ]; then
			while true; do
				mostrarMenuHash "$ultimoAlgoritmo" "$hD" ; readOpcionHash
				if [ "$hO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "2" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="verificar"; break;
				elif [ "$hO" = "3" ]; then modoFlujoSilencioso="activo"; sE="hash"; sA="crear"; break;
				elif [ "$hO" = "4" ]; then
					printf "\n" ; mPgt "Algoritmo: " ; read -r algoInput
					if ! validarAlgoritmoRegex "$algoInput"; then mErr "Sintaxis inválida." && read -r _
					else case " $hD " in *" $algoInput "*) ultimoAlgoritmo="$algoInput" ;; *) mErr "Ausente." && read -r _ ;; esac ; fi
				elif [ "$hO" = "v" ] || [ "$hO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "2" ]; then
			while true; do
				mostrarMenuPar2 ; readOpcionPar2
				if [ "$pO" = "1" ]; then modoFlujoSilencioso="desactivado"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "2" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="verificar"; break;
				elif [ "$pO" = "3" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="crear"; break;
				elif [ "$pO" = "4" ]; then modoFlujoSilencioso="activo"; sE="par2"; sA="reparar"; break;
				elif [ "$pO" = "v" ] || [ "$pO" = "V" ]; then sE=""; break ; fi ; done
			if [ -z "$sE" ]; then continue; fi ; procesarBucleLote "$sE" "$sA" "$ultimoFiltroExtension" ; esperarEnter
		elif [ "$mO" = "3" ]; then
			while true; do
				mostrarMenuFull ; readOpcionFull
				if [ "$fO" = "1" ]; then ejecutarModoFull "crear" ; break;
				elif [ "$fO" = "2" ]; then ejecutarModoFull "verificar" ; break;
				elif [ "$fO" = "3" ]; then ejecutarModoFull "remplazar" ; break;
				elif [ "$fO" = "4" ]; then ejecutarModoFull "reparar" ; break;
				elif [ "$fO" = "v" ] || [ "$fO" = "V" ]; then break ; fi ; done ; esperarEnter
		elif [ "$mO" = "4" ]; then
			while true; do
				mostrarMenuFiltro ; readOpcionFiltro
				if [ "$eO" = "1" ]; then
					printf "\n" ; mPgt "Extensión (sin punto): " ; read -r extInput
					if ! validarExtensionRegex "$extInput"; then mErr "Sintaxis de extensión inválida."
					else ultimoFiltroExtension=$(echo "$extInput" | tr -d '[:space:].') ; mOk "Filtro configurado." ; fi ; break
				elif [ "$eO" = "2" ]; then ultimoFiltroExtension="" ; mOk "Filtro removido." ; break
				elif [ "$eO" = "v" ] || [ "$eO" = "V" ]; then break ; fi ; done ; esperarEnter
		else mErr "Inválido." ; esperarEnter ; fi ; done ; }
main "$@"
exit 0
