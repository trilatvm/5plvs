#!/bin/sh
set -eu
#-------------------------------------------------------------------------------
ROJ='\033[91m'; AMA='\033[93m'; AZU='\033[94m'; # Colores ANSI
NAR='\033[33m'; VER='\033[92m'; MAG='\033[95m';
CIA='\033[96m'; BLA='\033[97m'; RES='\033[0m';
#-------------------------------------------------------------------------------
getFch(){ date +"%Y-%m-%d" ; } ; getHra(){ date +"%H-%M-%S" ; } ;
getT(){ date +"%Y-%m-%d %H:%M:%S" ; }
getTs(){ date +"%Y%m%d%H%M%S" ; }; getTse(){ date +"%s" ; }; 
setTs(){}
#-------------------------------------------------------------------------------
crearPar20(){ par2 c -r20 -m512 -s1048576 -t4 ./*.zip ; }
verifPar20(){ par2 v ./*.zip ; }
#restaPar2(){ par2 r -p ./*.zip ; }
restaPar20(){ par2 r ./*.zip ; }
main(){
	printf "\n\t\t${CIA}[$(getT)] %s${RES}\n" "SCRIPT INICIO" >&2;
	printf "\n\t\t${CIA}[$(getT)] %s${VER}\n" "CREAR PAR2" >&2;
	crearPar20 && sync
	printf "\n\t\t${CIA}[$(getT)] %s${MAG}\n" "VERIFICAR PAR2" >&2;
	verifPar20 && sync
	printf "\n\t\t${CIA}[$(getT)] %s${AMA}\n" "RECUPERAR PAR2" >&2;
	restaPar20 && sync
	printf "\n\t\t${CIA}[$(getT)] %s${RES}\n" "SCRIPT FIN" >&2;
}
#-------------------------------------------------------------------------------
main
#-------------------------------------------------------------------------------
exit 0