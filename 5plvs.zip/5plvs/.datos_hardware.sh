#!/bin/sh
set -e
#
uname -a
# Linux rk322x-box 6.18.44-current-rockchip #1 SMP Sun Aug  9 18:25:30 UTC 2026 armv7l GNU/Linux
#
cat /sys/class/mmc_host/mmc2/mmc2:*/life_time
# 0x01 0x01
#
mmc extcsd read /dev/mmcblk2 | grep -E "LIFE_TIME|PRE_EOL"
# eMMC Life Time Estimation A [EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_A]: 0x01
# eMMC Life Time Estimation B [EXT_CSD_DEVICE_LIFE_TIME_EST_TYP_B]: 0x01
# eMMC Pre EOL information [EXT_CSD_PRE_EOL_INFO]: 0x01
#
free -h
#                total        used        free      shared  buff/cache   available
# Mem:           1,9Gi       1,2Gi       364Mi       128Mi       550Mi       745Mi
# Swap:          2,0Gi       311Mi       1,7Gi
#
exit 0