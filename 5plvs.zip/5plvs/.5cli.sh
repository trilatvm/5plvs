#!/bin/sh
# .5cli.sh: Logica de consola y menus
roj="\033[0;91m" ; ama="\033[0;93m" ; ver="\033[0;92m" ; cia="\033[0;96m" ; mag="\033[0;95m" ; bla="\033[0;97m" ; rst="\033[0;33m"
#nar="\033[0;33m" ;	# naranja palido
nar="\033[1;38;5;202m" ;	# naranja brillante
mMsg() { printf "%b%s %b[%s]%b %b%s%b\n" "$nar" "$(obtenerTimestamp)" "$1" "$2" "$rst" "$3" "$4" "$rst" ; }
mOk() {  mMsg "$ver" " OK" "$ver" "$1" ; }
mErr() { mMsg "$roj" "ERR" "$roj" "$1" ; }
mInf() { mMsg "$nar" "INF" "$nar" "$1" ; }
mAdb() { mMsg "$nar" "ADV" "$ama" "$1" ; }
mPgt() { printf "%b%s %b[? ]%b %b%s" "$nar" "$(obtenerTimestamp)" "$mag" "$rst" "$ama" "$1" ; }
mObs() { mMsg "$bla" "OBS" "$nar" "$1" ; }
mObsErr() { mMsg "$bla" "OBS" "$nar" "$1" ; }
dibujarProgreso() {
	dpAct=$1 ; dpTot=$2 ; dpNom=$3
	[ -z "$dpTot" ] || [ "$dpTot" -le 0 ] && dpTot=1
	[ -z "$dpAct" ] && dpAct=0
	dpPorc=$(( (dpAct * 100) / dpTot )) ; dpMax=20
	dpLleno=$(( (dpPorc * dpMax) / 100 ))
	[ "$dpLleno" -gt "$dpMax" ] && dpLleno=$dpMax
	[ "$dpLleno" -lt 0 ] && dpLleno=0
	dpVac=$(( dpMax - dpLleno ))
	[ "$dpVac" -lt 0 ] && dpVac=0
	dpBP="####################" ; dpLP="--------------------"
	dpBar=$(printf "%.${dpLleno}s%.${dpVac}s" "$dpBP" "$dpLP")
	printf "%b%s %b[INF]%b [%b%s%b] %b%d%% (%d/%d)%b\n" "$nar" "$(obtenerTimestamp)" "$nar" "$rst" "$ama" "$dpBar" "$rst" "$nar" "$dpPorc" "$dpAct" "$dpTot" "$rst"
	printf "%b%s %b[INF]%b Arc: %b%.30s%b\n" "$nar" "$(obtenerTimestamp)" "$nar" "$rst" "$mag" "$dpNom" "$rst" ; }
flipColor(){ printf "%b" "$1" ; }
semaforo(){ printf "%b%s %b[INF]%b %b[%s] %b[%s] %b[%s]%b\n" "$nar" "$(obtenerTimestamp)" "$nar" "$rst" "$roj" "$1" "$ama" "$2" "$ver" "$3" "$rst" ; }
verSemaforoHash(){ semaforo "${incMd5:-0}" "${genMd5:-0}" "${corMd5:-0}" ; }
verSemaforoPar2(){ semaforo "${incPar2:-0}" "${genPar2:-0}" "${corPar2:-0}" ; }
esperarEnter() { printf "\n" && mInf "[ENTER]..." && read -r _ ; }
mostrarMenuGeneral() {
	printf "\033[H\033[2J" && sync ; printf "%b=== MONITOR INTEGRIDAD ===%b\n" "$ver" "$rst"
	mInf "Activo: $directorioActual" ; printf "\033[0;33mFiltro: [ %b%s%b ]\n" "$mag" "${ultimoFiltroExtension:-TODOS}" "$rst"
	printf "1) HASH (M1)\n2) PAR2 (M2)\n3) FULL (M3)\n4) FILTRO\nC) CAMBIAR DIR\nQ) SALIR\n" ; }
readOpcionGeneral() { printf "%b[SYS]%b [%b%s%b]: " "$nar" "$rst" "$mag" "$uG" "$rst" ; read -r mO ; [ -z "$mO" ] && mO=$uG ; uG=$mO ; }
mostrarMenuHash() {
	printf "\033[H\033[2J" ; printf "%b=== GESTION HASH ===%b\n" "$cia" "$rst"
	printf "\033[0;33mAlgoritmo: [ %b%s%b ] | Disponibles: [ %b%s%b ]\n" "$mag" "$1" "$rst" "$mag" "$2" "$rst"
	printf "1) CALCULAR\n2) VERIFICAR\n3) REMPLAZAR\n4) CAMBIAR ALGO\nV) VOLVER\n" ; }
readOpcionHash() { printf "%b[SYS]%b [%b%s%b]: " "$nar" "$rst" "$mag" "$uH" "$rst" ; read -r hO ; [ -z "$hO" ] && hO=$uH ; uH=$hO ; }
mostrarMenuPar2() {
	printf "\033[H\033[2J" ; printf "%b=== GESTION PAR2 ===%b\n" "$mag" "$rst"
	printf "1) CALCULAR\n2) VERIFICAR\n3) REMPLAZAR\n4) REPARAR\nV) VOLVER\n" ; }
readOpcionPar2() { printf "%b[SYS]%b [%b%s%b]: " "$nar" "$rst" "$mag" "$uP" "$rst" ; read -r pO ; [ -z "$pO" ] && pO=$uP ; uP=$pO ; }
mostrarMenuFull() {
	printf "\033[H\033[2J" ; printf "%b=== MODO FULL ===%b\n" "$cia" "$rst"
	printf "1) CALCULAR\n2) VERIFICAR\n3) REMPLAZAR\n4) REPARAR\nV) VOLVER\n" ; }
readOpcionFull() { printf "%b[SYS]%b [%b%s%b]: " "$nar" "$rst" "$mag" "$uF" "$rst" ; read -r fO ; [ -z "$fO" ] && fO=$uF ; uF=$fO ; }
mostrarMenuFiltro() {
	printf "\033[H\033[2J" ; printf "%b=== FILTRO EXTENSION ===%b\n" "$ama" "$rst"
	printf "\033[0;33mFiltro: [ %b%s%b ]\n" "$mag" "${ultimoFiltroExtension:-TODO}" "$rst"
	printf "1) DEFINIR\n2) LIMPIAR\nV) VOLVER\n" ; }
readOpcionFiltro() { printf "%b[SYS]%b [%b%s%b]: " "$nar" "$rst" "$mag" "$uE" "$rst" ; read -r eO ; [ -z "$eO" ] && eO=$uE ; uE=$eO ; }
ejecutarCambioAlgoritmo() {
	printf "\n" ; mPgt "Algoritmo: " ; read -r algoInput
	case " $1 " in *" $algoInput "*) ultimoAlgoritmo="$algoInput" ;; *) mErr "Inválido." && read -r _ ;; esac ; }
ejecutarConfiguracionFiltro() {
	printf "\n" ; mPgt "Extensión (sin punto): " ; read -r extInput
	ultimoFiltroExtension=$(echo "$extInput" | tr -d '[:space:].') ; mOk "Filtro configurado." ; }
