#!/bin/sh
set -e
crearSwap(){
	imp "# 0. Vaciar memoria reservada"
	sync && echo 3 > /proc/sys/vm/drop_caches
	imp "# 1. Crear archivo de 2 Gigabytes"
	dd if=/dev/zero of=/swapfile bs=1M count=2048
	imp "# 2. Otorgar permisos correctos de seguridad"
	chmod 600 /swapfile
	imp "# 3. Formatear como área de intercambio"
	mkswap /swapfile
	imp "# 4. Activar en sistema"
	swapon /swapfile
	imp "# 5. Visualizar cambios"
	free -h
}
imp(){
	printf "%s\n" "$@"
}
main(){
	clear
	imp "--- SCRITP INICIO ---"
	crearSwap
	sync
	imp "--- SCRITP    FIN ---"
}
main
exit 0