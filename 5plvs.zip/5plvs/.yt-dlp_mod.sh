El log de la terminal expone dos problemas críticos que están afectando tu descarga: un bloqueo por exceso de peticiones (HTTP Error 429) y la desconexión total del motor de JavaScript de Node.js en las llamadas internas de yt-dlp.

Diagnóstico de los Errores


Síntoma en el Log	Causa Raíz	Impacto en la TV Box
ERROR: ... HTTP Error 429: Too Many Requests	YouTube detectó ráfagas consecutivas de descargas provenientes de tu IP (especialmente al descargar múltiples idiomas de subtítulos simultáneamente: it, la, etc.).	Bloqueo temporal de tu dirección IP pública para la descarga de metadatos/subtítulos.
WARNING: [youtube] No supported JavaScript runtime could be found.	yt-dlp perdió el acceso al entorno de ejecución de Node. El script no está inyectando correctamente el flag --js-runtimes node en la evaluación de la tercera URL o el ejecutable de Node no es accesible globalmente desde ese subproceso.	Grave. Provoca fallos de extracción, formatos faltantes y aceleración de bloqueos (Error 429), ya que YouTube requiere resolver desafíos de código mediante el motor EJS.


Soluciones Paso a Paso


1. Corregir la pérdida del Runtime de Node.js

yt-dlp utiliza por defecto el motor de JavaScript llamado Deno. Como tu TV Box tiene instalado Node v18.20.4, es mandatorio forzar explícitamente su uso pasándole el argumento correcto al comando principal dentro de tu script .des.sh.
Además, es altamente recomendable habilitar los componentes remotos de NPM para que pueda descargar los descifradores actualizados automáticamente en caliente. [1] (/goto?url=CAESwAEB6zswFb_8y_M9wccGjxE1UeMFgKglE1WNkHvoYiwH1-2PASB8Rv9E28TrsWGwgNZJBAbPnUVDEQlzkngIpMDdSDFlHq1iz2iGlBXhgfI84JhZ8NfUohNKWYO11UpsxZ9iO88eNozvqS56DDwl5xK56lAS5hgS-ZrXmlzbFimgUlfnfDIchYHPK4Pir-8sly3Xs9uSdznFxDZXV9tIe1JfdH8GQc8XgfkH2uGQ5MJlkNzcwn0aEUProRo5FFtgfiQ)
Modificá la llamada de yt-dlp en tu función procesarCarpetaEspecifica() agregando estas dos líneas:
sh
	yt-dlp \
		--js-runtimes node \
		--remote-components ejs:npm \
		-f "bv*[vcodec*=avc1][height<=360]+ba/bv*[height<=360]+ba/b" \
        # ... (el resto de tus parámetros se mantienen igual)
Usa el código con precaución.
Nota: Asegurate de que el comando node responda de forma global. Si el script sigue arrojando el Warning, reemplazá --js-runtimes node por la ruta absoluta donde se aloja el binario en tu sistema, por ejemplo: --js-runtimes "node:/usr/bin/node". [1] (/goto?url=CAESywEB6zswFRNDNIy4HPhCGXGOubVh_GgDwffjwnwNgQeq_tEdFqh79nABk9W7RoUh_yyP2wQ8vPf4JTWg9kiU5rljXn2_WleviCjuICOOR60wV-ClK43bOyXRXltCjh9sexEHW42EdElYTk9cXhE_yoAYGWF860wFWoZVRwsuWfK6Bd9VaMEvhrN8LAbRsKiZa_K-6qS_w1gNmInwT7rXNqVbRA_oKMZYnZWkfd6V-9pMTIVZv-4UAfcw8GiWQ7aibixaDjfUFNsT0ksx8Q)

2. Mitigar el Bloqueo de Red (HTTP 429)

Estás solicitando 5 idiomas en subtítulos (en,es,it,la,zh-Hans). Cada idioma representa una petición web independiente hacia YouTube por cada video de la lista de reproducción. Para que no te cataloguen como un bot de spam, debés incrementar drásticamente los intervalos de descanso en el script:
Modificá tus variables de tiempo actuales por los siguientes valores preventivos:
sh
		--sleep-interval 10 \
		--max-sleep-interval 20 \
		--sleep-subtitles 5 \
		--sleep-requests 2 \
Usa el código con precaución.
Esto simulará un comportamiento humano y evitará la saturación de conexiones en la modesta pila de red del dispositivo.
¿Deseás que te proporcione el bloque completo modificado de la función procesarCarpetaEspecifica() listo para copiar y pegar en tu archivo .des.sh, o preferís probar la accesibilidad de la ruta de Node de forma manual en la consola?
