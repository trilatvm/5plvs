#!/bin/sh
set -e
clear
zip -r9vT ./5plvs_$(date +"%s").zip ./.*.sh
#zip -s23m -r9vT ./5plvs_$(date +"%s").zip ./.*.sh
#zip -s0 ./*.zip --out *.zip
sync
exit 0
