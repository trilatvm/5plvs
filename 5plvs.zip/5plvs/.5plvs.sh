#!/bin/sh
set -eu
# ----------------------------------------------------------------- VAR
. ./.src/.archivo.sh
. ./.src/.color.sh
. ./.src/.os.sh
. ./.src/.tiempo.sh
. ./.src/.apk.sh
. ./.src/.info.sh
. ./.src/.pantalla.sh
. ./.src/.recursos.sh
. ./.src/.configuracion.sh
. ./.src/.hash.sh
# ----------------------------------------------------------------- VAR
# ----------------------------------------------------------------- FNC
inicializar(){ buffer; pantalla; inf "SCRIPT Inicio $(getFecha)";}
finalizar(){ buffer; inf 'SCRIPT Fin'; }
tstColor(){ inf 'Completado'; prg '¿Reiniciar PC?'; adv 'Procesado'; err 'Cancelado'; }
tst(){
	tstColor
}
main(){
	inicializar
# --------------------------- #
	tst
# --------------------------- #
	sleep 15
# --------------------------- #
	finalizar
}
# ----------------------------------------------------------------- FNC
# ----------------------------------------------------------------- PPA
main
# ----------------------------------------------------------------- PPA
# ----------------------------------------------------------------- FIN
exit 0
# ----------------------------------------------------------------- FIN
# ----------------------------------------------------------------- VAR
# Variable global para recordar directorio
directorio_actual="./"
tsf= ; tsi= ; tsd= ;
tiempoI= ;
fechaf= ; fechai= ;
cntERR= ; cntGEN= ; cntVER= ;
# ----------------------------------------------------------------- FNC
informar()  { printf "\n${MAGENTA}[INF]  %s${RESET}\n" "$*"; }
preguntar()  { printf "\n${VERDE}[PRG]  %s:${RESET}" "$*"; }
advertir()  { printf "\n${AMARILLO}[AVS] %s${RESET}\n" "$*" >&2; }
#solicitar()  { printf "\n${CIAN}%s'['%s']':${RESET}" "$*"; }
calcular_hash() {	# Calcular hash
	archivo=$1 algoritmo=$2
	case "$algoritmo" in
		md5) md5 -q "$archivo" 2>/dev/null || md5sum "$archivo" | cut -d' ' -f1 ;;
		sha1) sha1 -q "$archivo" 2>/dev/null || sha1sum "$archivo" | cut -d' ' -f1 ;;
		sha256) sha256 -q "$archivo" 2>/dev/null || sha256sum "$archivo" | cut -d' ' -f1 ;;
		sha512) sha512 -q "$archivo" 2>/dev/null || sha512sum "$archivo" | cut -d' ' -f1 ;;
		b2sum) b2sum "$archivo" | cut -d' ' -f1 ;;
		cksum) cksum "$archivo" | cut -d' ' -f1 ;;
	esac; }
iniciar() {	# Inicio
	tsi=$(get_ts)
	informar "=== Sistema de hashes .shall ==="
	detectar_algoritmos
	while :; do
		clear
		cntERR=$((0))
		cntGEN=$cntERR
		cntVER=$cntGEN
		if [ -n "$directorio_actual" ]; then
			printf "Ingresar directorio [$directorio_actual]:"
		else
			printf "Ingresar directorio:"
		fi
		read -r entrada
		[ -n "$entrada" ] && directorio_actual=$entrada
		[ -d "$directorio_actual" ] || { advertir "Directorio inválido"; sleep 3; continue; }
		procesar_directorio "$directorio_actual"
		preguntar '¿Procesar otro directorio? ["ENTER" Sí / "n" No]'
		read -r r
		case "$r" in n|N) break ;; esac
		sync
	done
	tsf=$(get_ts)
}
# ----------------------------------------------------------------- PPA
adjT
informar "--- INICIO ---"
iniciar
# ----------------------------------------------------------------- FIN
informar "--- FIN    ---"
exit 0
