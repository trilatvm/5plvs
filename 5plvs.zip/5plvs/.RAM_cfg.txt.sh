Para cambiar la agresividad del uso de la memoria de intercambio (ZRAM o Swap) a un valor de 10, tenés que modificar el parámetro vm.swappiness del kernel de Linux. Un valor de 10 hará que el sistema priorice mantener los datos en la memoria RAM física y use el intercambio solo cuando sea estrictamente necesario.
Seguí estos pasos para aplicarlo:
## 1. Cambiar el valor temporalmente (Sin reiniciar)
Para probar el rendimiento de inmediato sin necesidad de reiniciar la box, ejecutá:
sudo sysctl vm.swappiness=10
Podés verificar que cambió correctamente corriendo: cat /proc/sys/vm/swappiness.
## 2. Cambiar el valor permanentemente
Para que el cambio se mantenga guardado cada vez que enciendas el dispositivo, debés editar el archivo de configuración del sistema:
   1. Abrí el archivo de configuración con el editor nano:
   
   sudo nano /etc/sysctl.conf
   
   2. Desplázate hasta el final del archivo con las flechas del teclado.
   3. Agregá la siguiente línea al final:
   
   vm.swappiness=10
   
   (Nota: Si ya existe una línea que dice vm.swappiness=, cambiale el número que tenga por 10).
   4. Guardá los cambios presionando Ctrl + O, luego presioná Enter para confirmar, y salí con Ctrl + X.
## 3. Ajustar optimizaciones adicionales para RAM (Opcional)
Dado que tenés 2GB de RAM en tu chip Rockchip, te recomiendo agregar también estas dos líneas al final del mismo archivo (/etc/sysctl.conf) para optimizar la liberación de caché y evitar congelamientos (freezes):
vm.vfs_cache_pressure=50
vm.dirty_background_ratio=5
vm.dirty_ratio=10
Para aplicar todos los cambios del archivo inmediatamente sin reiniciar, ejecutá:
sudo sysctl -p
Si querés seguir optimizando el sistema, decime:
* 
* ¿La box la vas a usar como servidor hogareño (Samba, Docker, Pi-hole) o para centro multimedia (Kodi, Armbian de escritorio)?
* ¿Notabas que el sistema se ralentizaba o se trababa antes de hacer este cambio?
* 
