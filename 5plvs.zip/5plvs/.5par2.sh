#!/bin/sh
# .5par2.sh: Logica de par2
verificarHerramientasPar2() { if ! command -v par2 >/dev/null 2>&1; then printf "\033[0;91m[ERR]\033[0;33m Utilidad par2 ausente.\n" ; exit 1 ; fi ; }
calcularBloqueOptimo() {
	cbUA=$1
	cbTB=$(wc -c < "$cbUA" 2>/dev/null || echo "0")
	cbTB=$(printf "%s" "$cbTB" | tr -cd '0-9')
	[ -z "$cbTB" ] && cbTB=0
	cbTP=4096
	cbTM=$(( cbTB / 1048176 ))
	if [ "$cbTM" -le 50 ]; then cbBC=16384
	elif [ "$cbTM" -le 500 ]; then cbBC=524288
	elif [ "$cbTM" -le 2000 ]; then cbBC=2097152
	else cbBC=4194304; fi
	cbRes=$(( cbBC % cbTP ))
	if [ "$cbRes" -eq 0 ]; then echo "$cbBC"; else echo "$(( cbBC + (cbTP - cbRes) ))"; fi ; }
calcularPar2() {
	cpRC=$1 ; cpDT=$2 ; cpNB=$(basename "$cpRC") ; cpDP="$cpDT/par2" ; asegurarDirectorio "$cpDP" ; cpAP="$cpDP/$cpNB.par2"
	if [ -f "$cpAP" ] && [ "${modoFlujoSilencioso:-desactivado}" != "activo" ]; then
		printf "\n" ; mPgt "Sobreescribir PAR2? (s/n): " ; read -r sU
		if [ "$sU" != "s" ] && [ "$sU" != "S" ]; then mInf "Omitido." ; return 0 ; fi
		rm -f "$cpDP/$cpNB"*.par2 "$cpDP/$cpNB"*.vol* 2>/dev/null || true ; fi
	mInf "Calculando bloque..."
	cpBO=$(calcularBloqueOptimo "$cpRC" || echo "16384")
	cpRD=$(awk '/MemAvailable/ {print $2}' /proc/meminfo 2>/dev/null || echo "65536")
	cpRD=$(printf "%s" "$cpRD" | tr -cd '0-9') ; [ -z "$cpRD" ] && cpRD=65536
	cpRA=$(( cpRD / 1024 / 2 )) ; [ "$cpRA" -lt 32 ] && cpRA=32
	mInf "RAM: ${cpRA}MB | Bloque: $cpBO"
	cpEC=1
	par2 create -r20 -s"$cpBO" -m"$cpRA" -B "$cpDT" -a "$cpDP/$cpNB" "$cpRC" >/dev/null 2>&1 && cpEC=0
	if [ "$cpEC" -eq 0 ]; then mOk "PAR2 Creado." ; genPar2=$((genPar2 + 1)) ; else mErr "Fallo PAR2." ; incPar2=$((incPar2 + 1)) ; fi
	verSemaforoPar2 ; }
verificarPar2() {
	vpRC=$1 ; vpDT=$2 ; vpNB=$(basename "$vpRC") ; vpAP="$vpDT/par2/$vpNB.par2"
	if verificarArchivoLectura "$vpAP"; then
		mInf "Validando PAR2..."
		vpEPs=1
		par2 verify -B "$vpDT" -a "$vpDT/par2/$vpNB" "$vpRC" >/dev/null 2>&1 && vpEPs=0
		if [ "$vpEPs" -eq 0 ]; then mOk "OK: $vpNB" ; corPar2=$((corPar2 + 1)) ; else mErr "CORRUPTO: $vpNB" ; incPar2=$((incPar2 + 1)) ; fi
	else mInf "Sin PAR2: $vpNB" ; fi
	verSemaforoPar2 ; }
repararPar2() {
	rpRC=$1 ; rpDT=$2 ; rpNB=$(basename "$rpRC") ; rpDP="$rpDT/par2" ; rpAP="$rpDP/$rpNB.par2"
	if verificarArchivoLectura "$rpAP"; then
		rpEPs=1
		par2 verify -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1 && rpEPs=0
		if [ "$rpEPs" -eq 0 ]; then mOk "Sano: $rpNB" ; corPar2=$((corPar2 + 1))
		else
			mInf "Reparando..."
			rpER=1
			par2 repair -B "$rpDT" -a "$rpDP/$rpNB" "$rpRC" >/dev/null 2>&1 && rpER=0
			if [ "$rpER" -eq 0 ]; then mOk "REPARADO: $rpNB" ; corPar2=$((corPar2 + 1)) ; else mErr "INSUFICIENTE: $rpNB" ; incPar2=$((incPar2 + 1)) ; fi ; fi
	else mErr "Falta mapa PAR2: $rpNB" ; incPar2=$((incPar2 + 1)) ; fi
	verSemaforoPar2 ; }
