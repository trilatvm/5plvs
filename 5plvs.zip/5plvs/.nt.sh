md5sum -c ./.shall/md5/.*.md5
zip -r9vT ./0_bckp_$(date +"%s").zip ./0_bckp
unzip ./0_bckp_1785595065.zip