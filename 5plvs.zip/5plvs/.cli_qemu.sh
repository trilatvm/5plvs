qemu-img create -f qcow2 tcl64.qcow2 20G;
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 1536 \
  -smp 3 \
  -audiodev pa,id=audio0 \
  -device intel-hda \
  -device hda-duplex,audiodev=audio0 \
  -boot d \
  -hda /run/media/usuario/TD/TD/qemu/tcl64.qcow2 \
  -cdrom /run/media/usuario/TD/TD/tinycorelinux/x64_TinyCorePure64-17.0.iso
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 1536 \
  -smp 3 \
  -audiodev pa,id=audio0 \
  -device intel-hda \
  -device hda-duplex,audiodev=audio0 \
  -boot d \
  -hda /run/media/usuario/TD/TD/qemu/tcl64.qcow2 \
  -cdrom /run/media/usuario/TD/TD/tinycorelinux/x86_CorePlus-current.iso
