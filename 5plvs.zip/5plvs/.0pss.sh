#####
sudo date -s "2232-04-18 20:47:15";
mkdir -p logOS;
mkdir -p DOC JAR JD2 MFX QBT SRC UGT YTB WEB;
mkdir -p ./DOC/ODF_DOCX ./DOC/ODS_XLSX;
cd ./logOS;
date +"%A %Y-%m-%d %H:%M:%S" | tee -a "date.log";;
sudo ntpd -q | tee -a "sincro_ntpd.log";
sudo chronyc -a makestep | tee -a "sincro_chronyc.log";
ps aux | grep chronyd;
sudo kill -9 702;
# sudo systemctl stop chronyd;
# sudo service chronyd stop
cp /etc/lightdm/lightdm.conf ./;
cp ./lightdm.conf /etc/lightdm/;
cp ./img.png /usr/share/backgrounds/
cp -r ./terminus-ttf-4.49.3-windows /usr/share/fonts/;
cat /etc/lightdm/lightdm.conf;
cd /var/cache/xbps/;
cd /usr/share/fonts/;
#-------------------------------------- sync
sudo xbps-install -S  | tee -a "update.log";
sudo xbps-install -y xbps  | tee -a "xbps.log";
sudo xbps-install -Syu  | tee -a "upgrade.log";
sudo xbps-query -Rs pps
#-------------------------------------- NTP
sudo sv down chronyd;
sudo rm /var/service/chronyd;
sudo xbps-install -Sy ntp | tee -a "ntp.log";
#sudo xbps-install -Sy ntp pps-tools 2>&1 | tee tiempo_.log
for pkg in ntp pps-tools; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
sudo ntpd -q | tee -a "ntp_sincro.log";
sudo ln -s /etc/sv/ntpd /var/service/;
sudo sv up ntpd;
sv status ntpd;
#-------------------------------------- xbps-query -Rs node
for pkg in exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs apfs-fuse apfsprogs e2fsprogs openjdk8-jre openjdk11-jre openjdk17-jre openjdk21-jre openjdk8 openjdk11 openjdk17 openjdk21 coreutils moreutils udftools ipmiutil xfonts-utils net-tools udftools smartmontools sensors ntfs-3g ntfsprogs libfuse2 dosfstools zfs-lts hfsprogs apfs-fuse apfsprogs e2fsprogs ntpsec ntpsec-doc ntpsec-ntpdate gpsd gpsd-clients pps-tools tree unzip zip xz parted gparted partview uextract peasydiff xarchiver nmap fail2ban iptables iptables-persistent net-tools remmina putty putty-doc sshfs httrack firefox-esr yt-dlp uget wget qbittorrent ffmpeg ffmpeg-doc flac easytag soundconverter spek pulseaudio alsa mpv vlc x264 x265 av1 imagemagick viewnior cups cups-pdf qpdfview leafpad mousepad libreoffice librecad nano git git-doc git-gui gcc g++ g++-multilib gdb valgrind make automake config autoconfig dpkg linux-headers-$(uname -r) stellarium gpredict gpredict-doc rtl-sdr airtay ax25 librtlsdr-dev gnuradio geogebra avogadro wine wine64 winetricks winbind qemu qemu-kvm pv dstat bmon glances nload iftop iotop ncdu tree nmap baobab top htop btop xfonts-utils font-manager freetype2-demos fontforge; do sudo xbps-query -Rs "$pkg" 2>&1 | tee -a "xbps-query.log"; done;
#-------------------------------------- xbps-install -Sy
for pkg in apss; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in ntp pps-tools gpsd; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in fail2ban iptables runit-iptables; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in wine wine-common wine-mono winegui winetricks; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in aqemu novaboot qemu qemuconf virtme; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in git git-gui python3 openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate ristretto fontmanager fontforge; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
#--------------------------------------
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do  xbps-query -R "$pkg" 2>&1 | tee -a "${pkg}.inf"; done;
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do  xbps-install --dry-run "$pkg" 2>&1 | tee -a "${pkg}.sim"; done;
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
#--------------------------------------
sudo ln -s /etc/sv/ntpd /var/service/;			# NTPD (Network Time Protocol daemon)
sudo ln -s /etc/sv/fail2ban /var/service/;		# Fail2Ban (protección contra ataques de fuerza bruta)
sudo ln -s /etc/sv/iptables /var/service/;		# IPTables (firewall)
sudo ln -s /etc/sv/runit-iptables /var/service/;	# unit-iptables (posible script adicional)
sudo sv up ntpd;
sudo sv up fail2ban;
sudo sv up iptables;
sudo sv up runit-iptables;
sv status ntpd;
sv status fail2ban;
sv status iptables;
sv status runit-iptables;
sudo sv up iptables;sudo sv status iptables;
sudo iptables -L -v -n;sudo ip6tables -L -v -n;
nano ~/iptables_ipv6_rules.sh;
#!/bin/sh
# Script de firewall para IPv4 e IPv6 en Void Linux
# Compatible con /bin/sh, con sudo y ; al final de cada línea
# ----------------------
# Limpiar reglas existentes
# ----------------------
sudo iptables -F;
sudo iptables -X;
sudo iptables -t nat -F;
sudo iptables -t nat -X;
sudo iptables -t mangle -F;
sudo iptables -t mangle -X;
sudo ip6tables -F;
sudo ip6tables -X;
sudo ip6tables -t nat -F;
sudo ip6tables -t nat -X;
sudo ip6tables -t mangle -F;
sudo ip6tables -t mangle -X;
# ----------------------
# Políticas por defecto
# ----------------------
sudo iptables -P INPUT DROP;
sudo iptables -P FORWARD DROP;
sudo iptables -P OUTPUT ACCEPT;
sudo ip6tables -P INPUT DROP;
sudo ip6tables -P FORWARD DROP;
sudo ip6tables -P OUTPUT ACCEPT;
# ----------------------
# Permitir loopback
# ----------------------
sudo iptables -A INPUT -i lo -j ACCEPT;
sudo iptables -A OUTPUT -o lo -j ACCEPT;
sudo ip6tables -A INPUT -i lo -j ACCEPT;
sudo ip6tables -A OUTPUT -o lo -j ACCEPT;
# ----------------------
# Permitir conexiones ya establecidas y relacionadas
# ----------------------
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
sudo ip6tables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
# ----------------------
# Puertos permitidos
# ----------------------
# SSH
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 22 -j ACCEPT;
# HTTP/HTTPS
sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 443 -j ACCEPT;
# Ping (ICMP)
sudo iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT;
sudo ip6tables -A INPUT -p ipv6-icmp --icmpv6-type echo-request -j ACCEPT;
# ----------------------
# Rechazar todo lo demás explícitamente
# ----------------------
sudo iptables -A INPUT -j REJECT;
sudo iptables -A FORWARD -j REJECT;
sudo ip6tables -A INPUT -j REJECT;
sudo ip6tables -A FORWARD -j REJECT;
# ----------------------
# Guardar reglas
# ----------------------
sudo iptables-save > /etc/iptables/rules.v4;
sudo ip6tables-save > /etc/iptables/rules.v6;
echo "Reglas de iptables e ip6tables aplicadas y guardadas;";
