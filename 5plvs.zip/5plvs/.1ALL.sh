#!/bin/sh
clear
sync
echo "--- INICIO SCRIPT ---"
#!/bin/sh
# Script de firewall para IPv4 e IPv6 en Void Linux
# Compatible con /bin/sh, con sudo y ; al final de cada línea
# ----------------------
# Limpiar reglas existentes
# ----------------------
sudo iptables -F;
sudo iptables -X;
sudo iptables -t nat -F;
sudo iptables -t nat -X;
sudo iptables -t mangle -F;
sudo iptables -t mangle -X;
sudo ip6tables -F;
sudo ip6tables -X;
sudo ip6tables -t nat -F;
sudo ip6tables -t nat -X;
sudo ip6tables -t mangle -F;
sudo ip6tables -t mangle -X;
# ----------------------
# Políticas por defecto
# ----------------------
sudo iptables -P INPUT DROP;
sudo iptables -P FORWARD DROP;
sudo iptables -P OUTPUT ACCEPT;
sudo ip6tables -P INPUT DROP;
sudo ip6tables -P FORWARD DROP;
sudo ip6tables -P OUTPUT ACCEPT;
# ----------------------
# Permitir loopback
# ----------------------
sudo iptables -A INPUT -i lo -j ACCEPT;
sudo iptables -A OUTPUT -o lo -j ACCEPT;
sudo ip6tables -A INPUT -i lo -j ACCEPT;
sudo ip6tables -A OUTPUT -o lo -j ACCEPT;
# ----------------------
# Permitir conexiones ya establecidas y relacionadas
# ----------------------
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
sudo ip6tables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
# ----------------------
# Puertos permitidos
# ----------------------
# SSH
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 22 -j ACCEPT;
# HTTP/HTTPS
sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 443 -j ACCEPT;
# Ping (ICMP)
sudo iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT;
sudo ip6tables -A INPUT -p ipv6-icmp --icmpv6-type echo-request -j ACCEPT;
# ----------------------
# Rechazar todo lo demás explícitamente
# ----------------------
sudo iptables -A INPUT -j REJECT;
sudo iptables -A FORWARD -j REJECT;
sudo ip6tables -A INPUT -j REJECT;
sudo ip6tables -A FORWARD -j REJECT;
# ----------------------
# Guardar reglas
# ----------------------
sudo iptables-save > /etc/iptables/rules.v4;
sudo ip6tables-save > /etc/iptables/rules.v6;
echo "Reglas de iptables e ip6tables aplicadas y guardadas;";
echo "--- FIN SCRIPT ---"
#sudo shutdown -r +5
exit 0