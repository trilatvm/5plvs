#!/bin/sh
set -eu
detectar_algoritmos() {	# Detectar todos los algoritmos disponibles
	algoritmos=""
	for a in md5 md5sum sha1 sha1sum sha256 sha256sum sha512 sha512sum b2sum cksum; do
		if command -v "$a" >/dev/null 2>&1; then
			case "$a" in
				md5|md5sum) algoritmos="$algoritmos md5" ;;
				sha1|sha1sum) algoritmos="$algoritmos sha1" ;;
				sha256|sha256sum) algoritmos="$algoritmos sha256" ;;
				sha512|sha512sum) algoritmos="$algoritmos sha512" ;;
				b2sum) algoritmos="$algoritmos b2sum" ;;
				cksum) algoritmos="$algoritmos cksum" ;;
			esac
		fi
	done
	[ -n "$algoritmos" ] || { advertir "No se encontró ningún algoritmo disponible."; exit 1; }
	informar "Algoritmos detectados:$algoritmos"; }