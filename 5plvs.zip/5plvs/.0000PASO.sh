for pkg in xbps base-devel dialog grub base-files libgcc dash coreutils sed tar gawk squashfs-tools xorriso binutils xz device-mapper dhclient dracut-network openresolv ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree zip unzip bzip2 gzip fuse-zip parted gparted xarchiver xfburn Thunar thunar-archive-plugin xdg-user-dirs file-roller smartmontools gsmartcontrol fail2ban iptables runit-iptables NetworkManager network-manager-applet openbox obconf obconf-qt obmenu-generator lxappearance-obconf tint2 tint2conf xorg xrandr lightdm lightdm-gtk-greeter xterm xfce4-terminal nitrogen gmrun void-repo-nonfree void-repo-multilib-nonfree wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme git git-gui python3 nodejs-lts octave geany geany-plugins geany-plugins-extra openjdk8 openjdk11 openjdk17 openjdk21 remmina putty httrack firefox-esr yt-dlp uget wget aria2 qbittorrent ImageMagick viewnior cups pdftk pdftk-java qpdf qpdfview xpdf pdfcrack leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font x264 x265 flac ffmpeg shotcut pulseaudio pulseaudio-utils pavucontrol pnmixer easytag soundconverter celluloid mpv vlc htop btop bmon nload glances moreutils ipmiutil udftools net-tools make cmake cmake-extras cmake-gui automake gcc xfce4 rsync nginx xorriso cdrtools bsdtar mtools libarchive openssh rsync; do xbps-query -R "$pkg" 2>&1 | tee -a "${pkg}.inf"; done;
for pkg in xbps base-devel dialog grub base-files libgcc dash coreutils sed tar gawk squashfs-tools xorriso binutils xz device-mapper dhclient dracut-network openresolv ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree zip unzip bzip2 gzip fuse-zip parted gparted xarchiver xfburn Thunar thunar-archive-plugin xdg-user-dirs file-roller smartmontools gsmartcontrol fail2ban iptables runit-iptables NetworkManager network-manager-applet openbox obconf obconf-qt obmenu-generator lxappearance-obconf tint2 tint2conf xorg xrandr lightdm lightdm-gtk-greeter xterm xfce4-terminal nitrogen gmrun void-repo-nonfree void-repo-multilib-nonfree wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme git git-gui python3 nodejs-lts octave geany geany-plugins geany-plugins-extra openjdk8 openjdk11 openjdk17 openjdk21 remmina putty httrack firefox-esr yt-dlp uget wget aria2 qbittorrent ImageMagick viewnior cups pdftk pdftk-java qpdf qpdfview xpdf pdfcrack leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font x264 x265 flac ffmpeg shotcut pulseaudio pulseaudio-utils pavucontrol pnmixer easytag soundconverter celluloid mpv vlc htop btop bmon nload glances moreutils ipmiutil udftools net-tools make cmake cmake-extras cmake-gui automake gcc xfce4 rsync nginx xorriso cdrtools bsdtar mtools libarchive openssh rsync; do xbps-install --dry-run "$pkg" 2>&1 | tee -a "${pkg}.sim"; done;
sudo xbps-install -y firefox-esr | tee -a "firefox-esr.log";
sudo xbps-install -Suy
tr ' ' '\n' < a.txt | sed '/^$/d' | sort | tee b.txt
sudo xbps-install -Suy \
base-system \
base-devel \
xbps \
base-files \
libgcc \
dash \
coreutils \
sed \
tar \
gawk \
binutils \
xz \
gzip \
bzip2 \
make \
gcc \
cmake \
automake
sudo xbps-install -Suy base-system
sudo xbps-pkgdb -m hold grub-terminus
sudo xbps-pkgdb -m hold terminus-font
sudo xbps-pkgdb -m hold kbd
for pkg in xbps base-devel dialog grub base-files libgcc dash coreutils sed tar gawk squashfs-tools xorriso binutils xz device-mapper dhclient dracut-network openresolv ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree zip unzip bzip2 gzip fuse-zip parted gparted xarchiver xfburn Thunar thunar-archive-plugin xdg-user-dirs file-roller smartmontools gsmartcontrol fail2ban iptables runit-iptables NetworkManager network-manager-applet openbox obconf obconf-qt obmenu-generator lxappearance-obconf tint2 tint2conf xorg xrandr lightdm lightdm-gtk-greeter xterm xfce4-terminal nitrogen gmrun void-repo-nonfree void-repo-multilib-nonfree wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme git git-gui python3 nodejs-lts octave geany geany-plugins geany-plugins-extra openjdk8 openjdk11 openjdk17 openjdk21 remmina putty httrack firefox-esr yt-dlp uget wget aria2 qbittorrent ImageMagick viewnior cups pdftk pdftk-java qpdf qpdfview xpdf pdfcrack leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge x264 x265 flac ffmpeg shotcut pulseaudio pulseaudio-utils pavucontrol pnmixer easytag soundconverter celluloid mpv vlc htop btop bmon nload glances moreutils ipmiutil udftools net-tools make cmake cmake-extras cmake-gui automake gcc xfce4 rsync nginx xorriso cdrtools bsdtar mtools libarchive openssh rsync; do sudo xbps-install -Suy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
Lo más probable es que pase una de estas cosas en Void Linux:
consolefont queda apuntando a una fuente inexistente,
dracut reconstruye initramfs sin Terminus,
kmscon/framebuffer cambia el rendering,
grub-terminus pisa configuración,
fontconfig elimina aliases viejos,
o vconsole.conf/rc.conf queda inconsistente.
Reconfigurar la consola
En Void normalmente se usa:
/etc/rc.conf
Poné:
FONT=ter-v16n
o:
FONT=ter-132n
Luego:
sudo xbps-reconfigure -fa
Probar manualmente
Sin reiniciar:
sudo setfont ter-v16n
Si eso funciona, entonces:
la fuente NO está rota,
solo se perdió la carga automática.
También puede romperse por framebuffer
Probá arrancar sin KMS temporalmente:
En GRUB, editá la línea del kernel y agregá:
nomodeset
Si Terminus vuelve:
el problema es DRM/KMS,
no la fuente.
Otra causa común: paquete kbd
XBPS a veces actualiza:
kbd
console-setup
font-util
y cambia nombres internos.
Probá reinstalar:
sudo xbps-install -f kbd terminus-font
Lo más estable en Void
Muchos usuarios terminan usando:
FONT=Lat2-Terminus16
en vez de ter-v16n.
Podés listar nombres válidos:
localectl list-console-fonts | grep Terminus
Lo que yo haría
sudo xbps-remove grub-terminus
sudo xbps-install -f kbd terminus-font
sudo nano /etc/rc.conf
Agregar:
FONT=ter-v16n
sudo xbps-reconfigure -fa
sudo dracut -f
Eso normalmente arregla el problema definitivamente en Void.
#####
sudo date -s "2232-04-18 20:47:15"
mkdir -p logOS;
cd ./logOS;
date +"%A %Y-%m-%d %H:%M:%S" | tee -a "date.log";;
sudo ntpd -q | tee -a "sincro_ntpd.log";
sudo chronyc -a makestep | tee -a "sincro_chronyc.log";
ps aux | grep chronyd;
sudo kill -9 702;
# sudo systemctl stop chronyd;
# sudo service chronyd stop
cp /etc/lightdm/lightdm.conf ./;
cp ./lightdm.conf /etc/lightdm/;
cat /etc/lightdm/lightdm.conf;
cd /var/cache/xbps/;
cd /usr/share/fonts/;
fc-cache -rv
fc-list | grep -i terminus	# Si NO aparece nada, el problema es fontconfig.
ls /etc/fonts/conf.d | grep 70-no-bitmaps	# Deshabilitar: 70-no-bitmaps-except-emoji.conf
sudo unlink /etc/fonts/conf.d/70-no-bitmaps-except-emoji.conf
fc-cache -rv
`70-no-bitmaps-except-emoji.conf` es una regla de Fontconfig que le dice al sistema:
> “No uses fuentes bitmap… excepto emojis.”
Las bitmap fonts son fuentes viejas de píxeles fijos, como:
* Terminus Font
* Fixed
* Misc
* Dina
* Proggy
* Tamzen
Estas fuentes no se renderizan con curvas vectoriales tipo TrueType/OpenType modernas; cada tamaño ya viene dibujado píxel por píxel.
---
¿Por qué las deshabilitan?
Porque muchos escritorios modernos consideran que:
* se ven “antiguas”
* no escalan bien en HiDPI
* rompen antialiasing/subpixel
* algunas apps crasheaban o renderizaban mal
* Wayland/GTK modernos priorizan outline fonts
Entonces varias distros empezaron a activar:
* `70-no-bitmaps.conf`
* o variantes como `70-no-bitmaps-except-emoji.conf`
para filtrar bitmap fonts automáticamente.
---
El “except-emoji” existe porque muchos emojis del sistema todavía usan bitmap/fallbacks especiales en algunos casos.
---
En realidad el archivo contiene reglas XML tipo:
```xml id="j8v7ca"
<selectfont>
  <rejectfont>
    <pattern>
      <patelt name="scalable">
        <bool>false</bool>
      </patelt>
    </pattern>
  </rejectfont>
</selectfont>
```
Eso significa:
* si la fuente NO es escalable (`scalable=false`)
* rechazala
Y Terminus entra exactamente ahí.
---
Por eso:
* los archivos estaban en `/usr/share/fonts`
* pero `fontconfig` fingía que no existían
* entonces las apps no las mostraban
---
Ahora que sacaste esa regla:
* vuelven a aparecer
* apps X11 suelen manejarlas perfecto
* terminales clásicas funcionan excelente
* TTY vuelve a verse glorioso 😄
Terminus sigue siendo muy querida porque:
* es ultra legible
* perfecta para programación
* excelente en tamaños pequeños
* consume nada
* ideal para tiling WMs y retro setups
Muy típico en gente que usa:
* i3
* dwm
* Openbox
* XMonad
o consolas puras Linux.
#------------------
 ~]$ find /boot/grub -iname "*.pf2"
/boot/grub/fonts/terminus20.pf2
/boot/grub/fonts/unicode.pf2
/boot/grub/fonts/terminus28.pf2
/boot/grub/fonts/terminus22.pf2
/boot/grub/fonts/terminus18.pf2
/boot/grub/fonts/terminus14.pf2
/boot/grub/fonts/terminus24.pf2
/boot/grub/fonts/terminus12.pf2
/boot/grub/fonts/terminus16.pf2
/boot/grub/fonts/terminus32.pf2
sudo nano /etc/default/grub
GRUB_FONT=/boot/grub/fonts/ter-u16n.pf2
GRUB_FONT=/boot/grub/fonts/terminus20.pf2
cp /usr/share/backgrounds/xfce/img.png /usr/share/void-artwork/splash.png
sudo update-grub
sudo grub-mkconfig -o /boot/grub/grub.cfg
Si querés que detecte otros sistemas:
sudo nano /etc/default/grub
y agregás:
GRUB_DISABLE_OS_PROBER=false
luego:
sudo update-grub
sudo grub-mkconfig -o /boot/grub/grub.cfg
Generando un fichero de configuración de grub...
Encontrado fondo de pantalla: /usr/share/void-artwork/splash.png
Encontrada imagen de linux: /boot/vmlinuz-6.18.33_1
Encontrada imagen de memoria inicial: /boot/initramfs-6.18.33_1.img
Encontrada imagen de linux: /boot/vmlinuz-6.12.91_1
Encontrada imagen de memoria inicial: /boot/initramfs-6.12.91_1.img
Encontrada imagen de linux: /boot/vmlinuz-6.12.11_1
Encontrada imagen de memoria inicial: /boot/initramfs-6.12.11_1.img
Aviso: os-prober will not be executed to detect other bootable partitions.
Systems on them will not be added to the GRUB boot configuration.
Check GRUB_DISABLE_OS_PROBER documentation entry.
Adding boot menu entry for UEFI Firmware Settings ...
hecho
#-------------------------------------- sync
sudo xbps-install -S | tee -a "update.log";	# Sync remote repository index
sudo xbps-install -y xbps | tee -a "xbps.log";	# Update target package(s)
xbps-query -l | tee -a "xbps-instalados.log";	# Update target package(s)
sudo xbps-install -Syu | tee -a "upgrade.log";
sudo xbps-query -Rs pps
#-------------------------------------- NTP
# Elimina el enlace actual
sudo rm -f /etc/localtime
# Crea el enlace simbólico a la zona horaria deseada
sudo ln -sf /usr/share/zoneinfo/America/Argentina/Buenos_Aires /etc/localtime
sudo sv down chronyd;
sudo rm /var/service/chronyd;
sudo xbps-install -Sy ntp | tee -a "ntp.log";
#sudo xbps-install -Sy ntp pps-tools 2>&1 | tee tiempo_.log
for pkg in ntp pps-tools; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
sudo ntpd -q | tee -a "ntp_sincro.log";
sudo ln -s /etc/sv/ntpd /var/service/;
sudo sv up ntpd;
sv status ntpd;
#-------------------------------------- xbps-query -Rs xfce
for pkg in exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs apfs-fuse apfsprogs e2fsprogs openjdk8-jre openjdk11-jre openjdk17-jre openjdk21-jre openjdk8 openjdk11 openjdk17 openjdk21 coreutils moreutils udftools ipmiutil xfonts-utils net-tools udftools smartmontools sensors ntfs-3g ntfsprogs libfuse2 dosfstools zfs-lts hfsprogs apfs-fuse apfsprogs e2fsprogs ntpsec ntpsec-doc ntpsec-ntpdate gpsd gpsd-clients pps-tools tree unzip zip xz parted gparted partview uextract peasydiff xarchiver nmap fail2ban iptables iptables-persistent net-tools remmina putty putty-doc sshfs httrack firefox-esr yt-dlp uget wget qbittorrent ffmpeg ffmpeg-doc flac easytag soundconverter spek pulseaudio alsa mpv vlc x264 x265 av1 imagemagick viewnior cups cups-pdf qpdfview leafpad mousepad libreoffice librecad nano git git-doc git-gui gcc g++ g++-multilib gdb valgrind make automake config autoconfig dpkg linux-headers-$(uname -r) stellarium gpredict gpredict-doc rtl-sdr airtay ax25 librtlsdr-dev gnuradio geogebra avogadro wine wine64 winetricks winbind qemu qemu-kvm pv dstat bmon glances nload iftop iotop ncdu tree nmap baobab top htop btop xfonts-utils font-manager freetype2-demos fontforge; do sudo xbps-query -Rs "$pkg" 2>&1 | tee -a "xbps-query.log"; done;
#-------------------------------------- xbps-install -Sy
for pkg in apss; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in ntp pps-tools gpsd; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in fail2ban iptables runit-iptables; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in wine wine-common wine-mono winegui winetricks; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in aqemu novaboot qemu qemuconf virtme; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in git git-gui python3 openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
for pkg in x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate ristretto fontmanager fontforge; do sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log"; done;
#--------------------------------------
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do	xbps-query -R "$pkg" 2>&1 | tee -a "${pkg}.inf"; done;
for pkg in coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi libsensors lm_sensors qt5-sensors qt6-sensors ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do	xbps-install --dry-run "$pkg" 2>&1 | tee -a "${pkg}.sim"; done;
mmkdir -p ./0dir/etc/skel
mmkdir -p ./0dir/home/usuario/.conf/openbox/
mmkdir -p ./0dir/home/usuario/.conf/openbox/
cd ./0dir/home/usuario/.conf/openbox/
echo 'sudo date -s "2232-04-18 20:47:15"'	> ./0dir/home/usuario/doc/0cli.sh
echo 'sudo xbps-install -Sy xbps base-devel git make dialog'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'ls /etc/sv'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'ln -s /etc/sv/lightdm /var/service'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'nano .bashrc'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'setxkbmap -layout es'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'xdg-user-dirs-update'	>> ./0dir/home/usuario/doc/0cli.sh
echo '# Ctrl + H'	>> ./0dir/home/usuario/doc/0cli.sh
echo 'xrandr -s 1920x1080_60 &'	>> ./0dir/home/usuario/doc/0cli.sh
echo ''	>> /home/usuario/.conf/openbox/autostart
# /home/usuario/.conf/openbox/autostart
xrandr -s 1920x1080_60 &
nitrogen --restore &
pnmixer &
nm-applet &
tint2 &
# pref/behavior/pavucontrol
nano ./0dir/home/usuario/.doc/0cli.sh
nano ./0dir/home/usuario/.conf/openbox/autostart
cp /run/media/usuario/DT/DT/img.png ./0dir/home/usuario/doc/
cp /run/media/usuario/DT/DT/YTB/20210809.qLurRFQhMbs.Purga_Linux.NA.Crear_live_iso_personal_con_void-mklive.mp4 ./0dir/home/usuario/doc/
cp /run/media/usuario/DT/DT/YTB/20241210.aFqR98WNcwU.Void_Linux_Lab.NA.Un_equipo_rendidor_-_Void_Linux_+_Openbox.mp4 ./0dir/home/usuario/doc/
cp /run/media/usuario/DT/DT/YTB/20250415.378rU-wpLX4.Jake@Linux.NA.One_more_reason_Void_Linux_is_the_BEST_distro.mkv ./0dir/home/usuario/doc/
xbps-query -Rs file-roller
base-files libgcc dash coreutils sed tar gawk squashfs-tools xorriso binutils xz device-mapper dhclient dracut-network openresolv
sync && sudo ./mklive.sh -I 0DIR -o ./0ISO/gnuLinux1.iso -T "GNU-Linux I" -p "xbps base-devel dialog grub base-files libgcc dash coreutils sed tar gawk squashfs-tools xorriso binutils xz device-mapper dhclient dracut-network openresolv ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree zip unzip bzip2 gzip fuse-zip parted gparted xarchiver xfburn Thunar thunar-archive-plugin xdg-user-dirs file-roller smartmontools gsmartcontrol fail2ban iptables runit-iptables NetworkManager network-manager-applet openbox obconf obconf-qt obmenu-generator lxappearance-obconf tint2 tint2conf xorg xrandr lightdm lightdm-gtk-greeter xterm xfce4-terminal nitrogen gmrun void-repo-nonfree void-repo-multilib-nonfree wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme git git-gui python3 nodejs-lts octave geany geany-plugins geany-plugins-extra openjdk8 openjdk11 openjdk17 openjdk21 remmina putty httrack firefox-esr yt-dlp uget wget aria2 qbittorrent ImageMagick viewnior cups pdftk pdftk-java qpdf qpdfview xpdf pdfcrack leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font x264 x265 flac ffmpeg shotcut pulseaudio pulseaudio-utils pavucontrol pnmixer easytag soundconverter celluloid mpv vlc htop btop bmon nload glances moreutils ipmiutil udftools net-tools make cmake cmake-extras cmake-gui automake gcc xfce4 rsync nginx xorriso cdrtools bsdtar mtools libarchive openssh rsync" | tee $(date +"%s")_rgt.log && sync
sudo xbps-install -S squashfs-tools xorriso cdrtools rsync
# ------------------------------------------
# ------------------------------------------
sysrc sshd_enable=YES
service sshd start
# ------------------------------------------
xz -dk FreeBSD-15.0-RELEASE-amd64-dvd1.iso.xz
sudo xbps-install -S \
  xorriso \
  libarchive \
  cdrtools \
  mtools \
  xz \
  tar
mkdir -p ./freebsd-custom/{iso,work,newiso}
mkdir -p freebsd-custom/{iso,overlay,pkgs,scripts,build,output}
cd freebsd-custom
cd ./freebsd-custom
bsdtar -C iso -xf FreeBSD-15.0-RELEASE-amd64-dvd1.iso
freebsd-custom]$ ls iso
COPYRIGHT  bin  boot  dev  etc  lib  libexec  media  mnt  net  packages  proc  rescue  root  sbin  tmp  usr  var
mkdir iso/custompkgs
ls iso
# Dentro de FreeBSD
mkdir -p ./repo
cp /var/cache/pkg/*.pkg /repo
pkg repo /repo
cd pkgs
pkg install -y xfce firefox xorg
pkg fetch -d xfce firefox xorg
Los paquetes quedan en:
/var/cache/pkg/
scp freebsd:/var/cache/pkg/*.pkg ./pkgs/
cd ..
cp pkgs/*.pkg iso/custompkgs/
ls iso/custompkgs
# ------------------------------------------
# ------------------------------------------
# ------------------------------------------
sudo chmod -R a+rwX /run/media/usuario/TD
sudo chmod -R a+rwX /run/media/usuario/DT
# /home/usuario/.conf/openbox/
xrandr -s 1920x1080_60 &
nitrogen --restore &
pnmixer &
nm-applet &
tint2 &
ln -s /etc/sv/lightdm /var/service
mkdir -p ./0ISO
mkdir -p ./0DIR/etc/skel/
mkdir -p ./0DIR/home/usuario/.conf/openbox/
mkdir -p ./0DIR/home/usuario/.doc/
mkdir -p ./0DIR/home/usuario/app/
mkdir -p ./0DIR/home/usuario/app-run/lin/
mkdir -p ./0DIR/home/usuario/app-run/win/
mkdir -p ./0DIR/usr/share/fonts/
mkdir -p ./0DIR/home/usuario/src/
mkdir -p ./0DIR/var/service/
cp -r /var/service/ntpd ./0DIR/var/service/
> ./0dir/.
for pkg in base-devel dialog git make coreutils moreutils ipmiutil udftools net-tools smartmontools gsmartcontrol acpi ntp pps-tools gpsd exfatprogs ntfs-3g dosfstools zfs-lts hfsprogs e2fsprogs tree unzip bzip2 fuse-zip gzip unzip zip xz parted gparted htop iotop powertop usbtop xarchiver xfburn btop usbtop dstat bmon glances iotop ncdu baobab baobab nload fail2ban iptables runit-iptables wine wine-common wine-mono winegui winetricks aqemu novaboot qemu qemuconf virtme remmina putty fuse-sshfs httrack firefox-esr yt-dlp uget wget aria2 qbittorrent git git-gui python3 nodejs-lts openjdk8 openjdk11 openjdk17 openjdk21 gcc automake cmake cmake-extras cmake-gui make makedepend xorg autoconf dpkg x264 x265 flac ffmpeg alsa-plugins-ffmpeg ffmpeg6 pulseaudio pulseaudio-utils easytag soundconverter celluloid mpv vlc libaom libaom-tools libdav1d libsvt-av1 ImageMagick viewnior cups cups-browsed cups-filters cups-pdf cups-pk-helper qpdfview leafpad mousepad libreoffice LibreCAD nano bitcoin bitcoin-qt stellarium gpredict rtl-sdr ax25-tools gnuradio qalculate qalculate-qt ristretto fontmanager fontforge grub-terminus terminus-font termsyn-font; do sudo xbps-install -Sy "$pkg" 2>&1 | tee "${pkg}.log"; done;
#--------------------------------------
mkdir -p /run/media/usuario/RPO/RPO/freebsd/packages/latest
# Latest ó
rsync -av --delete \
rsync://pkg.freebsd.org/FreeBSD:15:amd64/latest/ \
/run/media/usuario/RPO/RPO/freebsd/packages/latest/
# O quarterly (más estable)
rsync -av --delete \
rsync://pkg.freebsd.org/FreeBSD:15:amd64/quarterly/ \
/run/media/usuario/RPO/RPO/freebsd/packages/quarterly/
#--------------------------------------
nano JDownloader.vmoptions
'
-Xms64m
-Xmx512m
-XX:+UseG1GC
-Dsun.java2d.opengl=true
'
#--------------------------------------
#!/bin/sh
clear
###############################################################################
# Script POSIX sh puro para generar un wordlist de contraseñas posibles según la pista dada:
# - Contraseña de 5 caracteres
# - Todas en mayúsculas (A–Z)
# - Empieza con "G"
# - Termina con "D"
# - Ejemplo: GABCD, GZZZD, etc.
#
# Total de combinaciones:
#	 26 letras posibles para la posición 2
#	 26 letras posibles para la posición 3
#	 26 letras posibles para la posición 4
#	 => 26^3 = 17,576 combinaciones
#
# Tamaño aproximado del archivo wordlist:
#	 Cada línea tiene 6 bytes (5 letras + salto de línea)
#	 17,576 * 6 ≈ 105 KB
#	 Es un archivo muy pequeño y manejable.
#
# Archivos de prueba para piano electronico casio:
#	GH_PXS_musiclibraryscores_D_WL.pdf
#	Web_AL10PHCOSCOREWL1A.pdf
#
###############################################################################
# Generamos todas las combinaciones y las guardamos en wordlist.txt
for a in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
	for b in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
		for c in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
			# Construimos la contraseña con el patrón G???D
			echo "G${a}${b}${c}D"
#			printf "G%s%s%sD\n" "$a" "$b" "$c"
		done
	done
done > wordlist.txt
###############################################################################
# Estadísticas útiles:
# - Número de contraseñas generadas: 17,576
# - Tamaño del archivo resultante: ~105 KB
# - Tiempo estimado de prueba con pdfcrack:
#	 Depende de la velocidad de tu CPU, pero con un wordlist tan pequeño
#	 debería encontrar la contraseña en segundos o pocos minutos.
###############################################################################
# Usar pdfcrack con wordlist generado
# -f indica el archivo PDF protegido
# -w indica el archivo de wordlist
pdfcrack -f GH_PXS_musiclibraryscores_D_WL.pdf -w wordlist.txt
exit 0
#--------------------------------------
#--------------------------------------
#--------------------------------------
sync && ffmpeg -i orig.mp4 \
-vf "scale=1920:1080:force_original_aspect_ratio=decrease,\
pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black" \
-c:v libx264 \
-pix_fmt yuv420p \
-crf 20 \
-preset veryfast \
-profile:v high \
-level 4.1 \
-movflags +faststart \
-c:a aac -b:a 128k \
1920_1080p_h264.mp4 && sync
#--------------------------------------
sync && ffmpeg -i orig.mp4 \
-vf "scale=1920:1080:force_original_aspect_ratio=decrease,\
pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black" \
-c:v libx265 \
-pix_fmt yuv420p \
-crf 20 \
-preset veryfast \
-tag:v hvc1 \
-c:a aac -b:a 128k \
1920_1080p_h265.mp4 && sync
#--------------------------------------
sync && ffmpeg -i orig.mp4 \
-vf "scale=1920:1080:force_original_aspect_ratio=decrease,\
pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black" \
-c:v libaom-av1 \
-crf 30 \
-b:v 0 \
-cpu-used 4 \
-row-mt 1 \
-tiles 2x2 \
-c:a libopus -b:a 128k \
1920_1080p_av1.mkv && sync
#--------------------------------------
#--------------------------------------
#--------------------------------------
sudo ln -s /etc/sv/ntpd /var/service/;			# NTPD (Network Time Protocol daemon)
sudo ln -s /etc/sv/fail2ban /var/service/;		# Fail2Ban (protección contra ataques de fuerza bruta)
sudo ln -s /etc/sv/iptables /var/service/;		# IPTables (firewall)
sudo ln -s /etc/sv/runit-iptables /var/service/;	# unit-iptables (posible script adicional)
sudo sv up ntpd;
sudo sv up fail2ban;
sudo sv up iptables;
sudo sv up runit-iptables;
sv status ntpd;
sv status fail2ban;
sv status iptables;
sv status runit-iptables;
sudo sv up iptables;sudo sv status iptables;
sudo iptables -L -v -n;sudo ip6tables -L -v -n;
nano ~/iptables_ipv6_rules.sh;
#!/bin/sh
# Script de firewall para IPv4 e IPv6 en Void Linux
# Compatible con /bin/sh, con sudo y ; al final de cada línea
# ----------------------
# Limpiar reglas existentes
# ----------------------
sudo iptables -F;
sudo iptables -X;
sudo iptables -t nat -F;
sudo iptables -t nat -X;
sudo iptables -t mangle -F;
sudo iptables -t mangle -X;
sudo ip6tables -F;
sudo ip6tables -X;
sudo ip6tables -t nat -F;
sudo ip6tables -t nat -X;
sudo ip6tables -t mangle -F;
sudo ip6tables -t mangle -X;
# ----------------------
# Políticas por defecto
# ----------------------
sudo iptables -P INPUT DROP;
sudo iptables -P FORWARD DROP;
sudo iptables -P OUTPUT ACCEPT;
sudo ip6tables -P INPUT DROP;
sudo ip6tables -P FORWARD DROP;
sudo ip6tables -P OUTPUT ACCEPT;
# ----------------------
# Permitir loopback
# ----------------------
sudo iptables -A INPUT -i lo -j ACCEPT;
sudo iptables -A OUTPUT -o lo -j ACCEPT;
sudo ip6tables -A INPUT -i lo -j ACCEPT;
sudo ip6tables -A OUTPUT -o lo -j ACCEPT;
# ----------------------
# Permitir conexiones ya establecidas y relacionadas
# ----------------------
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
sudo ip6tables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT;
# ----------------------
# Puertos permitidos
# ----------------------
# SSH
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 22 -j ACCEPT;
# HTTP/HTTPS
sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 80 -j ACCEPT;
sudo ip6tables -A INPUT -p tcp --dport 443 -j ACCEPT;
# Ping (ICMP)
sudo iptables -A INPUT -p icmp --icmp-type echo-request -j ACCEPT;
sudo ip6tables -A INPUT -p ipv6-icmp --icmpv6-type echo-request -j ACCEPT;
# ----------------------
# Rechazar todo lo demás explícitamente
# ----------------------
sudo iptables -A INPUT -j REJECT;
sudo iptables -A FORWARD -j REJECT;
sudo ip6tables -A INPUT -j REJECT;
sudo ip6tables -A FORWARD -j REJECT;
# ----------------------
# Guardar reglas
# ----------------------
sudo iptables-save > /etc/iptables/rules.v4;
sudo ip6tables-save > /etc/iptables/rules.v6;
echo "Reglas de iptables e ip6tables aplicadas y guardadas;";
#--------------------------------------
#--------------------------------------
sudo chmod -R a+rwX /run/media/usuario/ET/ET/void-mklive/
#--------------------------------------
========================================
 WORLD OF TANKS EN WINE (SIN DXVK)
 CONFIGURACIÓN LIMPIA - AMD HD 6550D
========================================
1) LIMPIAR WINE COMPLETAMENTE
wineserver -k
rm -rf ~/.wine ~/.wine_wot ~/.cache/wine ~/.cache/winetricks ~/.local/share/wine ~/.config/wine
2) CREAR PREFIX NUEVO
export WINEPREFIX=$HOME/.wine_wot;
export WINEARCH=win64;
winecfg;
3) CONFIGURAR WINECFG
- Windows version: Windows 10
- Graphics:
  ✔ Emulate virtual desktop (1280x720 recomendado)
4) INSTALAR DEPENDENCIAS (SIN VULKAN / SIN DXVK)
winetricks -q vcrun2005 vcrun2008 vcrun2010 vcrun2012 vcrun2013 vcrun2015 vcrun2019;
winetricks -q  directx9 directx10 d3dx9 d3dx10;
winetricks -q  dotnet35 dotnet45 dotnet48;
winetricks -q  corefonts msxml3 msxml6 wininet urlmon;
winetricks settings renderer=gl;
winetricks settings csmt=on;
winetricks settings videomemorysize=512;
date;
winetricks -q ie8;
5) INSTALAR WORLD OF TANKS
export WINEPREFIX=$HOME/.wine_wot
wine /home/usuario/Documentos/wot/world_of_tanks_install_na_di714y54eawj.exe
6) EJECUTAR GAME CENTER
export WINEPREFIX=$HOME/.wine_wot;
wine "$WINEPREFIX/drive_c/Program Files/Wargaming.net/GameCenter/wgc.exe";
7) SI FALLA EL GAME CENTER
- Ejecutar el juego directo
- Forzar DX9:
-force-d3d9
8) CONFIGURACIÓN GRÁFICA RECOMENDADA
- Resolución: 1280x720
- Sombras: OFF
- AA: OFF
- Postprocesado: LOW/OFF
- Texturas: LOW/MED
NOTAS IMPORTANTES:
✔ GPU: AMD Radeon HD 6550D
✔ OpenGL: FUNCIONA
❌ Vulkan: NO SOPORTADO
❌ DXVK: NO USAR
✔ Mejor backend: WineD3D (OpenGL)
✔ Mejor modo: DirectX 9
========================================
#--------------------------------------
#--------------------------------------
#--------------------------------------
#--------------------------------------
Para iniciar una `.iso` en una máquina virtual usando QEMU desde la terminal (CLI), el comando básico es:
```bash
qemu-system-x86_64 -cdrom gnuLinux.iso -boot d -m 1536
# virtualización moderna y mejor rendimiento
qemu-system-x86_64 -cdrom FreeBSD-15.0-RELEASE-amd64-dvd1.iso -boot d -m 2048
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 1536 \
  -smp 2 \
  -cdrom FreeBSD-15.0-RELEASE-amd64-dvd1.iso \
  -boot d
# KVM no está disponible
qemu-system-x86_64 \
  -m 1536 \
  -smp 2 \
  -cdrom FreeBSD-15.0-RELEASE-amd64-dvd1.iso \
  -boot d
# Mouse no funciona bien
qemu-system-x86_64 \
  -m 1536 \
  -smp 2 \
  -cpu host \
  -cdrom FreeBSD-15.0-RELEASE-amd64-dvd1.iso \
  -boot d \
  -usb -device usb-tablet
# UNDB
qemu-img create -f qcow2 /run/media/usuario/UNDB/UNDB/freebsd.img 20G
#INSTALAR 
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 1024 \
  -smp 2 \
  -cdrom /run/media/usuario/UNDA/UNDA/freebsd-custom/FreeBSD-15.0-RELEASE-amd64-dvd1.iso \
  -boot d \
  -drive file=/run/media/usuario/UNDB/UNDB/freebsd.img,format=qcow2 \
  -usb -device usb-tablet
# ARRANCAR QUITAR CD-ROM
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 1024 \
  -smp 2 \
  -boot d \
  -drive file=/run/media/usuario/UNDB/UNDB/freebsd.img,format=qcow2 \
  -usb -device usb-tablet
  -fsdev local,id=fsdev0,path=/run/media/usuario/UNDB/UNDB/qemu_usb/,security_model=none \
  -device virtio-9p-pci,fsdev=fsdev0,mount_tag=share
root
Activar pkg pkg Si no existe: env ASSUME_ALWAYS_YES=yes pkg bootstrap
mkdir -p /run/media/usuario/UNDB/UNDB/qemu_usb/
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 512 \
  -smp 2 \
  -drive file=/run/media/usuario/UNDB/UNDB/freebsd.img,format=qcow2 \
  -boot d \
  -netdev user,id=n1 -device e1000,netdev=n1 \
  -fsdev local,id=fsdev0,path=/run/media/usuario/UNDB/UNDB/qemu_usb/,security_model=none \
  -device virtio-9p-pci,fsdev=fsdev0,mount_tag=share
mkdir -p /mnt/usb
mount -t 9p -o trans=virtio share /mnt/usb
# kernel no soporta 9p (virtio-9p) o no lo tiene habilitado en esa ISO/instalación.
qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 512 \
  -smp 2 \
  -drive file=/run/media/usuario/UNDB/UNDB/freebsd.img,format=qcow2 \
  -netdev user,id=n1,hostfwd=tcp::2222-:22 \
  -device e1000,netdev=n1
```
### Qué hace cada opción
* `-cdrom gnuLinux.iso` → monta la ISO como lectora de CD/DVD.
* `-boot d` → arranca desde el CD/DVD.
* `-m 2048` → asigna 2 GB de RAM.
---
## Ejemplo completo
```bash
qemu-system-x86_64 \
  -enable-kvm \
  -m 4096 \
  -smp 4 \
  -cdrom ubuntu.iso \
  -boot d
```
### Opciones útiles
* `-enable-kvm` → usa aceleración por hardware (mucho más rápido).
* `-smp 4` → 4 CPUs virtuales.
* `-m 4096` → 4 GB RAM.
---
## Crear un disco virtual
Antes de instalar un sistema operativo, normalmente creás un disco:
```bash
qemu-img create -f qcow2 disco.qcow2 40G
```
Luego arrancás la instalación:
```bash
qemu-system-x86_64 \
  -enable-kvm \
  -m 4096 \
  -smp 4 \
  -hda disco.qcow2 \
  -cdrom ubuntu.iso \
  -boot d
```
---
## Después de instalar el SO
Ya no necesitás bootear desde la ISO:
```bash
qemu-system-x86_64 \
  -enable-kvm \
  -m 4096 \
  -smp 4 \
  -hda disco.qcow2
```
---
## Verificar soporte KVM en Linux
```bash
lsmod | grep kvm
```
O:
```bash
kvm-ok
```
(si tenés instalado `cpu-checker`).
---
## Instalar QEMU (Linux)
### Debian/Ubuntu
```bash
sudo apt install qemu-kvm qemu-system qemu-utils
```
### Arch
```bash
sudo pacman -S qemu-full
```
### Fedora
```bash
sudo dnf install @virtualization
```
---
## UEFI (opcional)
Para boot UEFI:
```bash
qemu-system-x86_64 \
  -bios /usr/share/OVMF/OVMF_CODE.fd \
  -cdrom ubuntu.iso
```
---
## Modo sin interfaz gráfica
```bash
qemu-system-x86_64 -nographic -cdrom alpine.iso
```
Ideal para servidores o ISOs minimalistas.
---
## Redirección de puertos (SSH)
Ejemplo: acceder al guest por SSH:
```bash
qemu-system-x86_64 \
  -nic user,hostfwd=tcp::2222-:22
```
Luego:
```bash
ssh usuario@localhost -p 2222
```
