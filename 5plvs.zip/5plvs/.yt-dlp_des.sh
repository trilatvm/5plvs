#!/bin/sh
# Scritp 100% POSIX (NO BASH): Debian, Void, FreeBSD, etc.
# Scritp 100% GPL
set -e
AMA=; VER=; ROJ=; RST=;	# Definición colores ANSI
RTA=;	# Ruta seleccionada por el usuario
SCRIPT_DIR=;	# Directorio donde está este ejecutable
# Variables de selección
LISTA_SUBDIRS=""
TOTAL_DIRS=0
SELECCION=""
# ---------------------------------------------------------------------------- #
# ---------------------------------------------------------------------------- #
verificarDependencias(){
	for cmd in yt-dlp ffmpeg; do
		if ! command -v "$cmd" >/dev/null 2>&1; then
			printf "%bError: El comando '%s' no está instalado en el PATH.%b\n" "$ROJ" "$cmd" "$RST"
			exit 1
		fi
	done
}
verificarRTAvalida(){
	if [ -z "$RTA" ]; then
		RTA="$SCRIPT_DIR"
		printf "%bUso de ruta por defecto: %s%b\n" "$AMA" "$RTA" "$RST"
	fi
	if [ ! -d "$RTA" ]; then
		printf "%bError: El directorio '%s' no existe.%b\n" "$ROJ" "$RTA" "$RST"
		return 1
	fi
	# Elimina barras diagonales al final
	RTA=$(printf '%s' "$RTA" | sed 's:/*$::')
	return 0
}
solicitarRTA(){
	while :; do
		printf "%bIngrese la ruta del directorio base (ENTER para '%s'): %b" "$AMA" "$SCRIPT_DIR" "$RST"
		read -r RTA
		if verificarRTAvalida; then
			break
		fi
		printf "\n%bIntente nuevamente.%b\n\n" "$AMA" "$RST"
	done
}
listarYSeleccionarCarpetas(){
	printf "\n%bBuscando carpetas con archivos .lta en '%s'...%b\n" "$AMA" "$RTA" "$RST"
	# Buscar carpetas que tengan un .lta adentro o un archivo .lta con el nombre del directorio
	LISTA_SUBDIRS=""
	TOTAL_DIRS=0
	# Recorrer subdirectorios de primer nivel y la propia carpeta raíz
	for dir in "$RTA" "$RTA"/*; do
		if [ -d "$dir" ]; then
			base="${dir##*/}"
			# Buscar si existe alguna variante de .lta
			lta_match=""
			if [ -f "${dir}/${base}.lta" ]; then
				lta_match="${dir}/${base}.lta"
			elif [ -f "${dir}/.lta" ]; then
				lta_match="${dir}/.lta"
			elif [ -f "${dir}.lta" ]; then
				lta_match="${dir}.lta"
			fi
			if [ -n "$lta_match" ]; then
				TOTAL_DIRS=$((TOTAL_DIRS + 1))
				printf "%3d) %s\n" "$TOTAL_DIRS" "$base"
				LISTA_SUBDIRS="${LISTA_SUBDIRS}${dir}|"
			fi
		fi
	done
	if [ "$TOTAL_DIRS" -eq 0 ]; then
		printf "%bError: No se encontraron subcarpetas con archivos .lta en '%s'.%b\n" "$ROJ" "$RTA" "$RST"
		exit 1
	fi
	printf "\n%bSelección de carpetas:%b\n" "$VER" "$RST"
	printf "  - Ingrese %b0%b (o presione ENTER) para procesar %bTODAS%b (%d carpetas).\n" "$AMA" "$RST" "$AMA" "$RST" "$TOTAL_DIRS"
	printf "  - Ingrese el número de una carpeta (ej: %b5%b).\n" "$AMA" "$RST"
	printf "  - Ingrese varios números separados por espacio o coma (ej: %b1, 3, 7%b).\n" "$AMA" "$RST"
	printf "%bOpción: %b" "$AMA" "$RST"
	read -r SELECCION
	# Si está vacío, por defecto es 0 (TODAS)
	if [ -z "$SELECCION" ]; then
		SELECCION="0"
	fi
}
procesarCarpetaEspecifica(){
	DIR_OBJETIVO="$1"
	BASE_OBJETIVO="${DIR_OBJETIVO##*/}"
	# Determinar cuál archivo .lta corresponde
	LTA_FILE=""
	if [ -f "${DIR_OBJETIVO}/${BASE_OBJETIVO}.lta" ]; then
		LTA_FILE="${DIR_OBJETIVO}/${BASE_OBJETIVO}.lta"
	elif [ -f "${DIR_OBJETIVO}/.lta" ]; then
		LTA_FILE="${DIR_OBJETIVO}/.lta"
	elif [ -f "${DIR_OBJETIVO}.lta" ]; then
		LTA_FILE="${DIR_OBJETIVO}.lta"
	fi
	if [ -z "$LTA_FILE" ]; then
		printf "%b[OMITIDO] No se encontró .lta en %s%b\n" "$ROJ" "$BASE_OBJETIVO" "$RST"
		return 0
	fi
	printf "\n%b====================================================%b\n" "$VER" "$RST"
	printf "%bProcesando canal/carpeta: %s%b\n" "$AMA" "$BASE_OBJETIVO" "$RST"
	printf "%bArchivo de URLs: %s%b\n" "$AMA" "$LTA_FILE" "$RST"
	printf "%b====================================================%b\n\n" "$VER" "$RST"
	mkdir -p "${DIR_OBJETIVO}/tmp" "${DIR_OBJETIVO}/mkv"
	yt-dlp \
		-f "bv*[vcodec*=avc1][height<=360]+ba/bv*[height<=360]+ba/b" \
		-a "$LTA_FILE" \
		--download-archive "${DIR_OBJETIVO}/.rtg" \
		--socket-timeout 45 \
		--retries 45 \
		--fragment-retries 5 \
		--extractor-retries 5 \
		--sleep-interval 1 \
		--sleep-subtitles 1 \
		--sleep-requests 1 \
		--limit-rate 4096K \
		--concurrent-fragments 1 \
		--no-cache-dir \
		--embed-metadata \
		--embed-chapters \
		--embed-info-json \
		--write-info-json \
		--write-subs \
		--write-auto-subs \
		--convert-subs srt \
		--embed-subs \
		--sub-format "best[ext=srt]/best" \
		--sub-lang en,es,it,la,zh-Hans \
		--remux-video mkv \
		--no-mtime \
		--trim-filenames 180 \
		--restrict-filenames \
		--js-runtimes node \
		-o "${DIR_OBJETIVO}/tmp/%(uploader)s.%(upload_date)s.%(id)s.%(title)s.%(playlist_title,playlist_index|SN)s.%(ext)s" \
		--exec "mv {} ${DIR_OBJETIVO}/mkv/"
# 		--exec "mv {} ${DIR_OBJETIVO}/mkv/" || true
#		-o "${DIR_OBJETIVO}/tmp/%(upload_date)s.%(id)s.%(uploader)s.%(playlist_title,playlist_index|SN)s.%(title)s.%(ext)s" \
}
obtenerCarpetaPorIndice(){
	TARGET_IDX="$1"
	curr_idx=1
	old_ifs="$IFS"
	IFS="|"
	for dir_item in $LISTA_SUBDIRS; do
		if [ -n "$dir_item" ]; then
			if [ "$curr_idx" -eq "$TARGET_IDX" ]; then
				IFS="$old_ifs"
				printf "%s" "$dir_item"
				return 0
			fi
			curr_idx=$((curr_idx + 1))
		fi
	done
	IFS="$old_ifs"
	return 1
}
procesar(){
	solicitarRTA
	listarYSeleccionarCarpetas
	# Normalizar separadores de comas a espacios en la selección del usuario
	SELECCION_LIMP="$(printf '%s' "$SELECCION" | tr ',' ' ')"
	# Si eligió 0, procesar todas las carpetas encontradas
	if [ "$SELECCION_LIMP" = "0" ]; then
		curr_idx=1
		old_ifs="$IFS"
		IFS="|"
		for dir_item in $LISTA_SUBDIRS; do
			if [ -n "$dir_item" ]; then
				procesarCarpetaEspecifica "$dir_item"
			fi
		done
		IFS="$old_ifs"
	else
		# Procesar solo los números indicados
		for num in $SELECCION_LIMP; do
			dir_item=$(obtenerCarpetaPorIndice "$num")
			if [ -n "$dir_item" ]; then
				procesarCarpetaEspecifica "$dir_item"
			else
				printf "%b[AVISO] Número inválido ignorado: %s%b\n" "$ROJ" "$num" "$RST"
			fi
		done
	fi
}
inicializar(){ 
	AMA='\033[0;33m'; VER='\033[0;32m'; ROJ='\033[0;31m'; RST='\033[0m'
	SCRIPT_DIR=$(cd "$(dirname "$0")" && pwd)
	verificarDependencias
}
liberar(){ sync; }
finalizar(){
	liberar
	printf "%b\n--- SCRITP FIN    ---%b\n" "$VER" "$RST"
	printf "%b\n[$(date)]%b\n" "$ROJ" "$RST"
}
iniciar(){
	liberar
	inicializar
	clear
	printf "%b\n--- SCRITP INICIO ---%b\n" "$VER" "$AMA"
	printf "%b\n[$(date)]%b\n" "$ROJ" "$RST"
}
main(){ iniciar; procesar; finalizar; }
# ---------------------------------------------------------------------------- #
# ---------------------------------------------------------------------------- #
main
# ---------------------------------------------------------------------------- #
# ---------------------------------------------------------------------------- #
exit 0
