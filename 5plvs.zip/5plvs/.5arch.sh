#!/bin/sh
# .5arch.sh: Logica de archivo y permisos
verificarDirectorio() { [ -d "$1" ] && [ -r "$1" ] && [ -w "$1" ] ; }
asegurarDirectorio() { [ ! -d "$1" ] && mkdir -p "$1" ; }
verificarArchivoLectura() { [ -f "$1" ] && [ -r "$1" ] ; }
validarExclusionEcosistema() {
	case "$1" in
		*".5arch.sh"|*".5bckp.sh"|*".5cli.sh"|*".5hash.sh"|*".5par2.sh"|*".5rgx.sh"|*".5tmp.sh"|*".5colores.sh"|*".5genArch.sh") return 1 ;;
		*) return 0 ;;
	esac ; }
contarArchivos() {
	caFE=$1 ; caDM=$2 ; caCA=0
	for caEA in "$caDM"/*; do
		if [ ! -f "$caEA" ] || [ -d "$caEA" ] || ! validarArchivoRegex "$caEA" || ! validarExclusionEcosistema "$caEA" || ! verificarArchivoLectura "$caEA"; then continue ; fi
		if [ -n "$caFE" ]; then case "$caEA" in *."$caFE") caCA=$((caCA + 1)) ;; esac
		else caCA=$((caCA + 1)) ; fi ; done
	printf "%d" "$caCA" ; }
inicializarEntornoTrabajo() {
	printf "\033[H\033[2J" ; printf "%b=== INICIO ===%b\n" "$cia" "$rst" ; mInf "Base: $1"
	mPgt "Dir objetivo ([ENTER] por defecto): " ; read -r entradaDir
	if [ -z "$entradaDir" ]; then directorioActual="$1"; else directorioActual="$entradaDir"; fi
	if ! verificarDirectorio "$directorioActual"; then mErr "Ruta inválida." && exit 1; fi ; }
ejecutarConmutacionDir() {
	printf "\n" ; mPgt "Ruta abs: " ; read -r nuevoDir
	if [ -z "$nuevoDir" ]; then mInf "Cancelado."
	elif ! validarRutaAbsolutaRegex "$nuevoDir"; then mErr "Sintaxis de ruta Unix inválida."
	elif verificarDirectorio "$nuevoDir"; then directorioActual="$nuevoDir" ; mOk "Cambiado."
	else mErr "Inválido o sin permisos." ; fi
	esperarEnter ; }
auditarFirmasHuerfanas() {
	afDT=$1 ; afLA=$2 ; [ ! -d "$afDT/hashes" ] && return 0
	for afAlgDir in "$afDT/hashes"/*; do
		[ ! -d "$afAlgDir" ] && continue ; afAN=$(basename "$afAlgDir")
		for afHF in "$afAlgDir"/*; do
			[ ! -f "$afHF" ] && continue ; afOrigName=$(basename "$afHF" ".$afAN")
			if [ ! -f "$afDT/$afOrigName" ]; then
				printf "\n" ; mPgt "Firma huerfana detectada: $afOrigName.$afAN. ¿Eliminar? (s/n): " ; read -r rE
				if [ "$rE" = "s" ] || [ "$rE" = "S" ]; then rm -f "$afHF" ; mOk "Removido." ; fi ; fi ; done ; done ; }