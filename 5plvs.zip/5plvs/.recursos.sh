#!/bin/sh
set -eu
buffer(){ sync; }