#!/bin/sh
set -e;	# Finalizar inmediatamente si ocurre un error
# VAR --------------------------------------------------------------------------
msj= ; ts= ; tsEpoch= ;	# Variables globales
# VAR --------------------------------------------------------------------------
# FNC --------------------------------------------------------------------------
rgstr() { printf "%s\t%s\n" "$1" "$2" >> "0CMB.log"; }	# registro cambios
fina() {	# finalizar
	impr_tit "Script Fin"; sync; }	 # ultimo mensaje / Flush buffers, Forzar escritura de buffers pendientes a disco
proc() {	# procesar
	impr_tit "Proceso iniciar";
	impr_pgt "Preguntar";
	impr_adv "Advertir";
	impr_inf "Informar";
	impr_msj "Mostrar";
	impr_tit "Proceso finalizar"; }
adjT() {	# ajustar tiempo
	if date -s "2232-04-18 20:47:15" >/dev/null 2>&1; then
		impr_adv "Tiempo ajustado"	# Éxito
	else
		impr_err "Tiempo NO ajustado"	# Fallo
	fi; }
gtTS() {	# estampar tiempo
	date +"%Y%m%d%H%M%S";				# [22320418213808] timestamp
#	tsEpoch=$(date +"%s");				# [8277284288] seconds since the Epoch (1970-01-01 00:00 UTC)
#	ts=$(date --date='@${tsEpoch}');	# [Wed Apr 18 09:38:08 PM GMT 2232] Convert seconds since the Epoch (1970-01-01 UTC) to a date
#	echo $(ts);
}
impr() { printf "[%s][%s] %s\n" "$(gtTS)" "$1" "$2"; }		# imprimir consola
impr_err() { impr "ERR" "$1"; }					# error
impr_adv() { impr "ADV" "$1"; }					# advertencia
impr_inf() { impr "INF" "$1"; }					# informacion
impr_msj() { impr "MSJ" "$1"; }					# mensaje
impr_pgt() { impr " ? " "$1"; }					# pregunta
impr_tit() { impr_msj "---> $1"; }				# titulo
inic() {	# inicializar
	clear; impr_tit "Script Inicio"; adjT; }	# Limpiar pantalla / 1er msj / ajustar tiempo
main() {	# iniciar
	inic; proc; fina; }
# FNC --------------------------------------------------------------------------
# PPA --------------------------------------------------------------------------
main;
# FIN --------------------------------------------------------------------------
exit 0;	# Salida limpia
#
#
#
# GUIA TECNICA Unix & GNU/Linux Tips and Tricks CLI HERRAMIENTAS ESENCIALES
# Convencion:
  comando;			# comentario [valor típico]
# GIT (control de versiones)
  git init;			# Inicializar repositorio
  git clone "url";		# Clonar repositorio remoto
  git status;			# Estado del repositorio
  git add .;			# Agregar cambios al staging
  git commit -m "mensaje";	# Confirmar cambios
  git log --oneline --graph;	# Historial compacto
  git diff;			# Ver cambios no confirmados
  git pull;			# Descargar y fusionar cambios
  git push origin main;		# Subir cambios rama main
  git branch;			# Listar ramas
  git checkout -b nueva_rama;	# Crear y cambiar rama
  git merge "rama";		# Fusionar ramas
# POSTGRESQL (CLI psql)
  psql -U usuario -d basedatos;			# Conectar a base de datos
  psql -h localhost -U usuario -d basedatos;	# Conexión remota/local
  \l;						# Listar bases de datos
  \c basedatos;					# Conectar a base
  \dt;						# Listar tablas
  \d tabla;					# Describir tabla
  CREATE DATABASE test;				# Crear base de datos
  CREATE TABLE test(id SERIAL PRIMARY KEY);	# Crear tabla
  INSERT INTO test VALUES (1);			# Insertar datos
  SELECT * FROM test;				# Consultar datos
  DROP DATABASE test;				# Eliminar base de datos
# WGET (descargas HTTP)
  wget "url";				# Descargar archivo
  wget -c "url";			# Continuar descarga
  wget -O archivo;			# Guardar con nombre específico
  wget -r "url";			# Descarga recursiva
  wget --limit-rate=200k "url";		# Limitar velocidad
  wget -b "url";			# Descarga en segundo plano
# TORRENT (CLI: transmission-cli / aria2)
  transmission-cli "archivo.torrent";	# Descargar torrent
  transmission-show "archivo.torrent";	# Info torrent
  aria2c "archivo.torrent";		# Descargar torrent con aria2
  aria2c -x 16 "url";			# Descarga multiproceso
  aria2c -s 16 -k 1M "url";		# Segmentación avanzada
# ARIA2 (descargas avanzadas)
  aria2c "url";				# Descargar archivo
  aria2c -c "url";			# Reanudar descarga
  aria2c -x 16 -s 16 "url";		# Multi conexión
  aria2c -i lista.txt;			# Descargas múltiples
  aria2c --seed-time=0 "torrent";	# Torrent sin seed
# YT-DLP (YouTube / video downloader CLI)
  yt-dlp "url";				# Descargar video
  yt-dlp -f best "url";			# Mejor calidad
  yt-dlp -x --audio-format mp3 "url";		# Extraer audio
  yt-dlp -o "%(title)s.%(ext)s" "url";		# Nombre personalizado
  yt-dlp --playlist "url";			# Descargar playlist
  yt-dlp --download-archive log.txt "url";	# Evitar duplicados
# NTP (sincronización hora)
  sudo ntpd -qg;		# Sincronizar hora manual
  sudo ntpd -q;		# Ajuste rápido
  timedatectl status;		# Ver estado hora
  timedatectl set-ntp true;	# Activar sincronización
  ntpq -p;			# Servidores NTP
# VIM (editor terminal)
  vim archivo.txt;	# Abrir archivo
  i;			# Insertar modo edición
  Esc;			# Salir modo edición
  :w;			# Guardar
  :q;			# Salir
  :wq;			# Guardar y salir
  :q!;			# Salir sin guardar
  dd;			# Borrar línea
  yy;			# Copiar línea
  p;			# Pegar
  /texto;		# Buscar texto
  :%s/a/b/g;		# Reemplazar global
# WEBHTTRACK (clonado web offline)
  httrack "url";		# Clonar sitio web
  httrack "url" -O ./mirror;	# Guardar en carpeta
  httrack --mirror "url";	# Modo espejo completo
  httrack --depth=3 "url";	# Profundidad enlaces
  httrack --robots=0 "url";	# Ignorar robots.txt
# BASE - DISPOSITIVOS
  lsblk;						# listar bloques
  lsusb;						# listar USB
  fdisk -l;						# ver particiones
  fdisk -l /dev/"sdX7";					# partición específica
  rm *;							# borrar archivos (peligroso)
  rm -n *;						# modo interactivo seguro
  cp "origen" "destino";				# copiar
  mv "origen" "destino";				# mover/renombrar
  mkdir -p /mnt/"usb";					# crear punto montaje
  mount -t exfat /dev/"sdX7" /mnt/"usb";		# montar exFAT
  mount -t ntfs-3g /dev/"sdX7" /mnt/"usb";		# montar NTFS
  nano /etc/fstab;					# montaje automático
 '/dev/"sdX7"  /mnt/"usb"  exfat  defaults  0  0	
  /dev/"sdX7"  /mnt/ntfs  ntfs-3g defaults  0  0'	
  umount /mnt/"usb";					# desmontar
# FRAGMENTACIÓN HDD
  e4defrag -c /dev/"sdX7";		# analizar fragmentación
  e4defrag /dev/sda3;			# desfragmentar ext4
# S.M.A.R.T.
  smartctl -i /dev/"sdX7";		# info SMART
  smartctl -s on /dev/"sdX7";		# activar SMART
  smartctl -H /dev/"sdX7";		# health status
  smartctl -A /dev/"sdX7";		# atributos
  smartctl -t short /dev/"sdX7";	# test corto
  smartctl -t long /dev/"sdX7";		# test largo
  smartctl -a /dev/"sdX7";		# reporte completo
# TIEMPO
  date -s "2232-04-18 20:47:15";				# set fecha manual
  timedatectl set-timezone America/Argentina/Buenos_Aires;	# zona horaria
# MEMORIA
  sysctl vm.swappiness=10;	# swappiness
  sysctl vm.drop_caches=3;	# liberar cache
# PAQUETES
  xbps-install -Syu;					# update Void
  apt update;						# update Debian
  pkg update;						# update BSD
  xbps-install -Syu;					# upgrade Void
  apt upgrade -y;					# upgrade Debian
  pkg upgrade -y;					# upgrade BSD
  sudo xbps-install aria2 wget | tee -a web.log;	# instalar paquetes
  ps aux | grep xbps;					# procesos xbps
# kill procesos bloqueados:
  sudo kill -9 "PID";
  mv /var/cache/xbps/* /run/media/usuario/dt/dt/src/;	# mover cache
# NODE / WEB
  xbps-install -Sy nodejs-lts | tee -a node.log;
  xbps-install aria2 wget | tee -a web.log;
# SISTEMAS DE ARCHIVOS SOPORTADOS
# exFAT
  xbps-install -S exfatprogs;
  mkexfatfs -n "miDisco" /dev/"sdX7";
  fsck.exfat /dev/"sdX7";
  mount -t exfat /dev/"sdX7" /mnt/"usb";
  exfatlabel /dev/"sdX7" "nuevoNombre";
# NTFS
  xbps-install -S ntfs-3g;
  mkntfs -L "miDisco" /dev/"sdX7";
  ntfsfix /dev/"sdX7";
  mount -t ntfs-3g /dev/"sdX7" /mnt/ntfs;
  ntfslabel /dev/"sdX7" "nuevoNombre";
# FAT32
  xbps-install -S dosfstools;
  mkfs.vfat -F 32 -n "miDisco" /dev/"sdX7";
  fsck.vfat /dev/"sdX7";
  mount -t vfat /dev/"sdX7" /mnt/"usb";
  dosfslabel /dev/"sdX7" "nuevoNombre";
# ZFS
  xbps-install -S zfs-lts;
  zpool create "miPool" /dev/sdb;
  zpool create "miPool" mirror /dev/sdb /dev/sdc;
  zpool scrub "miPool";
  zpool status;
  zfs create "miPool"/"miDataset";
  zfs mount "miPool"/"miDataset";
  zpool export "miPool";
  zpool import "miPool" NuevoNombre;
  zfs rename "miPool"/"miDataset" "miPool"/"nuevoDataset";
# HFS+
  xbps-install -S hfsprogs;
  mkfs.hfsplus -v "miDisco" /dev/"sdX7";
  fsck.hfsplus /dev/"sdX7";
  mount -t hfsplus /dev/"sdX7" /mnt/mac;
  hfspluslabel /dev/"sdX7" "nuevoNombre";
# APFS
  xbps-install -S apfs-fuse apfsprogs;
  apfs-fuse /dev/"sdX7" /mnt/mac;		# solo lectura
# EXT4
  xbps-install -S e2fsprogs;
  mkfs.ext4 -L "miDisco" /dev/"sdX7";
  e2fsck -f /dev/"sdX7";
  mount -t ext4 /dev/"sdX7" /mnt/linux;
  e2label /dev/"sdX7" "nuevoNombre";
  tune2fs -L "nuevoNombre" /dev/"sdX7";
# PROCESOS
  ps aux;			# procesos
  top;				# monitor
  htop;				# monitor avanzado
  pgrep "nombre";		# buscar proceso
  pkill "nombre";		# matar por nombre
  kill "PID";			# matar PID
  nice -n "valor" "comando";	# prioridad
  renice -n "valor" -p "PID";	# cambiar prioridad
  kill -STOP "PID";		# pausar
  kill -CONT "PID";		# continuar
# RED
  ip addr;		# interfaces
  ifconfig;		# legacy
  iwconfig;		# wifi legacy
  netstat -tuln;	# puertos
  ss -tuln;		# puertos moderno
  ip route show;	# rutas
  route -n;		# rutas legacy
  ping "host";		# conectividad
  traceroute "host";	# ruta
# SEGURIDAD
  whoami;
  id;
  groups;
  ls -l;
  chmod "modo" "archivo";
  chown "usuario":"grupo" "archivo";
  tail -f /var/log/auth.log;
  dmesg | grep -i error;
  passwd "usuario";
  cat /etc/passwd;
# ARCHIVOS
  find /ruta -name "archivo*";
  locate "archivo";
  which "comando";
  cat "archivo";
  less "archivo";
  head "archivo";
  tail "archivo";
  tar -czvf archivo.tar.gz "dir";
  tar -xzvf archivo.tar.gz;
  zip archivo.zip "archivo";
  unzip archivo.zip;
# DISCOS
  lsblk;
  blkid;
  fdisk -l;
  parted -l;
  mkfs.ext4 /dev/sdX1;
  mkfs.ntfs /dev/sdX1;
  mount /dev/sdX1 /mnt;
  nano /etc/fstab;
  mount -a;
# SISTEMA
  df -h;
  du -sh "dir";
  free -h;
  vmstat;
  uptime;
  mpstat -P ALL;
  nmon;
  glances;
# CRON
  crontab -e;
  crontab -l;
# NTP / HORA
  sudo xbps-install -S ntp;
  sudo ln -s /etc/sv/ntpd /var/service/;
  ntpq -p;
  timedatectl status;
  sudo xbps-install -S chrony;
  sudo ln -s /etc/sv/chronyd /var/service/;
  chronyc tracking;
  chronyc sources;
  sudo ntpdate pool.ntp.org;
  sudo timedatectl set-ntp true;
  timedatectl set-timezone "zona_horaria";
# REGEX SH / POSIX - CASOS TIPICOS UNIX & GNU/LINUX
# LINEAS VACIAS / LIMPIEZA TEXTO
  '^[[:space:]]*$'		# línea completamente vacía
  '^[[:space:]]*#'		# comentarios o líneas comentadas
  '^[[:space:]]*[^[:space:]]'	# líneas con contenido (no vacías)
  '^[[:space:]]+|[[:space:]]+$'	# espacios al inicio o final
# ARCHIVOS / EXTENSIONES
  '.*\.sh$'		# scripts shell
  '.*\.log$'		# logs
  '.*\.conf$'		# configuración
  '.*\.(txt|md|log)$'	# múltiples extensiones
# DISPOSITIVOS (/dev)
  '^/dev/sd[a-z][0-9]*$'		# discos y particiones SATA/SCSI
  '^/dev/nvme[0-9]n[0-9]p[0-9]+$'	# NVMe
  '^/dev/loop[0-9]+$'			# loop devices
  '^/dev/tty[0-9]+$'			# terminales
  '^/dev/pts/[0-9]+$'			# pseudo terminales
# IP / RED
  '([0-9]{1,3}\.){3}[0-9]{1,3}'		# IPv4 básico
  '^127\.0\.0\.1$'			# localhost
  '^10\.'				# red privada clase A
  '^192\.168\.'				# red privada clase C
  '^172\.(1[6-9]|2[0-9]|3[0-1])\.'	# red privada clase B
# PUERTOS / SERVICIOS
  ':[0-9]{2,5}'	# puertos en netstat/ss
  'LISTEN'	# servicios activos
  'ESTABLISHED'	# conexiones activas
# PAQUETES (XBPS/APT/PKG)
  '^[a-z0-9][a-z0-9\-]+$'	# nombre de paquete simple
  '^[a-z0-9\-]+-[0-9]'		# paquete con versión
  'installed|upgraded|removed'	# estados típicos logs
# PROCESOS
  '^[0-9]+'				# PID
  '^[a-zA-Z0-9_\-]+$'			# nombre proceso simple
  '^(root|user|daemon|systemd)$'	# usuarios sistema
# FECHA / TIEMPO (logs)
  '[0-9]{4}-[0-9]{2}-[0-9]{2}'		# fecha YYYY-MM-DD
  '[0-9]{2}:[0-9]{2}:[0-9]{2}'		# hora HH:MM:SS
  '[A-Z][a-z]{2} [A-Z][a-z]{2} [0-9]+'	# formato tipo syslog
# MONTAJES / FSTAB
  '^/dev/.*[[:space:]]+/mnt/'				# mounts en /mnt
  '^(UUID|LABEL)=.*'					# fstab identificadores
  '[[:space:]](ext4|ntfs|exfat|vfat)[[:space:]]'	# tipo FS
# URL / RED / DOWNLOADS
  'https?://[^[:space:]]+'	# URL http/https
  'ftp://[^[:space:]]+'		# FTP
  '^[a-z]+://.*'		# cualquier esquema
# LOG LEVELS
  'INFO|WARN|ERROR|DEBUG'	# niveles logs
  '\b(error|fail|failed)\b'	# errores
  '\b(success|ok|done)\b'	# éxito
# FILTRO GENERAL LIMPIO (NEGACIÓN DE VACÍOS)
  '[^[:space:]].*'	# líneas no vacías
  '.+'			# al menos un carácter
  '\t+[[:alpha:]]'	# tabulación + una letra
  "'.*#"		# comilla + varios + numeral
  "'\t+#"		# comilla + tabulaciones + numeral
  '# [a-z]'		# numeral + espacio + letra minuscula
  '^# [A-Z]*$'		# inicio de línea + # + espacio + cero o más letras mayúsculas + fin de línea
# RAM
# AJUSTAR SWAPPINESS
  cat /proc/sys/vm/swappiness;						# Verificar valor actual [60 típico]
  mkdir -p /etc/sysctl.d;						# Crear directorio sysctl persistente [/etc/sysctl.d]
  echo "vm.swappiness=10" | sudo tee /etc/sysctl.d/99-swappiness.conf;	# Guardar configuración persistente [10 recomendado desktop]
  sudo sysctl --system;							# Aplicar configuración sysctl sin reiniciar [reload completo]
  sudo sysctl -w vm.swappiness=10;					# Aplicación directa temporal [10 recomendado]
  sysctl vm.swappiness;							# Confirmar valor aplicado [vm.swappiness = 10]
  cat /etc/sysctl.d/99-swappiness.conf;					# Verificar archivo persistente [vm.swappiness=10]
# ACTIVAR ZRAM
  sudo xbps-install -Sy zramen;			# Instalar servicio zram [zramen]
  sudo ln -s /etc/sv/zramen /var/service/;	# Habilitar servicio runit [zramen]
  sudo sv up zramen;				# Iniciar servicio inmediatamente [running]
  sv status zramen;				# Verificar estado servicio [run: zramen]
  swapon --show;				# Ver dispositivos swap activos [/dev/zram0 típico]
  zramctl;					# Mostrar dispositivos zram activos [compresión RAM]
  cat /proc/swaps;				# Ver swaps activos [/dev/zram0]
  free -h;					# Ver memoria y swap legible [MiB/GiB]
# LIMPIEZA DE CACHE XBPS
  sudo xbps-remove -Oo;		# Limpiar caché antigua no utilizada [/var/cache/xbps]
  sudo xbps-remove -o;		# Eliminar paquetes huérfanos [orphans]
  sudo xbps-remove -O;		# Limpiar completamente caché paquetes [cache total]
  du -sh /var/cache/xbps;	# Ver tamaño caché XBPS [MB/GB]
# LIMPIEZA MEMORIA CACHE KERNEL
  sync;						# Sincronizar buffers a disco [recomendado]
  echo 1 | sudo tee /proc/sys/vm/drop_caches;	# Liberar pagecache [1]
  echo 2 | sudo tee /proc/sys/vm/drop_caches;	# Liberar dentries e inodos [2]
  echo 3 | sudo tee /proc/sys/vm/drop_caches;	# Liberar todo cache kernel [3 recomendado]
# VERIFICAR MEMORIA REAL DISPONIBLE
  free -h;				# Memoria RAM y swap legible [MiB/GiB]
  free -m;				# Memoria en megabytes [MB]
  vmstat 1 5;				# Estadísticas memoria/swap CPU [intervalo 1s]
  htop;					# Monitor interactivo recursos [htop]
  btop;					# Monitor avanzado moderno [btop]
  glances;				# Monitor completo sistema [glances]
  cat /proc/meminfo;			# Información completa memoria kernel [/proc/meminfo]
  grep -E 'Mem|Swap' /proc/meminfo;	# Filtrar RAM y swap [/proc/meminfo]
# VERIFICAR ZRAM Y SWAP EN USO
  watch -n 1 swapon --show;		# Monitorear swap en tiempo real [1 segundo]
  watch -n 1 free -h;			# Monitorear memoria en tiempo real [1 segundo]
  cat /sys/block/zram0/disksize;	# Tamaño zram bytes [/dev/zram0]
  cat /sys/block/zram0/comp_algorithm;	# Algoritmo compresión zram [lzo/zstd/lz4]
# DESACTIVAR ZRAM
  sudo swapoff /dev/zram0;	# Desactivar swap zram [/dev/zram0]
  sudo rm /var/service/zramen;	# Deshabilitar servicio runit [zramen]
  sudo sv down zramen;		# Detener servicio [zramen]
# OPERAR RENGLONES
  sed '/#/ s/;$//'							# solo líneas que contienen, elimina ";" al final de línea
  sed 's/$/;/' 0A.sh;							# añadir "espacio + punto-coma" al final de linea
  sed 's/^/  /' 0A.sh;							# Aagregar tres espacios al inicio de cada renglon [0A.sh]
  sed '/^[[:space:]]*$/d' 0A.sh > 2A.sh;				# Eliminar renglones vacíos [0A.sh]
  sed -i '/^[[:space:]]*$/d' 0A.sh;					# Eliminar renglones vacíos inplace GNU sed [0A.sh]
  sed -i.bak '/^[[:space:]]*$/d' 0A.sh;					# Eliminar renglones vacíos y crear backup [0A.sh.bak]
  awk 'NF' 0A.sh > 2A.sh;						# Eliminar líneas vacías usando awk [0A.sh]
  awk 'NF > 0' 0A.sh > 2A.sh;						# Conservar solo líneas con contenido [0A.sh]
  grep -v '^[[:space:]]*$' 0A.sh > 2A.sh;				# Filtrar líneas vacías [0A.sh]
  grep . 0A.sh > 2A.sh;							# Quitar líneas totalmente vacías [0A.sh]
  tr -s '\n' < 0A.sh > 2A.sh;						# Compactar múltiples líneas vacías consecutivas [0A.sh]
  cat -s 0A.sh > 2A.sh;							# Comprimir líneas vacías repetidas [0A.sh]
  perl -ne 'print if /\S/' 0A.sh > 2A.sh;				# Eliminar líneas vacías usando perl [0A.sh]
  sed '/^[[:space:]]*#/d;/^[[:space:]]*$/d' 0A.sh > 2A.sh;		# Quitar comentarios y líneas vacías [0A.sh]
  nl -ba 0A.sh | sed '/^[[:space:]]*[0-9]\+[[:space:]]*$/d';		# Mostrar líneas numeradas ignorando vacías [0A.sh]
  wc -l 0A.sh;								# Contar total de líneas [0A.sh]
  grep -c '^[[:space:]]*$' 0A.sh;					# Contar líneas vacías [0A.sh]
  grep -cv '^[[:space:]]*$' 0A.sh;					# Contar líneas NO vacías [0A.sh]
  dos2unix 0A.sh;							# Convertir CRLF a LF antes de limpiar líneas [0A.sh]
  sed '/^[[:space:]]*$/N;/^\n$/D' 0A.sh;				# Eliminar múltiples líneas vacías consecutivas [0A.sh]
  vi +':g/^[[:space:]]*$/d' +wq 0A.sh;					# Eliminar líneas vacías desde vi/ex [0A.sh]
  ex -sc 'g/^[[:space:]]*$/d|x' 0A.sh;					# Eliminar líneas vacías usando ex [0A.sh]
  find . -type f -iname "*.sh" -exec sed -i '/^[[:space:]]*$/d' {} \;;	# Limpiar líneas vacías en todos los scripts .sh [directorio actual]
  for f in *.sh; do sed -i '/^[[:space:]]*$/d' "$f"; done;			# Limpiar líneas vacías múltiples scripts [*.sh]
  sync;									# Sincronizar cambios a disco [recomendado]
# FECHA / LOGS / SINCRONIZACION
  mkdir -p ./logOS;						# Crear directorio de logs [./logOS]
  cd ./logOS;							# Entrar a logs
  date +"%A %Y-%m-%d %H:%M:%S" | tee -a "date.log";		# Guardar fecha actual
  sudo date -s "2232-04-18 20:47:15";				# Ajustar fecha manual [YYYY-MM-DD HH:MM:SS]
  sudo ntpd -q | tee -a "sincro_ntpd.log";			# Sincronizar reloj vía NTP
  sudo chronyc -a makestep | tee -a "sincro_chronyc.log";	# Ajuste inmediato Chrony
  ps aux | grep chronyd;					# Verificar proceso chronyd
  sudo kill -9 5124;						# Matar PID manual [PID]
  sudo kill -9 7332;
# XBPS / REPOSITORIOS / ACTUALIZACION
  sudo xbps-install -S;		# Sincronizar índices remotos
  sudo xbps-install -Suy;		# Actualización completa
  sudo xbps-install -y firefox-esr;	# Instalar paquete automáticamente
  xbps-query -l;			# Listar paquetes instalados
  xbps-query -Rs xfce;			# Buscar paquetes
  sudo xbps-query -Rs pps;		# Buscar paquetes relacionados
# BASE SYSTEM
  sudo xbps-install -Suy \
  base-system \
  base-devel \
  xbps \
  base-files \
  libgcc \
  dash \
  coreutils \
  sed \
  tar \
  gawk \
  binutils \
  xz \
  gzip \
  bzip2 \
  make \
  gcc \
  cmake \
  automake;	# Sistema base compilación
# HOLD PAQUETES
  sudo xbps-pkgdb -m hold grub-terminus;	# Bloquear paquete
  sudo xbps-pkgdb -m hold terminus-font;
  sudo xbps-pkgdb -m hold kbd;
# INSPECCION MASIVA DE PAQUETES
  for pkg in xbps base-devel dialog grub; do
  xbps-query -R "$pkg" 2>&1 | tee -a "${pkg}.inf";
  done;
# SIMULACION INSTALACION
  for pkg in xbps base-devel dialog grub; do
  xbps-install --dry-run "$pkg" 2>&1 | tee -a "${pkg}.sim";
  done;
# INSTALACION MASIVA
  for pkg in git gcc make cmake automake; do
  sudo xbps-install -Sy "$pkg" 2>&1 | tee -a "${pkg}.log";
  done;
# LIMPIEZA TEXTO
  tr ' ' '\n' < a.txt | sed '/^$/d' | sort | tee b.txt;	# Normalizar lista paquetes
# TERMINUS FONT / CONSOLA
  sudo setfont ter-v16n;				# Probar fuente consola [ter-v16n]
  localectl list-console-fonts | grep Terminus;		# Listar fuentes Terminus
  sudo nano /etc/rc.conf;				# Configuración consola
# FONT=ter-v16n# Fuente típica [ter-v16n]
# FONT=ter-132n# Fuente grande
  sudo xbps-install -f kbd terminus-font;	# Reinstalar fuentes consola
  sudo xbps-reconfigure -fa;			# Reconfigurar todo sistema
  sudo dracut -f;				# Reconstruir initramfs
# FONTCONFIG / BITMAP FONTS
  fc-cache -rv;								# Reconstruir caché fuentes
  fc-list | grep -i terminus;						# Verificar Terminus
  ls /etc/fonts/conf.d | grep 70-no-bitmaps;				# Verificar reglas bitmap
  sudo unlink /etc/fonts/conf.d/70-no-bitmaps-except-emoji.conf;	# Habilitar bitmap fonts
# GRUB / TERMINUS
  find /boot/grub -iname "*.pf2";	# Buscar fuentes grub
  sudo nano /etc/default/grub;		# Configuración grub
# GRUB_FONT=/boot/grub/fonts/terminus20.pf2# Fuente típica
  sudo update-grub;				# Actualizar grub
  sudo grub-mkconfig -o /boot/grub/grub.cfg;	# Regenerar grub.cfg
# OS PROBER
# GRUB_DISABLE_OS_PROBER=false# Detectar otros SO
# TIMEZONE
  sudo rm -f /etc/localtime;								# Eliminar timezone actual
  sudo ln -sf /usr/share/zoneinfo/America/Argentina/Buenos_Aires /etc/localtime;	# Zona horaria
# NTPD RUNIT
  sudo sv down chronyd;				# Detener Chrony
  sudo rm /var/service/chronyd;			# Remover servicio
  sudo xbps-install -Sy ntp;			# Instalar NTP
  sudo ntpd -q;					# Sincronizar reloj
  sudo ln -s /etc/sv/ntpd /var/service/;	# Activar servicio
  sudo sv up ntpd;				# Iniciar servicio
  sv status ntpd;				# Estado servicio
# OPENBOX AUTOSTART
  mkdir -p ~/.config/openbox;			# Config Openbox
  nano ~/.config/openbox/autostart;		# Editar autostart
 'xrandr -s 1920x1080_60 &  # Resolución típica
  nitrogen --restore &
  pnmixer &
  nm-applet &
  tint2 &'
# LIGHTDM
  ln -s /etc/sv/lightdm /var/service;	# Activar LightDM
  cp /etc/lightdm/lightdm.conf ./;	# Backup config
# X11
  setxkbmap -layout es;		# Layout teclado [es]
  xrandr -s 1920x1080_60 &;	# Resolución monitor
# DIRECTORIOS BASE
  mkdir -p ./0DIR/{etc,home,usr,var};		# Estructura base, NO es POSIX sh, expansión Bash.
  mkdir -p ./0DIR/etc/skel/;
  mkdir -p ./0DIR/home/usuario/.conf/openbox/;
  mkdir -p ./0DIR/home/usuario/.doc/;
  mkdir -p ./0DIR/home/usuario/app/;
  mkdir -p ./0DIR/home/usuario/src/;
# MKLIVE
  sudo ./mklive.sh \
  -I 0DIR \
  -o ./gnuLinux.iso \
  -T "GNU-Linux" && sync;			# Generar ISO personalizada
# QEMU / QCOW2
  qemu-img create -f qcow2 disco.qcow2 40G;	# Crear disco virtual [40G]
  qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 2048 \
  -smp 2 \
  -cdrom FreeBSD.iso \
  -boot d;					# Boot ISO
# QEMU + DISCO
  qemu-system-x86_64 \
  -enable-kvm \
  -cpu host \
  -m 2048 \
  -smp 2 \
  -hda disco.qcow2 \
  -cdrom FreeBSD.iso \
  -boot d;
# QEMU + USB TABLET
  qemu-system-x86_64 \
  -enable-kvm \
  -usb \
  -device usb-tablet;	# Mejor mouse VM
# SSHD
  sysrc sshd_enable=YES;	# Habilitar SSH FreeBSD
  service sshd start;		# Iniciar SSH
# WINE LIMPIO
  wineserver -k;	# Detener Wine
  rm -rf \
  ~/.wine \
  ~/.wine_wot \
  ~/.cache/wine \
  ~/.config/wine;	# Limpiar Wine
# WINE PREFIX
  export WINEPREFIX=$HOME/.wine_wot;
  export WINEARCH=win64;
  winecfg;				# Crear prefix
# WINETRICKS
  winetricks -q \
  vcrun2005 \
  vcrun2008 \
  vcrun2010 \
  vcrun2012 \
  vcrun2013 \
  vcrun2015 \
  vcrun2019;					# Runtime VC++
  winetricks settings renderer=gl;		# OpenGL backend
  winetricks settings csmt=on;			# Command stream MT
  winetricks settings videomemorysize=512;	# VRAM [512]
# FFMPEG H264
  ffmpeg -i orig.mp4 \
  -vf "scale=1920:1080:force_original_aspect_ratio=decrease,\
  pad=1920:1080:(ow-iw)/2:(oh-ih)/2:color=black" \
  -c:v libx264 \
  -crf 20 \
  -preset veryfast \
  -c:a aac -b:a 128k \
  1920_1080p_h264.mp4 && sync;
# FFMPEG H265
  ffmpeg -i orig.mp4 \
  -c:v libx265 \
  -crf 20 \
  -preset veryfast \
  1920_1080p_h265.mp4 && sync;
# FFMPEG AV1
  ffmpeg -i orig.mp4 \
  -c:v libaom-av1 \
  -crf 30 \
  -b:v 0 \
  -cpu-used 4 \
  1920_1080p_av1.mkv && sync;
# FIREWALL IPV4/IPV6
  sudo iptables -F;					# Limpiar reglas IPv4
  sudo ip6tables -F;					# Limpiar reglas IPv6
  sudo iptables -P INPUT DROP;				# Política INPUT
  sudo iptables -P OUTPUT ACCEPT;			# Política OUTPUT
  sudo iptables -A INPUT -i lo -j ACCEPT;		# Loopback
  sudo iptables -A INPUT \
  -m conntrack \
  --ctstate ESTABLISHED,RELATED \
  -j ACCEPT;						# Conexiones establecidas
  sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT;	# SSH
  sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT;	# HTTP
  sudo iptables -A INPUT -p tcp --dport 443 -j ACCEPT;	# HTTPS
  sudo iptables-save > /etc/iptables/rules.v4;		# Guardar reglas IPv4
  sudo ip6tables-save > /etc/iptables/rules.v6;		# Guardar reglas IPv6
# SERVICIOS RUNIT
  sudo ln -s /etc/sv/ntpd /var/service/;
  sudo ln -s /etc/sv/fail2ban /var/service/;
  sudo ln -s /etc/sv/iptables /var/service/;
  sudo sv up ntpd;
  sudo sv up fail2ban;
  sudo sv up iptables;
# WORDLIST PDFCRACK
  for a in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
  for b in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
  for c in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
  echo "G${a}${b}${c}D";
  done;
  done;
  done > wordlist.txt;							# Generar wordlist
  pdfcrack \
  -f archivo.pdf \
  -w wordlist.txt;							# Ataque diccionario PDF
# PERMISOS MEDIOS EXTRAIBLES
  sudo chmod -R a+rwX /run/media/unusuario/HDD/;				# Permisos recursivos
  sudo chmod -R a+rwX /run/media/usuario/TD;
# repositorio local en HDD
# rsync-3.4.4_1           Remote fast incremental file transfer tool
xbps-install -Sy rsync
# rsync -hvrLt --progress --delete \
  --include="current/" \
  --include="current/multilib/" \
  --include="current/nonfree/" \
  --exclude="current/debug/" \
  --exclude="current/aarch64*" \
  --exclude="current/i686*" \
  --exclude="*" \
  rsync://alpha.de.voidlinux.org/voidlinux/ /run/media/unusuario/HDD/HDD/void-repo/
xbps-install -Sy rsync lftp
[-] lftp-4.9.2_3      Sophisticated FTP/HTTP client
https://mirror.puzzle.ch/voidlinux/ 	Europe 	Bern, Switzerland 	8.7 hours
lftp -c "open https://repo-default.voidlinux.org/voidlinux/; \
mirror --parallel=5 \
--exclude='\.i686\.xbps$' \
--exclude='\.i686\.xbps\.sig' \
--exclude='\.i686\.xbps\.sig2' \
--exclude='.*/debug/.*' \
--exclude='.*/aarch64.*/.*' \
--exclude='.*/armv.*/.*' \
current/ /run/media/unusuario/HDD/HDD/void-repo/current/"
Ó
wget --mirror --no-parent --no-host-directories \
  --reject-regex "/debug/|/aarch64|/i686|/arm" \
  -P /run/media/unusuario/HDD/HDD/void-repo/ \
  https://repo-default.voidlinux.org/voidlinux/current/
repository=/run/media/unusuario/HDD/HDD/void-repo/current
repository=/run/media/unusuario/HDD/HDD/void-repo/current/nonfree
repository=/run/media/unusuario/HDD/HDD/void-repo/current/multilib
#!/bin/sh
# =====================================================================
# CONFIGURACION
# =====================================================================
PAQUETES="stellarium libreoffice"
REPO_LOCAL="/run/media/unusuario/HDD/HDD/void-repo/current"
# Archivos de configuracion del sistema
CONF_FILE="/etc/xbps.d/10-local-repo.conf"
REMOTO_MUTED="/etc/xbps.d/00-repository-main.conf"
# Archivo de registro (Log)
LOG_FILE="/var/log/void_instalacion_local.log"
# =====================================================================
# FUNCIONES DE LOGGING
# =====================================================================
log_message() {
    # Imprime en pantalla y guarda en el archivo de log con marca de tiempo
    TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$TIMESTAMP] $1" >> "$LOG_FILE"
    echo "$1"
}
log_error() {
    # Imprime errores en pantalla (salida de error) y los registra
    TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")
    echo "[$TIMESTAMP] ERROR: $1" >> "$LOG_FILE"
    echo "ERROR: $1" >&2
}
# =====================================================================
# VALIDACIONES INICIALES
# =====================================================================
# 1. Validar permisos de root
if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: Este script debe ejecutarse como root o usando sudo." >&2
    exit 1
fi
# 2. Inicializar o limpiar el archivo de log anterior
: > "$LOG_FILE" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "ERROR: No se pudo escribir en $LOG_FILE. Verifique los permisos." >&2
    exit 1
fi
log_message "=================================================="
log_message "    Iniciando proceso de instalacion local        "
log_message "=================================================="
log_message "Paquetes solicitados: $PAQUETES"
log_message "Ruta del repositorio: $REPO_LOCAL"
# 3. Validar existencia del repositorio en el HDD
if [ ! -d "$REPO_LOCAL" ]; then
    log_error "No se encuentra el directorio del repositorio en $REPO_LOCAL"
    log_error "Asegurese de que el HDD este correctamente montado."
    exit 1
fi
# =====================================================================
# CONFIGURACION DE XBPS
# =====================================================================
log_message "Configurando XBPS para entorno local..."
# Crear archivo de repositorio local
cat << EOF > "$CONF_FILE" 2>> "$LOG_FILE"
repository=$REPO_LOCAL
repository=$REPO_LOCAL/nonfree
repository=$REPO_LOCAL/multilib
EOF
if [ $? -ne 0 ]; then
    log_error "No se pudo escribir el archivo de configuracion en $CONF_FILE"
    exit 1
fi
# Desactivar temporalmente los repositorios remotos de internet
touch "$REMOTO_MUTED" 2>> "$LOG_FILE"
# Sincronizar indices de paquetes
log_message "Sincronizando indices de paquetes desde el disco..."
xbps-query -S >> "$LOG_FILE" 2>&1
if [ $? -ne 0 ]; then
    log_error "Fallo la sincronizacion de indices de XBPS. Revise el log."
    rm -f "$REMOTO_MUTED"
    exit 1
fi
# =====================================================================
# EJECUCION DE LA INSTALACION
# =====================================================================
log_message "Ejecutando xbps-install..."
log_message "Por favor, espere mientras se copian los archivos..."
# Se ejecuta la instalacion guardando los detalles y errores en el log
xbps-install -y $PAQUETES >> "$LOG_FILE" 2>&1
STATUS=$?
# =====================================================================
# LIMPIEZA Y RESULTADO
# =====================================================================
# Restaurar repositorios remotos por defecto inmediatamente
rm -f "$REMOTO_MUTED"
log_message "--------------------------------------------------"
if [ $STATUS -eq 0 ]; then
    log_message "Proceso finalizado exitosamente."
    log_message "Los programas se instalaron correctamente."
else
    log_error "La instalacion de paquetes devolvio el codigo de salida: $STATUS"
    log_error "Revise el archivo de registro completo en: $LOG_FILE"
fi
log_message "=================================================="
# cd /mnt/repo_local
# python3 -m http.server 8080
Configurar los equipos clientes para usar el repositorio local
Creá un directorio para repositorios personalizados (si no existe):
Bash
# mkdir -p /etc/xbps.d
Creá un archivo de configuración, por ejemplo, 10-local-repo.conf:
Bash
# nano /etc/xbps.d/10-local-repo.conf
Añadí las rutas según el método que elegiste en el Paso 3:
Si conectaste el HDD directo a la PC (Ruta local):
Plaintext
repository=/mnt/repo_local/current
repository=/mnt/repo_local/current/nonfree
repository=/mnt/repo_local/current/multilib
Si lo compartiste por red (HTTP):
Plaintext
repository=http://IP_DE_TU_SERVIDOR:8080/current
repository=http://IP_DE_TU_SERVIDOR:8080/current/nonfree
repository=http://IP_DE_TU_SERVIDOR:8080/current/multilib
Opcional: Si querés que solo use tu disco y no intente salir a internet a buscar los mirrors oficiales, eliminá o renombrá el archivo de repositorios por defecto que está en /usr/share/xbps.d/.
# SERVIDORES DE CORREO
  'AÑO	EDAD	NOMBRE		COSTE	TIPO	ESTADO	NOTAS					URL'
  '1983	43	Sendmail	mix	mix	on	MTA histórico complejo pero potente	https://www.proofpoint.com/us/sendmail-open-source'
  '1995	31	Exim		gratis	gnu	on	MTA flexible Unix/Linux			https://www.exim.org'
  '1996	30	Outlook.com	mix	pri	on	Microsoft, evolución de Hotmail		https://www.outlook.live.com'
  '1998	28	Postfix		gratis	gnu	on	MTA muy usado en Linux			https://www.postfix.org'
  '2002	24	Dovecot		gratis	gnu	on	IMAP/POP3 estable y eficiente		https://www.dovecot.org'
  '2004	22	Gmail		mix	pri	on	Google, ecosistema integrado		https://www.mail.google.com'
  '2005	21	Zimbra		mix	mix	on	Suite corporativa de correo		https://www.zimbra.com'
  '2007	19	iRedMail	mix	mix	on	Instalador completo servidor de correo	https://www.iredmail.org'
  '2011	15	Haraka		gratis	gnu	on	MTA rápido basado en Node.js		https://www.haraka.github.io'
  '2013	13	OpenSMTPD	gratis	gnu	on	MTA simple de OpenBSD			https://www.opensmtpd.org'
  '2015	11	Poste.io	mix	mix	on	Mail server tipo appliance		https://www.poste.io'
  '2017	09	Mailcow		mix	mix	on	Stack moderno basado en Docker		https://www.mailcow.email'
  '2017	09	Mailu		mix	mix	on	Suite ligera en contenedores		https://www.mailu.io'
  '2020	06	Proton Mail	mix	mix	on	cifrado end-to-end, enfoque privacidad	https://www.proton.me/mail'
# ALMACENAMIENTO EN LA NUBE
  'AÑO	EDAD	NOMBRE		COSTE	TIPO	ESTADO	RECURSO	NOTAS	URL'
  '2005	21	Archive.org	mix	gnu	on	AIV	Archivo digital público histórico	https://www.archive.org'
  '2006	20	Amazon S3	mix	priv	on	AIV	objeto altamente escalable		https://www.aws.amazon.com/s3'
  '2007	19	OneDrive	mix	priv	on	AIV	Integración Windows/Office		https://www.onedrive.live.com'
  '2008	18	Google Drive	mix	priv	on	AIV	Integración ecosistema Google		https://www.drive.google.com'
  '2008	18	ownCloud	gratis	gnu	on	AIV	Self-hosted tipo enterprise/DIY		https://www.owncloud.com'
  '2010	16	iCloud		mix	priv	on	AIV	Ecosistema Apple			https://www.icloud.com'
  '2011	15	Box		mix	priv	on	AIV	Orientado a empresas y colaboración	https://www.box.com'
  '2012	14	Dropbox		mix	priv	on	AIV	Sincronización simple de archivos	https://www.dropbox.com'
  '2013	13	MEGA		mix	priv	on	AIV	Cifrado cliente, enfoque privacidad	https://www.mega.io'
  '2014	12	pCloud		mix	priv	on	AIV	Almacenamiento con opción lifetime	https://www.www.pcloud.com'
  '2015	11	Nextcloud	gratis	gnu	on	AIV	Self-hosted, control total de datos	https://nextcloud.com'
  '2016	10	SugarSync	mix	priv	off	AIV	Backup y sincronización de archivos	https://www.sugarsync.com'
  '2017	09	Google Photos	mix	priv	on	IV	Gestión y backup de imágenes y video	https://www.photos.google.com'
  '2018	08	YouTube Storage	mix	priv	on	V	Video streaming y almacenamiento masivo	https://www.youtube.com'
  '2018	08	Amazon Drive	mix	priv	off	AIV	Almacenamiento personal de Amazon	https://www.amazon.com/clouddrive'
  '2019	07	Sync.com	mix	priv	on	AIV	Enfoque en privacidad y cifrado		https://www.sync.com'
  '2020	06	Dropbox Paper	mix	priv	on	AIV	Documentos colaborativos en la nube	https://www.dropbox.com/paper'
  '2020	06	Google One	mix	priv	on	AIV	Almacenamiento expandido Google Drive	https://www.one.google.com'
  '2021	05	Koofr		mix	priv	on	AIV	Almacenamiento y backup europeo		https://www.koofr.eu'
  '2022	04	Icedrive	mix	priv	on	AIV	Almacenamiento con cifrado nativo	https://www.icedrive.net'
# ------------------------------------------------------------------------------------------------------------------------------------------------- REGLAS
DADO 'Tratado de construcción para scripts POSIX "***.sh" establece que todo programa debe seguir una arquitectura estrictamente estructurada: inicia la cabecera de archivo "#!/bin/sh", luego con un bloque de notas descriptivas, seguido de la inicialización de variables donde se separan claramente entradas, salidas y entorno, y continuando con un conjunto de funciones modulares organizadas bajo el paradigma CRUD "Create, Read, Update, Delete", donde cada función debe tener una única responsabilidad, un nombre explícito, y un comentario compacto en la misma línea que describa su propósito, la funcion debe terminar en forma compacta ultimo comando ejecutable mas espacio mas punto y como mas cierre de corchete; además, se permite la compactación de funciones en una sola línea siempre que no se comprometa la legibilidad. El flujo del script debe ser lineal y controlado mediante una función "main" que orquesta únicamente llamadas a funciones sin contener lógica compleja, seguido de una fase de finalización responsable de sincronización de recursos y liberación de estados del sistema. Se establece como norma que todos los archivos generados deben estar ordenados, normalizados y libres de duplicados mediante herramientas como "sort -u", garantizando consistencia de salida. La política de entradas es obligatoria y universal: cualquier recurso "archivos, rutas, directorios, URLs o parámetros" debe solicitarse al usuario, y si este no ingresa ningún valor "Enter vacío", se debe utilizar automáticamente el directorio y/ó recurzos donde se ejecuta el script; en ambos casos la entrada debe ser validada mediante una función interna centralizada antes de su uso, evitando el acceso directo a valores/recursos no verificados. Asimismo, se exige el principio de mínima línea funcional, donde se busca reducir el número de renglones sin sacrificar claridad, promoviendo compactación controlada, uso de pipelines eficientes y eliminación de redundancias. El sistema debe mantener portabilidad POSIX estricta y nativa, informar al usuario en todo momento de las operacion que se llevan a cabo por mensaje de consola "printf", evitar dependencias y estados intermedios, toda variable utilizada debe crearce, inicializarce, boorrarse y eliminarse; aplicar validaciones de seguridad en archivos y entradas, y garantizar trazabilidad mediante comentarios compactos y consistentes, asegurando que cada script sea modular, mantenible, determinista y seguro en su ejecución.', ENCONCES 'Calcula todos los hashes disponibles', CREA UN SCRIPT.
# ------------------------------------------------------------------------------------------------------------------------------------------------- REGLAS
# ------------------------------------------------------------------------------------------------------------------------------------------------- SCRIPT
#!/bin/sh
# -----------------------------------------------------------------------------
# Script POSIX SH
# - Calcula hashes disponibles
# - Soporta archivo/directorio
# - Enter vacío = directorio actual
# - Omite archivos checksum/hash existentes
# - Muestra hashes en tiempo real
# - Salida TSV: tipo_hash<TAB>hash<TAB>timestamp<TAB>archivo
# -----------------------------------------------------------------------------
# ---------------------------[ VARIABLES ]-------------------------------------
script_dir=$(pwd); hash_file="${script_dir}/hashes.txt";
input_target=""; input_files=""; hash_cmds="";
# Extensiones checksum/hash ignoradas
exclude_ext="txt|md5|sha1|sha224|sha256|sha384|sha512|b2|cksum|hash";
# -------------------------[ VALIDACIONES ]------------------------------------
validar_entrada() { [ -e "$1" ]; }		  # Validar entrada
validar_salida() { : > "$1" 2>/dev/null; } # Validar salida
# ----------------------------[ CREATE ]---------------------------------------
crear_archivo() { : > "$1"; } # Inicializar archivo
# -----------------------------[ READ ]----------------------------------------
leer_input() { # Solicitar recurso
	printf "Ingrese archivo/directorio [Enter=%s]: " "$script_dir"
	read input_target
	[ -z "$input_target" ] && input_target="$script_dir"
}
resolver_archivos() { # Resolver archivos válidos
	if [ -f "$input_target" ]; then
		case "$input_target" in
			*.txt|*.md5|*.sha1|*.sha224|*.sha256|*.sha384|*.sha512|*.b2|*.cksum|*.hash)
				printf "[ERROR] Archivo checksum omitido\n"
				return 1
			;;
		esac
		input_files="$input_target"
	elif [ -d "$input_target" ]; then
		input_files=$(find "$input_target" -type f \
		! -regex ".*\.\(${exclude_ext}\)$" \
		! -iname "*checksum*" \
		! -iname "*.sfv")
	else
		return 1
	fi
	[ -n "$input_files" ]
}
leer_hashes() { # Detectar hashes disponibles
	hash_cmds=$(command -v \
	md5sum sha1sum sha224sum sha256sum sha384sum sha512sum \
	b2sum cksum 2>/dev/null | sort -u)
}
# ----------------------------[ UPDATE ]---------------------------------------
calcular_hash() { # Calcular hashes
	file="$1"
	timestamp=$(date +%s)
	for cmd in $hash_cmds; do
		tipo=$(basename "$cmd")
		numero=$("$cmd" "$file" 2>/dev/null | awk '{print $1}')
		[ -n "$numero" ] || continue
		printf "%s\t%s\t%s\t%s\n" \
		"$tipo" "$numero" "$timestamp" "$file" \
		| tee -a "$hash_file"
	done
}
procesar_archivos() { # Procesar archivos
	crear_archivo "$hash_file"
	for f in $input_files; do
		printf "[+] Procesando -> %s\n" "$f"
		calcular_hash "$f"
	done
	sort -u -o "$hash_file" "$hash_file"
}
# ----------------------------[ DELETE ]---------------------------------------
limpiar() { # Limpiar variables
	unset file cmd tipo numero timestamp
	unset input_target input_files hash_cmds
	unset exclude_ext
}
# -------------------------[ FINALIZACIÓN ]------------------------------------
finalizar() { # Finalizar sistema
	sync
	limpiar
	printf "[OK] Resultado -> %s\n" "$hash_file"
}
# -------------------------------[ MAIN ]--------------------------------------
main() {
	clear
	leer_input
	validar_entrada "$input_target" || {
		printf "[ERROR] Entrada inválida\n"
		exit 1
	}
	resolver_archivos || {
		printf "[ERROR] Sin archivos procesables\n"
		exit 1
	}
	validar_salida "$hash_file" || {
		printf "[ERROR] No se puede escribir salida\n"
		exit 1
	}
	leer_hashes
	procesar_archivos
}
main
finalizar
exit 0
# ------------------------------------------------------------------------------------------------------------------------------------------------- SCRIPT
#!/bin/sh
# NOTAS / DESCRIPCIÓN
# Script POSIX SH:
# - Calcula todos los hashes (md5, sha1, sha256, sha512) de archivos seleccionados
# - Arquitectura modular tipo CRUD
# - Entrada de usuario validada
# - Archivos de salida ordenados y deduplicados
# - Compacto y lineal según tratado
# VARIABLES / INICIALIZACIÓN
hash_nbr="hashes"; hash_ext="txt"; hash_file=""  # Archivo salida hash
script_dir=$(dirname "$0")                       # Directorio donde se ejecuta el script
input_files=""                                   # Archivos seleccionados por usuario
# FUNCIONES CRUD
crear_archivo() { file="$1"; : > "$file"; }                                       # CREATE - inicializa archivo
leer_input_usuario() {                                                            # READ - pide archivos
  printf "Ingrese archivos (espacio separado) [Enter = actual dir]: "
  read user_input
  if [ -z "$user_input" ]; then
    input_files=$(find "$script_dir" -type f)
  else
    input_files="$user_input"
  fi
}
validar_archivo() {                                                                # READ - valida existencia
  for f in $1; do
    [ ! -f "$f" ] && echo "ERROR: archivo no existe -> $f" && return 1
  done
  return 0
}
calcular_hash() {                                                                  # UPDATE - calcula hashes de un archivo
  file="$1"
  md5=$(md5sum "$file" 2>/dev/null | awk '{print $1}')
  sha1=$(sha1sum "$file" 2>/dev/null | awk '{print $1}')
  sha256=$(sha256sum "$file" 2>/dev/null | awk '{print $1}')
  sha512=$(sha512sum "$file" 2>/dev/null | awk '{print $1}')
  printf "%s\t%s\t%s\t%s\t%s\n" "$file" "$md5" "$sha1" "$sha256" "$sha512"
}
procesar_archivos() { crear_archivo "$hash_file"; for f in $input_files; do calcular_hash "$f" >> "$hash_file"; done; sort -u -o "$hash_file" "$hash_file"; }  # CREATE/UPDATE - procesa todos los archivos
init_env() { clear; umask 022; }                                                   # INICIALIZACIÓN DE ENTORNO
finalizar() { sync; echo "OK -> Hashes generados en: $hash_file"; }                # FINALIZACIÓN
# MAIN
main() {
  init_env
  leer_input_usuario
  [ -z "$input_files" ] && echo "No se seleccionaron archivos." && exit 1
  validar_archivo "$input_files" || exit 1
  hash_file="${script_dir}/${hash_nbr}.${hash_ext}"
  procesar_archivos
}
# EJECUCIÓN CONTROLADA
main
finalizar
exit 0
# ------------------------------------------------------------------------------------------------------------------------------------------------- SCRIPT
reNbrArch() {	# renombrar archivo/directorio
	rta="$1";					# ruta actual
	bse=$(basename "$rta");				# nombre base
	dir=$(dirname "$rta");				# directorio contenedor
	# Separar: [prefijo protegido = primeros 2 puntos] [resto modificable]
	pfx=$(printf "%s" "$bse" | cut -d '.' -f 1-2);	# conservar hasta el segundo punto
	rst=$(printf "%s" "$bse" | cut -d '.' -f 3-);	# resto modificable
	# Si no existen 2 puntos no modificar prefijo
	if [ "$pfx" = "$bse" ]; then			# sin suficientes puntos
		pfx="";					# sin prefijo protegido
		rst="$bse";				# usar nombre completo
	else
		pfx="${pfx}.";				# restaurar punto final
	fi;
	case "$rst" in					# Obtener extension final
		*.*)
			nom="${rst%.*}";		# nombre sin extension
			ext=".${rst##*.}";		# extension final
		;;
		*)
			nom="$rst";			# nombre completo
			ext="";				# sin extension
		;;
	esac;
	nom=$(printf "%s" "$nom" | tr -d 'aeiouAEIOU');			# remover vocales
	nom=$(printf "%s" "$nom" | sed 's/_-_/-/g');			# reemplazar "_-_" por "-"
	nom=$(printf "%s" "$nom" | sed 's/__/__/g; :a; s/__/_/g; ta');	# convertir "__" en "_"
	nom=$(printf "%s" "$nom" | sed 's/\._/./g');			# reemplazar "._" por "."
	nvo="${pfx}${nom}${ext}";			# reconstruir nombre final
	if [ "$bse" != "$nvo" ]; then			# si hubo cambios
		org="$rta";				# ruta original
		dst="$dir/$nvo";			# ruta destino
		mv -- "$org" "$dst";			# renombrar archivo/directorio
		rgstr "Org" "$org";			# registrar origen
		rgstr "Dst" "$dst";			# registrar destino
		rgstr "" "";				# registrar linea vacia
		impr_tit "Renombrado";			# titulo
		impr_inf "Org: $org";			# mostrar origen
		impr_inf "Dst: $dst";			# mostrar destino
	fi; }
reNbr() {	# recorer directorios
	find . -depth | while IFS= read -r itm; do
		reNbrArch "$itm";			# Procesar elemento encontrado
		sync;
	done; }
# FIN