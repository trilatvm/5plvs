#!/bin/sh
# 100% POSIX nativo no bash
# Diseñado estrictamente para RUTAS ABSOLUTAS
# Compatible con Debian 13, Void 2026 y FreeBSD 15.
set -e
ROJ='\033[0;31m'; VER='\033[0;32m'; AMA='\033[0;33m'; CIA='\033[0;36m'; MAG='\033[95m'; RST='\033[0m';
rtaOrg="" ; rtaDst="" ; arch="" ; archNbr="" ; entrada="" ;
getTs(){ date +"%Y-%m-%d %H:%M:%S"; }
getTsE(){ date +"%s"; }
locSH() { (cd "$(dirname "$0")" && pwd); }	# Obtener directorio donde RESIDE el script
# ------------------------------------------ #
msj(){ printf "${MAG}[%s]\t%b\n" "$(getTs)" "${*}"; }
msjErr() { msj "${ROJ}[ERR] ${*}${RST}"; }
msjAdv() { msj "${AMA}[ADV] ${*}${RST}"; }
msjInf() { msj "${VER}[INF] ${*}${RST}"; }
msjPgt() { printf "[%s]\t${CIA}[PGT] %b${RST} " "$(getTs)" "${*}"; }
# ------------------------------------------ #
chkSalir() {
	case "$1" in
		[qQ]) msjAdv "Saliendo del script por solicitud del usuario..." ; exit 0 ;;
	esac; }
vrfStx() {
	case "$1" in
		/*) return 0 ;;
		*)  msjErr "La ruta debe ser absoluta (empezar con '/')." ; return 1 ;;
	esac; }
vrfEx() {
	[ -d "$1" ] && return 0
	msjErr "La ruta no existe o no es un directorio válido." ; return 1; }
vrfLct() {
	[ -r "$1" ] && return 0
	msjErr "Privilegios insuficientes. No se puede LEER la ruta." ; return 1; }
vrfEct() {
	[ -w "$1" ] && return 0
	msjErr "Privilegios insuficientes. No se puede ESCRIBIR en la ruta." ; return 1; }
vldr(){ chkSalir "$1"; vrfStx "$1" && vrfEx "$1" && vrfLct "$1"; }
vldrPlvs(){ vldr "$1" && vrfEct "$1"; }
# ------------------------------------------ #
ingOrg(){
	while :; do
		msjPgt "ORIGEN [${entrada}] || 'q' [Salir]:"
		read -r entrada
		msjAdv "$entrada"
		vldr "$entrada" || continue
		rtaOrg="$entrada"
		case "$rtaOrg" in */) ;; *) rtaOrg="$rtaOrg/" ;; esac
		archNbr=$(echo "$rtaOrg" | sed 's#/*$##;s#.*/##')
		msjInf "Origen validado correctamente. Identificador: archNbr=\"$archNbr\""
		break
	done; }
ingDst(){
	while :; do
		entrada="$(locSH)"
		msjPgt "DESTINO [${entrada}] || 'q' [Salir]:"
		read -r entrada
#		[ -z "$entrada" ] && entrada="$(locSH)"
		if [ -z "$entrada" ] ; then
			entrada="$(locSH)"
		fi
		msjAdv "$entrada"
		vldrPlvs "$entrada" || continue
		rtaDst="$entrada"
		case "$rtaDst" in */) ;; *) rtaDst="$rtaDst/" ;; esac
		msjInf "Destino validado correctamente."
		break
	done; }
# ------------------------------------------ #
cmpZip(){
	arch="${archNbr}_$(getTsE).zip"
	msjInf "Comprimiendo contenido desde la ruta absoluta..."
	zip -rv9T "${rtaDst}${arch}" ${rtaOrg}*; }
# ------------------------------------------ #
par2Cr(){
	msjInf "Creando archivos PAR2 locales en el destino..."
	(cd "$rtaDst" && par2 c -r20 -m512 -s1048576 -t4 "$arch"); }
par2Vr(){
	msjInf "Verificando archivos PAR2..."
	(cd "$rtaDst" && par2 v -t4 "$arch"); }
# ------------------------------------------ #
hashCr(){
	msjInf "Generando hashes en el directorio destino..."
	if command -v sha256sum >/dev/null 2>&1; then
#		(cd "$rtaDst" && sha256sum "$arch" > "${arch}.sha256")
		(cd "$rtaDst" && md5sum "$arch" > "${arch}.md5")
	else
#		(cd "$rtaDst" && sha256 -r "$arch" > "${arch}.sha256")
		(cd "$rtaDst" && md5 -r "$arch" > "${arch}.md5")
	fi; }
hashVr(){
	msjInf "Verificando consistencia de las firmas generadas..."
	if command -v sha256sum >/dev/null 2>&1; then
#		(cd "$rtaDst" && sha256sum -c "${arch}.sha256")
		(cd "$rtaDst" && md5sum -c "${arch}.md5")
	else
#		(cd "$rtaDst" && sha256 -c "${arch}.sha256")
		(cd "$rtaDst" && md5 -c "${arch}.md5")
	fi; }
bff(){ sync; }
# ------------------------------------------ #
inicVr(){ rtaOrg=""; rtaDst=""; }
main(){
	bff
	msj "---- SCRIPT INICIO ---"
	while true ; do
		msjInf "-------"
		inicVr
		ingOrg	
		ingDst
		bff	
		cmpZip
		bff
		par2Cr	
		bff
		par2Vr	
		hashCr	
		hashVr	
		bff
	done
	msj "---- SCRIPT FIN    ---"
}
main
exit 0