#!/sh
set -e
ROJ="\033[0;91m"; NAR="\033[0;33m"; AMA="\033[0;93m"; VER="\033[0;92m"; CIA="\033[0;96m"; MAG="\033[0;95m"; RST="\033[0m";
EXT="" ;
INCmd5=0 ; CORmd5=0 ; GENmd5=0 ;
INCpar2=0 ; CORpar2=0 ; GENpar2=0 ;
log_info() {
	_timestamp=$(date "+%Y%m%d%H%M%S")
#	printf "[%s]\t%b%s%b\n" "$_timestamp" "$1" "$2" "$RST"
	printf "%b[%s] %b%s%b\n" "$NAR" "$_timestamp" "$1" "$2" "$RST"
}
dibujar_progreso() {
	_actual=$1
	_total=$2
	_archivo=$3
	_perc=$(( (_actual * 100) / _total ))
	_bar_size=40
	_filled=$(( (_perc * _bar_size) / 100 ))
	_empty=$(( _bar_size - _filled ))
	
	_bar=""
	_i=0; while [ $_i -lt $_filled ]; do _bar="${_bar}#"; _i=$((_i+1)); done
	_i=0; while [ $_i -lt $_empty ]; do _bar="${_bar}-"; _i=$((_i+1)); done
	
	printf "%b[%s] %d%% (%d/%d)\n\t\t Archivo: %.20s%b\n" "$NAR" "$_bar" "$_perc" "$_actual" "$_total" "$_archivo" "$RST"
}
verificar_herramientas() {
	if ! command -v par2 >/dev/null 2>&1; then
		log_info "$ROJ" "Error: par2 no instalado."
		exit 1
	fi
}
contar_archivos() {
	_ext=$1
	_count=0
	if [ -z "$_ext" ]; then
		for _f in *; do if [ -f "$_f" ]; then _count=$((_count + 1)); fi; done
	else
		for _f in *."$_ext"; do if [ -f "$_f" ]; then _count=$((_count + 1)); fi; done
	fi
	echo "$_count"
}
procesar_md5() {
	_file=$1
	if [ -f "$_file.md5" ]; then
		log_info "$CIA" "Verificando MD5..."
		if command -v md5sum >/dev/null 2>&1; then
			set +e
			md5sum -c "$_file.md5" >/dev/null 2>&1
			_status=$?
			set -e
			if [ $_status -eq 0 ]; then
				log_info "$VER" "[OK] MD5 correcto: $_file"
				CORmd5=$(($CORmd5 + 1))
			else
				log_info "$ROJ" "[INCORRECTO] MD5 fallo: $_file"
				INCmd5=$(($INCmd5 + 1))
			fi
		fi
	else
		log_info "$AMA" "Calculando MD5..."
		if command -v md5sum >/dev/null 2>&1; then
			md5sum "$_file" > "$_file.md5" 2>/dev/null
		else
			openssl dgst -md5 "$_file" > "$_file.md5" 2>/dev/null
		fi
		log_info "$VER" "[CREADO] $_file.md5"
		GENmd5=$(($GENmd5 + 1))
	fi
}
procesar_par2() {
	_file=$1
	if [ -f "$_file.par2" ]; then
		log_info "$CIA" "Verificando PAR2..."
		set +e
#		par2 verify -q "$_file.par2" >/dev/null 2>&1
		par2 verify "$_file.par2" 2>&1
#		printf "\n%s" ""
		_par2_status=$?
		set -e
		
		if [ $_par2_status -eq 0 ]; then
			log_info "$VER" "[OK] PAR2 correcto: $_file"
			CORpar2=$(($CORpar2 + 1))
		else
			log_info "$ROJ" "[INCORRECTO] PAR2 fallo: $_file"
			INCpar2=$(($INCpar2 + 1))
#			printf "Reparar archivo? (s/n): "
			log_info "$MAG" "Reparar archivo? (s/n): "
			read -r CONFIRM
			if [ "$CONFIRM" = "s" ] || [ "$CONFIRM" = "S" ]; then
				log_info "$AMA" "Reparando con PAR2..."
				set +e
#				par2 repair -q "$_file.par2" >/dev/null 2>&1
				par2 repair -q "$_file.par2" 2>&1
#				printf "\n%s" ""
				_repair_status=$?
				set -e
				if [ $_repair_status -eq 0 ]; then
					log_info "$VER" "[REPARADO] $_file"
				else
					log_info "$ROJ" "[ERROR] No se pudo reparar: $_file"
				fi
			fi
		fi
	else
		log_info "$AMA" "\tCreando PAR2 (20%)..."
#		par2 create -r20 -m512 -q "$_file" >/dev/null 2>&1
		par2 create -r20 -m512 "$_file" 2>&1
#		par2 create -r20 -m1024 -q "$_file" >/dev/null 2>&1
#		par2 c -r20 -m512 -s1048576 -t4 -q "$_file" >/dev/null 2>&1
#		par2 c -r20 -m512 -s1024 -t4 -q "$_file" >/dev/null 2>&1
		printf "\n%s" ""
		log_info "$VER" "[CREADO] PAR2 completado."
		GENpar2=$(($GENpar2 + 1))
	fi
}
verificar_herramientas
if [ -n "$1" ]; then
	CURRENT_DIR="$1"
else
	CURRENT_DIR=$(dirname "$0")
	CURRENT_DIR=$(cd "$CURRENT_DIR" && pwd)
fi
if [ ! -d "$CURRENT_DIR" ]; then
	log_info "$ROJ" "Error: Ruta invalida."
	exit 1
fi
while true; do
	cd "$CURRENT_DIR" || exit 1
	clear
	log_info "$VER" "Directorio: $CURRENT_DIR"
	printf "Extension ([ENTER]=todos, [q]=salir): "
	read -r EXT
	if [ "$EXT" = "q" ] || [ "$EXT" = "Q" ]; then
		break
	fi
	TOTAL_FILES=$(contar_archivos "$EXT")
	if [ "$TOTAL_FILES" -eq 0 ]; then
		log_info "$AMA" "No hay archivos."
	else
		_current=0
		for file in *; do
			sync
			if [ -n "$EXT" ]; then
				case "$file" in *."$EXT") ;; *) continue ;; esac
			fi
			if [ ! -f "$file" ] || [ "${file##*.}" = "md5" ] || [ "${file##*.}" = "par2" ]; then
				continue
			fi
			_current=$((_current + 1))
			echo ""
			dibujar_progreso "$_current" "$TOTAL_FILES" "$file"
			procesar_md5 "$file"
			procesar_par2 "$file"
		done
		log_info "$VER" "Lote terminado."
		printf "%b\t\t\t\t%s\t%s%b\n" "$CIA" "MD5" "PAR2"
		printf "%b\t\tINCORRECTO\t%s\t%s%b\n" "$ROJ" "$INCmd5" "$INCpar2"
		printf "%b\t\t  GENERADO\t%s\t%s%b\n" "$AMA" "$GENmd5" "$GENpar2"
		printf "%b\t\t  CORRECTO\t%s\t%s%b\n" "$VER" "$CORmd5" "$CORpar2"
	fi
	echo ""
	printf "Presione [ENTER] para continuar..."
	read -r _
done
exit 0