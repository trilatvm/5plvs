document.addEventListener('DOMContentLoaded', () => {
  // 1. Alternar Modo Noche / Día
  const btnTema = document.getElementById('btn-tema');
  btnTema.addEventListener('click', () => {
    document.body.classList.toggle('light-mode');
    btnTema.textContent = document.body.classList.contains('light-mode') ? '🌙' : '☀️';
  });

  // 2. Interacción de pulsación larga (Long Press) en los datos calculados
  const modal = document.getElementById('modal-calculos');
  const modalTitulo = document.getElementById('modal-titulo');
  const modalContenido = document.getElementById('modal-contenido');
  const itemsDatos = document.querySelectorAll('.dato-item');

  let timerPresion;
  const TIEMPO_PULSACION = 450; // milisegundos

  // Estructura preparada para recibir la lógica de negocio
  window.detalleCalculos = {
    media: { titulo: 'Media (μ)', texto: 'Esperando datos ingresados...' },
    mediana: { titulo: 'Mediana', texto: 'Esperando datos ingresados...' },
    n: { titulo: 'Muestra (n)', texto: 'Esperando datos ingresados...' },
    desviacion: { titulo: 'Desviación Estándar (σ)', texto: 'Esperando datos ingresados...' },
    varianza: { titulo: 'Varianza (σ²)', texto: 'Esperando datos ingresados...' },
    error: { titulo: 'Error Estándar (SE)', texto: 'Esperando datos ingresados...' }
  };

  function abrirModal(metrica) {
    const info = window.detalleCalculos[metrica];
    modalTitulo.textContent = info.titulo;
    modalContenido.innerHTML = info.texto;
    modal.classList.add('activo');
  }

  itemsDatos.forEach(item => {
    const metrica = item.getAttribute('data-metrica');

    const iniciarPresion = () => {
      timerPresion = setTimeout(() => {
        abrirModal(metrica);
      }, TIEMPO_PULSACION);
    };

    const cancelarPresion = () => {
      clearTimeout(timerPresion);
    };

    // Eventos Mouse
    item.addEventListener('mousedown', iniciarPresion);
    item.addEventListener('mouseup', cancelarPresion);
    item.addEventListener('mouseleave', cancelarPresion);

    // Eventos Táctiles (Móvil / Tablet)
    item.addEventListener('touchstart', iniciarPresion, { passive: true });
    item.addEventListener('touchend', cancelarPresion);
    item.addEventListener('touchcancel', cancelarPresion);
  });

  // Cerrar modal con un toque en cualquier parte
  modal.addEventListener('click', () => {
    modal.classList.remove('activo');
  });
});
