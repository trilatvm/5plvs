

document.addEventListener('DOMContentLoaded', () => { // Referencias al DOM const btnTema = document.getElementById('btn-tema'); const btnMas = document.getElementById('btn-mas'); const btnMenos = document.getElementById('btn-menos'); const inputValor = document.getElementById('input-valor'); const elMedia = document.getElementById('val-media'); const elMediana = document.getElementById('val-mediana'); const elN = document.getElementById('val-n'); const elDesviacion = document.getElementById('val-desviacion'); const elVarianza = document.getElementById('val-varianza'); const elError = document.getElementById('val-error'); const canvas = document.getElementById('graficoNormal'); const ctx = canvas.getContext('2d'); const modal = document.getElementById('modal-calculos'); const modalTitulo = document.getElementById('modal-titulo'); const modalContenido = document.getElementById('modal-contenido'); const itemsDatos = document.querySelectorAll('.dato-item'); // Estado de la aplicación let datos = []; // Detalle de cálculos para el modal transparente window.detalleCalculos = { media: { titulo: 'Media (μ)', texto: 'Sin datos ingresados aún.' }, mediana: { titulo: 'Mediana', texto: 'Sin datos ingresados aún.' }, n: { titulo: 'Muestra (n)', texto: 'Sin datos ingresados aún.' }, desviacion: { titulo: 'Desviación Estándar (σ)', texto: 'Sin datos ingresados aún.' }, varianza: { titulo: 'Varianza (σ²)', texto: 'Sin datos ingresados aún.' }, error: { titulo: 'Error Estándar (SE)', texto: 'Sin datos ingresados aún.' } }; // ================= 1. TEMA DÍA / NOCHE ================= btnTema.addEventListener('click', () => { document.body.classList.toggle('light-mode'); btnTema.textContent = document.body.classList.contains('light-mode') ? '🌙' : '☀️'; dibujarGrafico(); }); // ================= 2. AGREGAR Y QUITAR DATOS ================= function agregarDato() { const valor = parseFloat(inputValor.value); if (isNaN(valor)) { inputValor.focus(); return; } datos.push(valor); inputValor.value = ''; inputValor.focus(); actualizarTodo(); } function quitarDato() { if (datos.length === 0) return; const valorEscrito = parseFloat(inputValor.value); if (!isNaN(valorEscrito)) { const indice = datos.lastIndexOf(valorEscrito); if (indice !== -1) { datos.splice(indice, 1); } else { datos.pop(); } inputValor.value = ''; } else { datos.pop(); } inputValor.focus(); actualizarTodo(); } btnMas.addEventListener('click', agregarDato); btnMenos.addEventListener('click', quitarDato); inputValor.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); agregarDato(); } }); // ================= 3. CÁLCULOS ESTADÍSTICOS ================= function calcularEstadisticas() { const n = datos.length; if (n === 0) { elMedia.textContent = '0.00'; elMediana.textContent = '0.00'; elN.textContent = '0'; elDesviacion.textContent = '0.00'; elVarianza.textContent = '0.00'; elError.textContent = '0.00'; Object.keys(window.detalleCalculos).forEach(k => { window.detalleCalculos[k].texto = 'Sin datos ingresados aún.'; }); return null; } // Media (μ) const suma = datos.reduce((acc, v) => acc + v, 0); const media = suma / n; // Mediana const ordenados = [...datos].sort((a, b) => a - b); const mitad = Math.floor(n / 2); const mediana = n % 2 !== 0 ? ordenados[mitad] : (ordenados[mitad - 1] + ordenados[mitad]) / 2; // Varianza (σ²) y Desviación Estándar (σ) const sumaDiferenciasCuadrado = datos.reduce((acc, v) => acc + Math.pow(v - media, 2), 0); const varianza = sumaDiferenciasCuadrado / n; const desviacion = Math.sqrt(varianza); // Error Estándar (SE = σ / √n) const errorEstandar = desviacion / Math.sqrt(n); // Mostrar resultados en pantalla elMedia.textContent = media.toFixed(2); elMediana.textContent = mediana.toFixed(2); elN.textContent = n; elDesviacion.textContent = desviacion.toFixed(2); elVarianza.textContent = varianza.toFixed(2); elError.textContent = errorEstandar.toFixed(2); // Actualizar textos detallados para el Modal Cian const listaStr = datos.join(', '); const ordenadosStr = ordenados.join(', '); window.detalleCalculos.media.texto = `Datos (x): [${listaStr}]<br><br>` + `Fórmula: μ = Σx / n<br>` + `Cálculo: (${datos.join(' + ')}) / ${n} = ${suma.toFixed(2)} / ${n}<br>` + `<strong>Resultado: ${media.toFixed(4)}</strong>`; window.detalleCalculos.mediana.texto = `Datos ordenados: [${ordenadosStr}]<br><br>` + `Posición central en n = ${n}<br>` + `<strong>Resultado: ${mediana.toFixed(4)}</strong>`; window.detalleCalculos.n.texto = `Cantidad total de observaciones:<br><br>` + `[${listaStr}]<br><br>` + `<strong>n = ${n}</strong>`; window.detalleCalculos.varianza.texto = `Fórmula: σ² = Σ(x - μ)² / n<br><br>` + `Suma de cuadrados: ${sumaDiferenciasCuadrado.toFixed(4)}<br>` + `Dividido entre n = ${n}<br>` + `<strong>Resultado: ${varianza.toFixed(4)}</strong>`; window.detalleCalculos.desviacion.texto = `Fórmula: σ = √σ²<br><br>` + `Cálculo: √${varianza.toFixed(4)}<br>` + `<strong>Resultado: ${desviacion.toFixed(4)}</strong>`; window.detalleCalculos.error.texto = `Fórmula: SE = σ / √n<br><br>` + `Cálculo: ${desviacion.toFixed(4)} / √${n} (${Math.sqrt(n).toFixed(4)})<br>` + `<strong>Resultado: ${errorEstandar.toFixed(4)}</strong>`; return { media, mediana, n, desviacion, varianza, errorEstandar }; } // ================= 4. TABLA DE FRECUENCIAS ================= function generarTablaFrecuenciaHTML() { const n = datos.length; const conteo = new Map(); // Ordenar datos de menor a mayor y contar ocurrencias const ordenados = [...datos].sort((a, b) => a - b); ordenados.forEach(val => { conteo.set(val, (conteo.get(val) || 0) + 1); }); let acumulada = 0; let filasHTML = ''; conteo.forEach((f, valor) => { acumulada += f; const fr = f / n; const porcentaje = (fr * 100).toFixed(1); filasHTML += ` <tr> <td>${valor}</td> <td>${f}</td> <td>${acumulada}</td> <td>${fr.toFixed(3)}</td> <td>${porcentaje}%</td> </tr> `; }); return ` <div class="tabla-frecuencia-wrapper"> <table class="tabla-frecuencia"> <thead> <tr> <th>dato (x)</th> <th>f</th> <th>F</th> <th>fr</th> <th>%</th> </tr> </thead> <tbody> ${filasHTML} </tbody> </table> </div> `; } function abrirModalTablaFrecuencia() { if (datos.length === 0) return; // Solo se abre si hay datos ingresados inputValor.blur(); // Evita que quede el teclado virtual abierto en móviles modalTitulo.textContent = `Tabla de Frecuencia (n = ${datos.length})`; modalContenido.innerHTML = generarTablaFrecuenciaHTML(); modal.classList.add('activo'); } // ================= 5. GRÁFICO DE CAMPANA DE GAUSS ================= function ajustarResolucionCanvas() { const rect = canvas.parentElement.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1; canvas.width = rect.width * dpr; canvas.height = rect.height * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); return { width: rect.width, height: rect.height }; } function dibujarGrafico(stats = calcularEstadisticas()) { const { width, height } = ajustarResolucionCanvas(); ctx.clearRect(0, 0, width, height); const esClaro = document.body.classList.contains('light-mode'); const colorEje = esClaro ? 'rgba(15, 23, 42, 0.15)' : 'rgba(241, 245, 249, 0.15)'; const colorCurva = esClaro ? '#0284c7' : '#22d3ee'; const colorRelleno = esClaro ? 'rgba(2, 132, 199, 0.12)' : 'rgba(34, 211, 238, 0.12)'; const colorMedia = '#fb923c'; const colorPuntos = '#facc15'; const padX = width * 0.08; const padTop = height * 0.15; const padBottom = height * 0.18; const baseLineY = height - padBottom; const graphW = width - padX * 2; const graphH = baseLineY - padTop; ctx.beginPath(); ctx.moveTo(padX, baseLineY); ctx.lineTo(width - padX, baseLineY); ctx.strokeStyle = colorEje; ctx.lineWidth = 1.5; ctx.stroke(); if (!stats || stats.n === 0) { ctx.fillStyle = esClaro ? 'rgba(15,23,42,0.3)' : 'rgba(241,245,249,0.25)'; ctx.font = '14px monospace'; ctx.textAlign = 'center'; ctx.fillText('ingresá datos para graficar N(μ, σ²)', width / 2, height / 2); return; } const { media, desviacion } = stats; if (desviacion === 0) { const centerX = width / 2; ctx.beginPath(); ctx.setLineDash([5, 5]); ctx.moveTo(centerX, padTop); ctx.lineTo(centerX, baseLineY); ctx.strokeStyle = colorMedia; ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = colorMedia; ctx.font = '12px monospace'; ctx.textAlign = 'center'; ctx.fillText(`μ = ${media.toFixed(2)} (σ = 0)`, centerX, baseLineY + 18); return; } const minX = media - 4 * desviacion; const maxX = media + 4 * desviacion; const rangoX = maxX - minX; const pdf = (x) => { const exp = -0.5 * Math.pow((x - media) / desviacion, 2); return (1 / (desviacion * Math.sqrt(2 * Math.PI))) * Math.exp(exp); }; const maxY = pdf(media); ctx.beginPath(); const pasos = 200; 

Usa el código con precaución.

for (let i = 0; i <= pasos; i++) {
const t = i / pasos;
const xVal = minX + t * rangoX;
const yVal = pdf(xVal);

const px = padX + t * graphW;
const py = baseLineY - (yVal / maxY) * graphH;

if (i === 0) {
ctx.moveTo(px, baseLineY);
ctx.lineTo(px, py);
} else {
ctx.lineTo(px, py);
}
}
ctx.lineTo(width - padX, baseLineY);
ctx.closePath();

ctx.fillStyle = colorRelleno;
ctx.fill();

ctx.strokeStyle = colorCurva;
ctx.lineWidth = 2.5;
ctx.stroke();

const mediaPx = padX + ((media - minX) / rangoX) * graphW;
ctx.beginPath();
ctx.setLineDash([4, 4]);
ctx.moveTo(mediaPx, padTop);
ctx.lineTo(mediaPx, baseLineY);
ctx.strokeStyle = colorMedia;
ctx.lineWidth = 1.5;
ctx.stroke();
ctx.setLineDash([]);

ctx.font = '11px monospace';
ctx.textAlign = 'center';
[-2, -1, 0, 1, 2].forEach(k => {
const val = media + k * desviacion;
const px = padX + ((val - minX) / rangoX) * graphW;
ctx.fillStyle = k === 0 ? colorMedia : (esClaro ? '#64748b' : '#94a3b8');
const etiqueta = k === 0 ? μ:${val.toFixed(1)} : ${k > 0 ? '+' : ''}${k}σ;
ctx.fillText(etiqueta, px, baseLineY + 16);
});

datos.forEach(d => {
const clamped = Math.max(minX, Math.min(maxX, d));
const px = padX + ((clamped - minX) / rangoX) * graphW;
ctx.beginPath();
ctx.arc(px, baseLineY, 4, 0, Math.PI * 2);
ctx.fillStyle = colorPuntos;
ctx.fill();
});
}

function actualizarTodo() {
const stats = calcularEstadisticas();
dibujarGrafico(stats);
}

window.addEventListener('resize', () => dibujarGrafico());

// ================= 6. MODALES CON PULSACIÓN LARGA =================
let timerPresion;
const TIEMPO_PULSACION = 450;

function abrirModalMetrica(metrica) {
const info = window.detalleCalculos[metrica];
modalTitulo.textContent = info.titulo;
modalContenido.innerHTML = info.texto;
modal.classList.add('activo');
}

// Pulsación larga en los 6 resultados laterales
itemsDatos.forEach(item => {
const metrica = item.getAttribute('data-metrica');

const iniciarPresion = () => {
timerPresion = setTimeout(() => abrirModalMetrica(metrica), TIEMPO_PULSACION);
};
const cancelarPresion = () => clearTimeout(timerPresion);

item.addEventListener('mousedown', iniciarPresion);
item.addEventListener('mouseup', cancelarPresion);
item.addEventListener('mouseleave', cancelarPresion);

item.addEventListener('touchstart', iniciarPresion, { passive: true });
item.addEventListener('touchend', cancelarPresion);
item.addEventListener('touchcancel', cancelarPresion);
});

// Pulsación larga en el campo de entrada amarillo (Tabla de Frecuencia)
let timerInput;
const iniciarPresionInput = () => {
if (datos.length === 0) return;
timerInput = setTimeout(() => abrirModalTablaFrecuencia(), TIEMPO_PULSACION);
};
const cancelarPresionInput = () => clearTimeout(timerInput);

inputValor.addEventListener('mousedown', iniciarPresionInput);
inputValor.addEventListener('mouseup', cancelarPresionInput);
inputValor.addEventListener('mouseleave', cancelarPresionInput);

inputValor.addEventListener('touchstart', iniciarPresionInput, { passive: true });
inputValor.addEventListener('touchend', cancelarPresionInput);
inputValor.addEventListener('touchcancel', cancelarPresionInput);

// Cerrar modal con un toque
modal.addEventListener('click', () => {
modal.classList.remove('activo');
});

// Inicializar gráfico vacío al cargar
actualizarTodo();
});

