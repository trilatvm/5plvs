let datos = [];

export function obtenerDatos() {
  return [...datos];
}

export function agregarValor(valor) {
  if (typeof valor !== 'number' || isNaN(valor)) return false;
  datos.push(valor);
  return true;
}

export function quitarValor(valorEspecifico = NaN) {
  if (datos.length === 0) return false;

  if (!isNaN(valorEspecifico)) {
    const indice = datos.lastIndexOf(valorEspecifico);
    if (indice !== -1) {
      datos.splice(indice, 1);
      return true;
    }
  }

  datos.pop();
  return true;
}

