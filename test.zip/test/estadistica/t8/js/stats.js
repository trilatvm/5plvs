export function calcularEstadisticas(datos) {
  const n = datos.length;

  if (n === 0) {
    return null;
  }

  // Media (μ)
  const suma = datos.reduce((acc, v) => acc + v, 0);
  const media = suma / n;

  // Mediana
  const ordenados = [...datos].sort((a, b) => a - b);
  const mitad = Math.floor(n / 2);
  const mediana = n % 2 !== 0
    ? ordenados[mitad]
    : (ordenados[mitad - 1] + ordenados[mitad]) / 2;

  // Varianza (σ²) y Desviación Estándar (σ)
  const sumaDiferenciasCuadrado = datos.reduce((acc, v) => acc + Math.pow(v - media, 2), 0);
  const varianza = sumaDiferenciasCuadrado / n;
  const desviacion = Math.sqrt(varianza);

  // Error Estándar (SE)
  const errorEstandar = desviacion / Math.sqrt(n);

  // Textos explicativos para el modal
  const listaStr = datos.join(', ');
  const ordenadosStr = ordenados.join(', ');

  const detalles = {
    media: {
      titulo: 'Media (μ)',
      texto: `Datos (x): [${listaStr}]<br><br>` +
             `Fórmula: μ = Σx / n<br>` +
             `Cálculo: (${datos.join(' + ')}) / ${n} = ${suma.toFixed(2)} / ${n}<br>` +
             `<strong>Resultado: ${media.toFixed(4)}</strong>`
    },
    mediana: {
      titulo: 'Mediana',
      texto: `Datos ordenados: [${ordenadosStr}]<br><br>` +
             `Posición central en n = ${n}<br>` +
             `<strong>Resultado: ${mediana.toFixed(4)}</strong>`
    },
    n: {
      titulo: 'Muestra (n)',
      texto: `Cantidad total de observaciones:<br><br>` +
             `[${listaStr}]<br><br>` +
             `<strong>n = ${n}</strong>`
    },
    varianza: {
      titulo: 'Varianza (σ²)',
      texto: `Fórmula: σ² = Σ(x - μ)² / n<br><br>` +
             `Suma de cuadrados: ${sumaDiferenciasCuadrado.toFixed(4)}<br>` +
             `Dividido entre n = ${n}<br>` +
             `<strong>Resultado: ${varianza.toFixed(4)}</strong>`
    },
    desviacion: {
      titulo: 'Desviación Estándar (σ)',
      texto: `Fórmula: σ = √σ²<br><br>` +
             `Cálculo: √${varianza.toFixed(4)}<br>` +
             `<strong>Resultado: ${desviacion.toFixed(4)}</strong>`
    },
    error: {
      titulo: 'Error Estándar (SE)',
      texto: `Fórmula: SE = σ / √n<br><br>` +
             `Cálculo: ${desviacion.toFixed(4)} / √${n} (${Math.sqrt(n).toFixed(4)})<br>` +
             `<strong>Resultado: ${errorEstandar.toFixed(4)}</strong>`
    }
  };

  return { media, mediana, n, desviacion, varianza, errorEstandar, detalles };
}

export function generarTablaFrecuenciaHTML(datos) {
  const n = datos.length;
  const conteo = new Map();
  const ordenados = [...datos].sort((a, b) => a - b);

  ordenados.forEach(val => {
    conteo.set(val, (conteo.get(val) || 0) + 1);
  });

  let acumulada = 0;
  let filasHTML = '';

  conteo.forEach((f, valor) => {
    acumulada += f;
    const fr = f / n;
    const porcentaje = (fr * 100).toFixed(1);

    filasHTML += `
      <tr>
        <td>${valor}</td>
        <td>${f}</td>
        <td>${acumulada}</td>
        <td>${fr.toFixed(3)}</td>
        <td>${porcentaje}%</td>
      </tr>
    `;
  });

  return `
    <div class="tabla-frecuencia-wrapper">
      <table class="tabla-frecuencia">
        <thead>
          <tr>
            <th>dato (x)</th>
            <th>f</th>
            <th>F</th>
            <th>fr</th>
            <th>%</th>
          </tr>
        </thead>
        <tbody>
          ${filasHTML}
        </tbody>
      </table>
    </div>
  `;
}

