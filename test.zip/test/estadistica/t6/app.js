document.addEventListener('DOMContentLoaded', () => { // Referencias al DOM const btnTema = document.getElementById('btn-tema'); const btnMas = document.getElementById('btn-mas'); const btnMenos = document.getElementById('btn-menos'); const inputValor = document.getElementById('input-valor'); const elMedia = document.getElementById('val-media'); const elMediana = document.getElementById('val-mediana'); const elN = document.getElementById('val-n'); const elDesviacion = document.getElementById('val-desviacion'); const elVarianza = document.getElementById('val-varianza'); const elError = document.getElementById('val-error'); const canvas = document.getElementById('graficoNormal'); const ctx = canvas.getContext('2d'); const modal = document.getElementById('modal-calculos'); const modalTitulo = document.getElementById('modal-titulo'); const modalContenido = document.getElementById('modal-contenido'); const itemsDatos = document.querySelectorAll('.dato-item'); // Estado de la aplicación (lista de números ingresados) let datos = []; // Detalle de cálculos para el modal transparente window.detalleCalculos = { media: { titulo: 'Media (μ)', texto: 'Sin datos ingresados aún.' }, mediana: { titulo: 'Mediana', texto: 'Sin datos ingresados aún.' }, n: { titulo: 'Muestra (n)', texto: 'Sin datos ingresados aún.' }, desviacion: { titulo: 'Desviación Estándar (σ)', texto: 'Sin datos ingresados aún.' }, varianza: { titulo: 'Varianza (σ²)', texto: 'Sin datos ingresados aún.' }, error: { titulo: 'Error Estándar (SE)', texto: 'Sin datos ingresados aún.' } }; // ================= 1. TEMA DÍA / NOCHE ================= btnTema.addEventListener('click', () => { document.body.classList.toggle('light-mode'); btnTema.textContent = document.body.classList.contains('light-mode') ? '🌙' : '☀️'; dibujarGrafico(); }); // ================= 2. AGREGAR Y QUITAR DATOS ================= function agregarDato() { const valor = parseFloat(inputValor.value); if (isNaN(valor)) { inputValor.focus(); return; } datos.push(valor); inputValor.value = ''; inputValor.focus(); actualizarTodo(); } function quitarDato() { if (datos.length === 0) return; const valorEscrito = parseFloat(inputValor.value); if (!isNaN(valorEscrito)) { // Si escribió un número específico, busca y elimina ese valor const indice = datos.lastIndexOf(valorEscrito); if (indice !== -1) { datos.splice(indice, 1); } else { datos.pop(); // Si no existe, quita el último ingresado } inputValor.value = ''; } else { // Si el campo está vacío, quita el último dato ingresado datos.pop(); } inputValor.focus(); actualizarTodo(); } btnMas.addEventListener('click', agregarDato); btnMenos.addEventListener('click', quitarDato); // Permitir agregar con la tecla Enter inputValor.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); agregarDato(); } }); // ================= 3. CÁLCULOS ESTADÍSTICOS ================= function calcularEstadisticas() { const n = datos.length; if (n === 0) { elMedia.textContent = '0.00'; elMediana.textContent = '0.00'; elN.textContent = '0'; elDesviacion.textContent = '0.00'; elVarianza.textContent = '0.00'; elError.textContent = '0.00'; Object.keys(window.detalleCalculos).forEach(k => { window.detalleCalculos[k].texto = 'Sin datos ingresados aún.'; }); return null; } // Media (μ) const suma = datos.reduce((acc, v) => acc + v, 0); const media = suma / n; // Mediana const ordenados = [...datos].sort((a, b) => a - b); const mitad = Math.floor(n / 2); const mediana = n % 2 !== 0 ? ordenados[mitad] : (ordenados[mitad - 1] + ordenados[mitad]) / 2; // Varianza (σ²) y Desviación Estándar (σ) poblacional const sumaDiferenciasCuadrado = datos.reduce((acc, v) => acc + Math.pow(v - media, 2), 0); const varianza = sumaDiferenciasCuadrado / n; const desviacion = Math.sqrt(varianza); // Error Estándar (SE = σ / √n) const errorEstandar = desviacion / Math.sqrt(n); // Mostrar resultados en pantalla elMedia.textContent = media.toFixed(2); elMediana.textContent = mediana.toFixed(2); elN.textContent = n; elDesviacion.textContent = desviacion.toFixed(2); elVarianza.textContent = varianza.toFixed(2); elError.textContent = errorEstandar.toFixed(2); // Actualizar textos detallados para el Modal Cian const listaStr = datos.join(', '); const ordenadosStr = ordenados.join(', '); window.detalleCalculos.media.texto = `Datos (x): [${listaStr}]<br><br>` + `Fórmula: μ = Σx / n<br>` + `Cálculo: (${datos.join(' + ')}) / ${n} = ${suma.toFixed(2)} / ${n}<br>` + `<strong>Resultado: ${media.toFixed(4)}</strong>`; window.detalleCalculos.mediana.texto = `Datos ordenados: [${ordenadosStr}]<br><br>` + `Posición central en n = ${n}<br>` + `<strong>Resultado: ${mediana.toFixed(4)}</strong>`; window.detalleCalculos.n.texto = `Cantidad total de observaciones:<br><br>` + `[${listaStr}]<br><br>` + `<strong>n = ${n}</strong>`; window.detalleCalculos.varianza.texto = `Fórmula: σ² = Σ(x - μ)² / n<br><br>` + `Suma de cuadrados: ${sumaDiferenciasCuadrado.toFixed(4)}<br>` + `Dividido entre n = ${n}<br>` + `<strong>Resultado: ${varianza.toFixed(4)}</strong>`; window.detalleCalculos.desviacion.texto = `Fórmula: σ = √σ²<br><br>` + `Cálculo: √${varianza.toFixed(4)}<br>` + `<strong>Resultado: ${desviacion.toFixed(4)}</strong>`; window.detalleCalculos.error.texto = `Fórmula: SE = σ / √n<br><br>` + `Cálculo: ${desviacion.toFixed(4)} / √${n} (${Math.sqrt(n).toFixed(4)})<br>` + `<strong>Resultado: ${errorEstandar.toFixed(4)}</strong>`; return { media, mediana, n, desviacion, varianza, errorEstandar }; } // ================= 4. GRÁFICO DE CAMPANA DE GAUSS ================= function ajustarResolucionCanvas() { const rect = canvas.parentElement.getBoundingClientRect(); const dpr = window.devicePixelRatio || 1; canvas.width = rect.width * dpr; canvas.height = rect.height * dpr; ctx.setTransform(dpr, 0, 0, dpr, 0, 0); return { width: rect.width, height: rect.height }; } function dibujarGrafico(stats = calcularEstadisticas()) { const { width, height } = ajustarResolucionCanvas(); ctx.clearRect(0, 0, width, height); const esClaro = document.body.classList.contains('light-mode'); const colorEje = esClaro ? 'rgba(15, 23, 42, 0.15)' : 'rgba(241, 245, 249, 0.15)'; const colorCurva = esClaro ? '#0284c7' : '#22d3ee'; // Cian const colorRelleno = esClaro ? 'rgba(2, 132, 199, 0.12)' : 'rgba(34, 211, 238, 0.12)'; const colorMedia = '#fb923c'; // Naranja const colorPuntos = '#facc15'; // Amarillo const padX = width * 0.08; const padTop = height * 0.15; const padBottom = height * 0.18; const baseLineY = height - padBottom; const graphW = width - padX * 2; const graphH = baseLineY - padTop; // Dibujar eje horizontal base ctx.beginPath(); ctx.moveTo(padX, baseLineY); ctx.lineTo(width - padX, baseLineY); ctx.strokeStyle = colorEje; ctx.lineWidth = 1.5; ctx.stroke(); // Si no hay datos o desviación es 0 if (!stats || stats.n === 0) { ctx.fillStyle = esClaro ? 'rgba(15,23,42,0.3)' : 'rgba(241,245,249,0.25)'; ctx.font = '14px monospace'; ctx.textAlign = 'center'; ctx.fillText('ingresá datos para graficar N(μ, σ²)', width / 2, height / 2); return; } const { media, desviacion } = stats; // Caso especial: todos los datos son iguales (σ = 0) if (desviacion === 0) { const centerX = width / 2; ctx.beginPath(); ctx.setLineDash([5, 5]); ctx.moveTo(centerX, padTop); ctx.lineTo(centerX, baseLineY); ctx.strokeStyle = colorMedia; ctx.lineWidth = 2; ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = colorMedia; ctx.font = '12px monospace'; ctx.textAlign = 'center'; ctx.fillText(`μ = ${media.toFixed(2)} (σ = 0)`, centerX, baseLineY + 18); return; } // Rango X: μ - 4σ hasta μ + 4σ const minX = media - 4 * desviacion; const maxX = media + 4 * desviacion; const rangoX = maxX - minX; // Función densidad normal const pdf = (x) => { const exp = -0.5 * Math.pow((x - media) / desviacion, 2); return (1 / (desviacion * Math.sqrt(2 * Math.PI))) * Math.exp(exp); }; const maxY = pdf(media); // Trazar campana de Gauss ctx.beginPath(); const pasos = 200; for (let i = 0; i <= pasos; i++) { const t = i / pasos; const xVal = minX + t * rangoX; const yVal = pdf(xVal); const px = padX + t * graphW; const py = baseLineY - (yVal / maxY) * graphH; if (i === 0) { ctx.moveTo(px, baseLineY); ctx.lineTo(px, py); } else { ctx.lineTo(px, py); } } ctx.lineTo(width - padX, baseLineY); ctx.closePath(); // Relleno bajo la curva ctx.fillStyle = colorRelleno; ctx.fill(); // Línea de la curva ctx.strokeStyle = colorCurva; ctx.lineWidth = 2.5; ctx.stroke(); // Línea vertical punteada de la Media (μ) const mediaPx = padX + ((media - minX) / rangoX) * graphW; ctx.beginPath(); ctx.setLineDash([5, 5]); ctx.moveTo(mediaPx, padTop); ctx.lineTo(mediaPx, baseLineY); ctx.strokeStyle = colorMedia; ctx.lineWidth = 1.5; ctx.stroke(); ctx.setLineDash([]); // Marcas de desviación estándar (-2σ, -1σ, μ, +1σ, +2σ) 

Usa el código con precaución.

ctx.font = '11px monospace';
ctx.textAlign = 'center';
[-2, -1, 0, 1, 2].forEach(k => {
const val = media + k * desviacion;
const px = padX + ((val - minX) / rangoX) * graphW;
ctx.fillStyle = k === 0 ? colorMedia : (esClaro ? '#64748b' : '#94a3b8');
const etiqueta = k === 0 ? μ:${val.toFixed(1)} : ${k > 0 ? '+' : ''}${k}σ;
ctx.fillText(etiqueta, px, baseLineY + 16);
});

// Dibujar puntos individuales ingresados sobre el eje X
datos.forEach(d => {
const clamped = Math.max(minX, Math.min(maxX, d));
const px = padX + ((clamped - minX) / rangoX) * graphW;
ctx.beginPath();
ctx.arc(px, baseLineY, 4, 0, Math.PI * 2);
ctx.fillStyle = colorPuntos;
ctx.fill();
});
}

function actualizarTodo() {
const stats = calcularEstadisticas();
dibujarGrafico(stats);
}

// Redibujar automáticamente si cambia el tamaño de la ventana
window.addEventListener('resize', () => dibujarGrafico());

// ================= 5. MODAL CON PULSACIÓN LARGA =================
let timerPresion;
const TIEMPO_PULSACION = 450;

function abrirModal(metrica) {
const info = window.detalleCalculos[metrica];
modalTitulo.textContent = info.titulo;
modalContenido.innerHTML = info.texto;
modal.classList.add('activo');
}

itemsDatos.forEach(item => {
const metrica = item.getAttribute('data-metrica');

const iniciarPresion = () => {
timerPresion = setTimeout(() => abrirModal(metrica), TIEMPO_PULSACION);
};
const cancelarPresion = () => clearTimeout(timerPresion);

item.addEventListener('mousedown', iniciarPresion);
item.addEventListener('mouseup', cancelarPresion);
item.addEventListener('mouseleave', cancelarPresion);

item.addEventListener('touchstart', iniciarPresion, { passive: true });
item.addEventListener('touchend', cancelarPresion);
item.addEventListener('touchcancel', cancelarPresion);
});

modal.addEventListener('click', () => {
modal.classList.remove('activo');
});

// Inicializar gráfico vacío al cargar
actualizarTodo();
});

