
window.AppStats = window.AppStats || {};

window.AppStats.State = (function () {
  let datos = [];

  return {
    obtenerDatos() {
      return [...datos];
    },
    agregarValor(valor) {
      if (typeof valor !== 'number' || isNaN(valor)) return false;
      datos.push(valor);
      return true;
    },
    quitarValor(valorEspecifico = NaN) {
      if (datos.length === 0) return false;
      if (!isNaN(valorEspecifico)) {
        const indice = datos.lastIndexOf(valorEspecifico);
        if (indice !== -1) {
          datos.splice(indice, 1);
          return true;
        }
      }
      datos.pop();
      return true;
    }
  };
})();
