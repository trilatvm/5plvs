
document.addEventListener('DOMContentLoaded', () => {
  const aviso = document.getElementById('pantalla-aviso');
  const avisoTexto = document.getElementById('aviso-texto');

  try {
    // Verificar que los módulos cargaron correctamente
    if (!window.AppStats || !window.AppStats.State || !window.AppStats.Math || !window.AppStats.Chart) {
      throw new Error('No se pudieron cargar los archivos JS de la carpeta js/. Verificá que la carpeta js/ esté junto a index.html.');
    }

    const { State, Math: StatsMath, Chart } = window.AppStats;

    const btnTema = document.getElementById('btn-tema');
    const btnMas = document.getElementById('btn-mas');
    const btnMenos = document.getElementById('btn-menos');
    const inputValor = document.getElementById('input-valor');

    const els = {
      media: document.getElementById('val-media'),
      mediana: document.getElementById('val-mediana'),
      n: document.getElementById('val-n'),
      desviacion: document.getElementById('val-desviacion'),
      varianza: document.getElementById('val-varianza'),
      error: document.getElementById('val-error')
    };

    const modal = document.getElementById('modal-calculos');
    const modalTitulo = document.getElementById('modal-titulo');
    const modalContenido = document.getElementById('modal-contenido');
    const itemsDatos = document.querySelectorAll('.dato-item');

    const grafico = new Chart(document.getElementById('graficoNormal'));
    let detallesActuales = null;

    function actualizarUI() {
      const datos = State.obtenerDatos();
      const stats = StatsMath.calcularEstadisticas(datos);
      const esClaro = document.body.classList.contains('light-mode');

      if (!stats) {
        els.media.textContent = '0.00';
        els.mediana.textContent = '0.00';
        els.n.textContent = '0';
        els.desviacion.textContent = '0.00';
        els.varianza.textContent = '0.00';
        els.error.textContent = '0.00';
        detallesActuales = null;
      } else {
        els.media.textContent = stats.media.toFixed(2);
        els.mediana.textContent = stats.mediana.toFixed(2);
        els.n.textContent = stats.n;
        els.desviacion.textContent = stats.desviacion.toFixed(2);
        els.varianza.textContent = stats.varianza.toFixed(2);
        els.error.textContent = stats.errorEstandar.toFixed(2);
        detallesActuales = stats.detalles;
      }

      grafico.dibujar(stats, datos, esClaro);
    }

    btnTema.addEventListener('click', () => {
      document.body.classList.toggle('light-mode');
      btnTema.textContent = document.body.classList.contains('light-mode') ? '🌙' : '☀️';
      actualizarUI();
    });

    function manejarAgregar() {
      const val = parseFloat(inputValor.value);
      if (State.agregarValor(val)) {
        inputValor.value = '';
        actualizarUI();
      }
      inputValor.focus();
    }

    function manejarQuitar() {
      const val = parseFloat(inputValor.value);
      if (State.quitarValor(val)) {
        inputValor.value = '';
        actualizarUI();
      }
      inputValor.focus();
    }

    btnMas.addEventListener('click', manejarAgregar);
    btnMenos.addEventListener('click', manejarQuitar);
    inputValor.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        manejarAgregar();
      }
    });

    window.addEventListener('resize', actualizarUI);

    function registrarPulsacionLarga(elemento, callback, duracion = 450) {
      let timer;
      const iniciar = () => { timer = setTimeout(callback, duracion); };
      const cancelar = () => clearTimeout(timer);

      elemento.addEventListener('mousedown', iniciar);
      elemento.addEventListener('mouseup', cancelar);
      elemento.addEventListener('mouseleave', cancelar);
      elemento.addEventListener('touchstart', iniciar, { passive: true });
      elemento.addEventListener('touchend', cancelar);
      elemento.addEventListener('touchcancel', cancelar);
    }

    itemsDatos.forEach(item => {
      const metrica = item.getAttribute('data-metrica');
      registrarPulsacionLarga(item, () => {
        if (!detallesActuales) return;
        modalTitulo.textContent = detallesActuales[metrica].titulo;
        modalContenido.innerHTML = detallesActuales[metrica].texto;
        modal.classList.add('activo');
      });
    });

    registrarPulsacionLarga(inputValor, () => {
      const datos = State.obtenerDatos();
      if (datos.length === 0) return;
      inputValor.blur();
      modalTitulo.textContent = `Tabla de Frecuencia (n = ${datos.length})`;
      modalContenido.innerHTML = StatsMath.generarTablaFrecuenciaHTML(datos);
      modal.classList.add('activo');
    });

    modal.addEventListener('click', () => modal.classList.remove('activo'));

    // Todo inició correctamente: ocultar pantalla de advertencia
    actualizarUI();
    aviso.classList.add('oculta');
    setTimeout(() => aviso.remove(), 350);

  } catch (error) {
    // Si algo falla en Android Firefox, muestra el motivo claro en lugar de pantalla negra
    avisoTexto.innerHTML = `<strong>Error de carga:</strong><br>${error.message}`;
  }
});
