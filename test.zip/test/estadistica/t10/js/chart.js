window.AppStats = window.AppStats || {};

window.AppStats.Chart = class NormalChart {
  constructor(canvasElement) {
    this.canvas = canvasElement;
    this.ctx = canvasElement.getContext('2d');
  }

  ajustarResolucion() {
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;
    this.canvas.width = Math.max(1, rect.width * dpr);
    this.canvas.height = Math.max(1, rect.height * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return { width: rect.width, height: rect.height };
  }

  dibujar(stats, datos, esClaro) {
    const { width, height } = this.ajustarResolucion();
    if (width === 0 || height === 0) return;

    const ctx = this.ctx;
    ctx.clearRect(0, 0, width, height);

    const colorEje = esClaro ? 'rgba(15, 23, 42, 0.15)' : 'rgba(241, 245, 249, 0.15)';
    const colorCurva = esClaro ? '#0284c7' : '#22d3ee';
    const colorRelleno = esClaro ? 'rgba(2, 132, 199, 0.12)' : 'rgba(34, 211, 238, 0.12)';
    const colorMedia = '#fb923c';
    const colorPuntos = '#facc15';

    const padX = width * 0.08;
    const padTop = height * 0.15;
    const padBottom = height * 0.18;
    const baseLineY = height - padBottom;
    const graphW = width - padX * 2;
    const graphH = baseLineY - padTop;

    ctx.beginPath();
    ctx.moveTo(padX, baseLineY);
    ctx.lineTo(width - padX, baseLineY);
    ctx.strokeStyle = colorEje;
    ctx.lineWidth = 1.5;
    ctx.stroke();

    if (!stats || stats.n === 0) {
      ctx.fillStyle = esClaro ? 'rgba(15,23,42,0.3)' : 'rgba(241,245,249,0.25)';
      ctx.font = '13px monospace';
      ctx.textAlign = 'center';
      ctx.fillText('ingresá datos para graficar N(μ, σ²)', width / 2, height / 2);
      return;
    }

    const { media, desviacion } = stats;

    if (desviacion === 0) {
      const centerX = width / 2;
      ctx.beginPath();
      ctx.setLineDash();
      ctx.moveTo(centerX, padTop);
      ctx.lineTo(centerX, baseLineY);
      ctx.strokeStyle = colorMedia;
      ctx.lineWidth = 2;
      ctx.stroke();
      ctx.setLineDash([]);

      ctx.fillStyle = colorMedia;
      ctx.font = '12px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`μ = ${media.toFixed(2)} (σ = 0)`, centerX, baseLineY + 18);
      return;
    }

    const minX = media - 4 * desviacion;
    const maxX = media + 4 * desviacion;
    const rangoX = maxX - minX;

    const pdf = (x) => {
      const exp = -0.5 * Math.pow((x - media) / desviacion, 2);
      return (1 / (desviacion * Math.sqrt(2 * Math.PI))) * Math.exp(exp);
    };

    const maxY = pdf(media);

    ctx.beginPath();
    const pasos = 200;
    for (let i = 0; i <= pasos; i++) {
      const t = i / pasos;
      const xVal = minX + t * rangoX;
      const yVal = pdf(xVal);
      const px = padX + t * graphW;
      const py = baseLineY - (yVal / maxY) * graphH;

      if (i === 0) {
        ctx.moveTo(px, baseLineY);
        ctx.lineTo(px, py);
      } else {
        ctx.lineTo(px, py);
      }
    }
    ctx.lineTo(width - padX, baseLineY);
    ctx.closePath();

    ctx.fillStyle = colorRelleno;
    ctx.fill();
    ctx.strokeStyle = colorCurva;
    ctx.lineWidth = 2.5;
    ctx.stroke();

    const mediaPx = padX + ((media - minX) / rangoX) * graphW;
    ctx.beginPath();
    ctx.setLineDash();
    ctx.moveTo(mediaPx, padTop);
    ctx.lineTo(mediaPx, baseLineY);
    ctx.strokeStyle = colorMedia;
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.font = '11px monospace';
    ctx.textAlign = 'center';
    [-2, -1, 0, 1, 2].forEach(k => {
      const val = media + k * desviacion;
      const px = padX + ((val - minX) / rangoX) * graphW;
      ctx.fillStyle = k === 0 ? colorMedia : (esClaro ? '#64748b' : '#94a3b8');
      const etiqueta = k === 0 ? `μ:${val.toFixed(1)}` : `${k > 0 ? '+' : ''}${k}σ`;
      ctx.fillText(etiqueta, px, baseLineY + 16);
    });

    datos.forEach(d => {
      const clamped = Math.max(minX, Math.min(maxX, d));
      const px = padX + ((clamped - minX) / rangoX) * graphW;
      ctx.beginPath();
      ctx.arc(px, baseLineY, 4, 0, Math.PI * 2);
      ctx.fillStyle = colorPuntos;
      ctx.fill();
    });
  }
};

